<?php
session_start();
require_once 'db.php';

// Check authentication
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'Master Admin') {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized access']);
    exit;
}

// Validate input
if (!isset($_POST['trip_id'], $_POST['vehicle_id'], $_POST['driver_id'], $_POST['comment'])) {
    echo json_encode(['status' => 'error', 'message' => 'Missing required data']);
    exit;
}

$trip_id = intval($_POST['trip_id']);
$vehicle_id = intval($_POST['vehicle_id']);
$driver_id = intval($_POST['driver_id']);
$comment = mysqli_real_escape_string($conn, $_POST['comment']);

try {
    // Start transaction
    mysqli_begin_transaction($conn);

    // Update trip request
    $updateTrip = mysqli_query($conn, "
        UPDATE trip_requests 
        SET vehicle_id = $vehicle_id,
            driver_id = $driver_id
        WHERE id = $trip_id
    ");

    // Update vehicle status
    $updateVehicle = mysqli_query($conn, "
        UPDATE vehicles 
        SET status = 'In Use' 
        WHERE id = $vehicle_id
    ");

    // Update driver status
    $updateDriver = mysqli_query($conn, "
        UPDATE drivers 
        SET status = 'Assigned' 
        WHERE id = $driver_id
    ");

    // Add assignment record
    $insertAssignment = mysqli_query($conn, "
        INSERT INTO trip_assignments (
            trip_id, 
            vehicle_id, 
            driver_id, 
            assigned_by, 
            comment, 
            assignment_date
        ) VALUES (
            $trip_id,
            $vehicle_id,
            $driver_id,
            {$_SESSION['id']},
            '$comment',
            NOW()
        )
    ");

    if ($updateTrip && $updateVehicle && $updateDriver && $insertAssignment) {
        mysqli_commit($conn);
        echo json_encode(['status' => 'success']);
    } else {
        throw new Exception('Failed to update database');
    }
} catch (Exception $e) {
    mysqli_rollback($conn);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}

mysqli_close($conn);