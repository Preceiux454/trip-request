<?php
require_once 'db.php';
session_start();

header('Content-Type: application/json');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

function sendCompletionNotification($managerEmail, $managerName, $requestor_name, $requestor_email, $department, $date_needed, $time_needed, $time_return, $route_from, $route_to, $passengers, $purpose, $company_vehicle) {
    $mail = new PHPMailer(true);
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;
        $mail->Username   = 'furfectmatch00@gmail.com';
        $mail->Password   = 'hshp joln vbgl yddk';

        // Recipients
        $mail->setFrom('furfectmatch00@gmail.com', 'Vehicle Request');
        $mail->addAddress($managerEmail);

        // Format schedule details
        $formattedDate = date('F j, Y', strtotime($date_needed));
        $formattedTime = date('h:i A', strtotime($time_needed));

        // Build email content using provided template
        $emailBody = "

        <p style='font-family: Arial, sans-serif; font-size: 16px; color: #333;'> Good Day {$managerName}!,</p>
        <p style='font-family: Arial, sans-serif; font-size: 16px; color: #333;'>We hope this email finds you well. A new Vehicle Request has been submitted that requires your review and approval.</p>
        <p style='font-family: Arial, sans-serif; font-size: 16px; color: #333;'><strong>Request Details:</strong><br>
       -----------------------------------------------<br>
        <p style='font-family: Arial, sans-serif; font-size: 16px; color: #333;'>  <b>Submitted by:</b> {$requestor_name} <br>
        <b> Email: </b> {$requestor_email}  <br>
        <b>   Department:  </b>{$department} <br><br>
        <b>  Schedule: </b> <br>
       <b>• Date Required:</b> {$formattedDate}<br>
      <b>  • Pickup Time:</b> {$formattedTime}<br>
      <b> • Return Time: </b>{$time_return}<br><br>
      <b>  Vehicle & Route Information: </b> <br>
      <b>  • Requested Vehicle: </b> {$company_vehicle}<br>
     <b>   • Departure Point:</b> {$route_from}<br>
     <b>  • Destination: </b> {$route_to}<br>
     <b>  • Passengers:</b> {$passengers}<br><br>
     <b>  Purpose: </b>{$purpose}<br> </p>
        -----------------------------------------------</p>
        <p style='font-family: Arial, sans-serif; font-size: 16px; color: #333;'><strong>Required Actions:</p><br>
        1. Review the request details above<br>
        2. Access the request portal using the link below<br>
        3. Select your decision (Approve/Reject)<br>
        4. Provide any necessary comments<br>
        5. Submit your response<br>
         <p style='font-family: Arial, sans-serif; font-size: 16px; color: #333;'> <b> You may access this link: </b> <a href='http://localhost/Trip/login.php'>localhost/Trip/login.php</a></p>
        <p style='font-family: Arial, sans-serif; font-size: 16px; color: #333;'>IMPORTANT: This is an automated notification. For technical assistance, please contact the IT Help Desk.</p>  ";

        // Email content
        $mail->isHTML(true);
        $mail->Subject = 'Vehicle Request - Manager Approval';
        $mail->Body    = $emailBody;
        
        $mail->send();

    } catch (Exception $e) {
        throw new Exception("Mailer Error: {$mail->ErrorInfo}");
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        // Validate and sanitize inputs
        $requestor_name = mysqli_real_escape_string($conn, $_POST['requestor_name']);
        $requestor_email = mysqli_real_escape_string($conn, $_POST['requestor_email']);
        $department = mysqli_real_escape_string($conn, $_POST['department']);
        $manager_id = (int)$_POST['manager_id'];
        $date_needed = mysqli_real_escape_string($conn, $_POST['date_needed']);
        $time_needed = mysqli_real_escape_string($conn, $_POST['time_needed']);
        $time_return = mysqli_real_escape_string($conn, $_POST['time_return']);
        $route_from = mysqli_real_escape_string($conn, $_POST['route_from']);
        $route_to = mysqli_real_escape_string($conn, $_POST['route_to']);
        $passengers = mysqli_real_escape_string($conn, $_POST['passengers']);
        $purpose = mysqli_real_escape_string($conn, $_POST['purpose']);
        $company_vehicle = mysqli_real_escape_string($conn, $_POST['company_vehicle']);

        if (empty($requestor_name) || empty($requestor_email) || empty($department) || empty($manager_id)) {
            echo json_encode(["status" => "error", "message" => "Missing required fields"]);
            exit;
        }

        // Validate manager_id
        if (!isset($_POST['manager_id']) || empty($_POST['manager_id'])) {
            throw new Exception("Please select a manager");
        }

        $manager_id = intval($_POST['manager_id']);
        
        // Verify the selected manager exists
        $manager_check = mysqli_prepare($conn, "SELECT id, email, name FROM users WHERE id = ? AND role = 'Manager' LIMIT 1");
        mysqli_stmt_bind_param($manager_check, "i", $manager_id);
        mysqli_stmt_execute($manager_check);
        $manager_result = mysqli_stmt_get_result($manager_check);
        
        if (mysqli_num_rows($manager_result) === 0) {
            throw new Exception("Invalid manager selected");
        }

        $managerData = mysqli_fetch_assoc($manager_result);
        $managerEmail = $managerData['email'];
        $managerName  = $managerData['name'];

        // Begin transaction
        mysqli_begin_transaction($conn);

        // Insert trip request with specific manager
        $query = "INSERT INTO trip_requests (
            requestor_name, requestor_email, department, manager_id, date_needed, 
            time_needed, time_return, route_from, route_to, 
            passengers, purpose, company_vehicle, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending')";

        $stmt = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt, "sssissssssss",
            $requestor_name, $requestor_email, $department, $manager_id,
            $date_needed, $time_needed, $time_return,
            $route_from, $route_to, $passengers,
            $purpose, $company_vehicle
        );

        if (!mysqli_stmt_execute($stmt)) {
            throw new Exception("Error inserting trip request: " . mysqli_error($conn));
        }

        $trip_request_id = mysqli_insert_id($conn);

        // Insert initial pending approval for the selected manager only
        $approval_query = "INSERT INTO approvals (trip_id, approver_role, status) 
                          VALUES (?, 'manager', 'Pending')";
        
        $approval_stmt = mysqli_prepare($conn, $approval_query);
        mysqli_stmt_bind_param($approval_stmt, "i", $trip_request_id);
        
        if (!mysqli_stmt_execute($approval_stmt)) {
            throw new Exception("Failed to create approval record");
        }

        // Commit transaction
        mysqli_commit($conn);

        // Send email notification to the manager
        sendCompletionNotification($managerEmail, $managerName, $requestor_name, $requestor_email, $department, $date_needed, $time_needed, $time_return, $route_from, $route_to, $passengers, $purpose, $company_vehicle);

        echo json_encode([
            'status' => 'success',
            'message' => 'Trip request submitted successfully!'
        ]);

    } catch (Exception $e) {
        mysqli_rollback($conn);
        error_log("Trip Request Error: " . $e->getMessage());
        echo json_encode([
            'status' => 'error',
            'message' => $e->getMessage()
        ]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request"]);
}

mysqli_close($conn);

