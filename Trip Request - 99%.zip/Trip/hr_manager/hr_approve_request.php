<?php
session_start();
require_once '../db.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';

ini_set('../php_errors.log', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'HR Manager') {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized access']);
    exit;
}

try {
    $trip_id = intval($_POST['trip_id']);
    $comment = mysqli_real_escape_string($conn, $_POST['comment']);

    mysqli_begin_transaction($conn);

    // Insert HR manager approval with correct role name
    // Using 'hr' to match the query in the email section
    $query = "INSERT INTO approvals (trip_id, approver_role, status, comment) 
              VALUES (?, 'hr', 'Approved', ?)";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "is", $trip_id, $comment);
    
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Failed to insert approval record: " . mysqli_stmt_error($stmt));
    }

    // Update trip request status
    $update_query = "UPDATE trip_requests SET status = 'Final Approved' WHERE id = ?";
    $stmt = mysqli_prepare($conn, $update_query);
    mysqli_stmt_bind_param($stmt, "i", $trip_id);
    
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Failed to update trip request: " . mysqli_stmt_error($stmt));
    }

    // Update vehicle status to 'In Use'
    $update_vehicle_query = "UPDATE vehicles SET status = 'In Use' 
                            WHERE id = (SELECT vehicle_id FROM trip_requests WHERE id = ?)";
    $stmt = mysqli_prepare($conn, $update_vehicle_query);
    mysqli_stmt_bind_param($stmt, "i", $trip_id);
    
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Failed to update vehicle status: " . mysqli_stmt_error($stmt));
    }

    // Fetch all required information for email
    $email_query = "SELECT 
        tr.*,
        tr.requestor_email,
        tr.requestor_name,
        m.email as manager_email,
        m.name as manager_name,
        ma.status as manager_status,
        ma.comment as manager_comment,
        ma.created_at as manager_date,
        ada.status as admin_status,
        ada.comment as admin_comment,
        ada.created_at as admin_date,
        hra.status as hr_status,
        hra.comment as hr_comment,
        hra.created_at as hr_date,
        v.id as vehicle_id,
        v.name as vehicle_name,
        v.plate_number,
        v.status as vehicle_status,
        d.name as driver_name,
        d.contact as driver_contact,
        d.license_number as driver_license,
        u_admin.name as admin_name,
        u_admin.email as admin_email,
        u_hr.name as hr_manager_name,
        COALESCE(v.name, 'No Vehicle Assigned') as assigned_vehicle,
        COALESCE(v.plate_number, 'N/A') as vehicle_plate
    FROM trip_requests tr
    LEFT JOIN users m ON tr.manager_id = m.id
    LEFT JOIN approvals ma ON ma.trip_id = tr.id AND ma.approver_role = 'manager'
    LEFT JOIN approvals ada ON ada.trip_id = tr.id AND ada.approver_role = 'admin'
    LEFT JOIN approvals hra ON hra.trip_id = tr.id AND hra.approver_role = 'hr'
    LEFT JOIN vehicles v ON v.id = tr.vehicle_id
    LEFT JOIN drivers d ON d.id = tr.driver_id
    LEFT JOIN (SELECT * FROM users WHERE role = 'Admin' LIMIT 1) u_admin ON 1=1
    LEFT JOIN (SELECT * FROM users WHERE role = 'HR Manager' LIMIT 1) u_hr ON 1=1
    WHERE tr.id = ?";

    $stmt = mysqli_prepare($conn, $email_query);
    if (!$stmt) {
        throw new Exception("Query preparation failed: " . mysqli_error($conn));
    }

    mysqli_stmt_bind_param($stmt, "i", $trip_id);
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Query execution failed: " . mysqli_stmt_error($stmt));
    }

    $result = mysqli_stmt_get_result($stmt);
    if (!$result) {
        throw new Exception("Failed to get result: " . mysqli_error($conn));
    }

    $email_data = mysqli_fetch_assoc($result);
    if (!$email_data) {
        error_log("Trip ID: " . $trip_id . " - No data found");
        throw new Exception("Failed to fetch email data for trip ID: " . $trip_id);
    }

    // Debug log
    error_log("Email data fetched: " . print_r($email_data, true));

    // Default values to prevent null issues
    $managerComment = $email_data['manager_comment'] ?? 'No comment provided';
    $adminComment = $email_data['admin_comment'] ?? 'No comment provided';
    $hrComment = $comment ?? 'No comment provided';
    $driverName = $email_data['driver_name'] ?? 'No driver assigned';
    $driverContact = $email_data['driver_contact'] ?? 'N/A';
    $driverLicense = $email_data['driver_license'] ?? 'N/A';

    // Setup PHPMailer
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;
        $mail->Username   = 'furfectmatch00@gmail.com'; // Move to config
        $mail->Password   = 'hshp joln vbgl yddk'; // Move to config

        $mail->setFrom('furfectmatch00@gmail.com', 'Vehicle Request');

        // Add recipients with validation
        if (!empty($email_data['requestor_email'])) {
            $mail->addAddress($email_data['requestor_email']);
        }
        if (!empty($email_data['manager_email'])) {
            $mail->addAddress($email_data['manager_email']);
        }
        if (!empty($email_data['admin_email'])) {
            $mail->addAddress($email_data['admin_email']);
        }

        // Verify we have at least one valid recipient
        if ($mail->getAllRecipientAddresses() === array()) {
            throw new Exception("No valid email recipients found");
        }

        $mail->Subject = 'Vehicle Request Approved';
        $mail->isHTML(true);
        $mail->Body = "
        <html>
        <head>
            <title>Vehicle Request - Approved</title>
        </head>
        <body style='font-family: Arial, sans-serif; color: #333;'>
            <p><b>Good Day,</b></p>

            <p>The trip request submitted by <b>{$email_data['requestor_name']}</b> has been approved by the HR Manager <b>{$email_data['hr_manager_name']}</b> and is now completed.</p>

            <h3>Approval Details:</h3>
            <p>
                <strong>Requestor Name:</strong> {$email_data['requestor_name']} <br>
                <strong>Manager:</strong> {$email_data['manager_name']} <br>
                <strong>Manager Comment:</strong> {$managerComment} <br>
                <strong>Admin:</strong> {$email_data['admin_name']} <br>
                <strong>Admin Comment:</strong> {$adminComment} <br>
                <strong>HR Manager:</strong> {$email_data['hr_manager_name']} <br>
                <strong>HR Comment:</strong> {$hrComment} <br>
            </p>

            <h3>Vehicle Details:</h3>
            <p>
                <strong>Assigned Vehicle:</strong> {$email_data['assigned_vehicle']} <br>
                <strong>Plate Number:</strong> {$email_data['vehicle_plate']} <br>
                <strong>Status:</strong> In Use <br>
            </p>

            <h3>Driver Details:</h3>
            <p>
                <strong>Driver Name:</strong> {$driverName} <br>
                <strong>Contact Number:</strong> {$driverContact} <br>
                <strong>License Number:</strong> {$driverLicense} <br>
            </p>

            <p>
                <b>You may access this link:</b> 
                <a href='http://localhost/Trip/login.php'>Trip Ticket System</a>
            </p>

            <p><b>IMPORTANT:</b> This is an automated notification. For technical assistance, please contact the IT Help Desk.</p>
        </body>
        </html>";

        $mail->SMTPDebug = 0; // Disable in production
        $mail->send();

    } catch (Exception $e) {
        throw new Exception("Email Error: " . $mail->ErrorInfo);
    }

    mysqli_commit($conn);
    echo json_encode(['status' => 'success', 'message' => 'Request approved successfully']);

} catch (Exception $e) {
    mysqli_rollback($conn);
    error_log("HR Approval Error: " . $e->getMessage());
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
} finally {
    mysqli_close($conn);
}
?>
