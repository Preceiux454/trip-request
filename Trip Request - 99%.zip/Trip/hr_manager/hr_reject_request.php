<?php
session_start();
require_once '../db.php';

header('Content-Type: application/json');

if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'HR Manager') {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized access']);
    exit;
}

try {
    $trip_id = intval($_POST['trip_id']);
    $comment = mysqli_real_escape_string($conn, $_POST['comment']);

    mysqli_begin_transaction($conn);

    // Insert HR manager rejection
    $query = "INSERT INTO approvals (trip_id, approver_role, status, comment) 
              VALUES (?, 'hr', 'Rejected', ?)";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "is", $trip_id, $comment);
    
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Failed to insert approval record: " . mysqli_stmt_error($stmt));
    }

    // Update trip request status
    $update_query = "UPDATE trip_requests SET status = 'Rejected' WHERE id = ?";
    $stmt = mysqli_prepare($conn, $update_query);
    mysqli_stmt_bind_param($stmt, "i", $trip_id);
    
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Failed to update trip request: " . mysqli_stmt_error($stmt));
    }

    mysqli_commit($conn);
    echo json_encode(['status' => 'success', 'message' => 'Request rejected successfully']);

} catch (Exception $e) {
    mysqli_rollback($conn);
    error_log("HR Rejection Error: " . $e->getMessage());
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
} finally {
    mysqli_close($conn);
}