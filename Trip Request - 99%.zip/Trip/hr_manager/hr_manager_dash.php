<?php
session_start();
require_once '../db.php';

// Check if user is logged in and is HR Manager
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'HR Manager') {
    header('Location: ../login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HR Manager Dashboard</title>
    <!-- Include your CSS and JS files -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <script src="../js/dashboard-common.js"></script>
</head>
<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <!-- Include HR Manager sidebar -->
        <?php include 'inc/hr_sidebar.php'; ?>

        <div class="content-wrapper">
            <section class="content-header">
                <div class="container-fluid">
                    <h1>Trip Requests Management</h1>
                </div>
            </section>

            <section class="content">
                <div class="container-fluid">
                    <div class="card">
                        <div class="card-body">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Requestor</th>
                                        <th>Department</th>
                                        <th>Date Needed</th>
                                        <th>Manager</th>
                                        <th>Admin</th>
                                        <th>HR Manager</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="tripRequestsTable">
                                    <!-- Trip requests will be loaded here -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <!-- Include the shared modal -->
    <?php include '../inc/trip_details_modal.php'; ?>

    <!-- Loading Indicator -->
    <div id="loadingIndicator" style="display:none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);">
        <div class="spinner-border text-primary" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>

    <!-- Scripts in correct order -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/js/adminlte.min.js"></script>
    <script src="../js/dashboard-common.js"></script>
    <script src="../js/modal-handler.js"></script>
    <script>
        // Add refresh interval (5 minutes)
        const REFRESH_INTERVAL = 50000;
        let refreshTimer;

        // Helper function for date formatting
        function formatDate(dateString) {
            return dateString ? new Date(dateString).toLocaleString() : 'N/A';
        }

        // Helper function for status badge colors
        function getStatusBadgeClass(status) {
            switch(status) {
                case 'Approved':
                    return 'badge-success';
                case 'Rejected':
                    return 'badge-danger';
                case 'Admin Approved':
                    return 'badge-info';
                case 'Manager Approved':
                    return 'badge-primary';
                case 'Final Approved':
                    return 'badge-success';
                default:
                    return 'badge-warning';
            }
        }

        $(document).ready(function() {
            // Initialize modal handler
            if (typeof ModalHandler !== 'undefined') {
                ModalHandler.init();
            } else {
                console.error('ModalHandler not loaded');
            }
            
            // Setup dashboard with error handling
            try {
                DashboardManager.setupDashboard({ 
                    loadFunction: loadTripRequests 
                });
            } catch (e) {
                console.error('Dashboard setup error:', e);
            }

            // Setup auto-refresh
            refreshTimer = setInterval(loadTripRequests, REFRESH_INTERVAL);

            // Add manual refresh button handler
            $('#refreshBtn').on('click', function() {
                clearInterval(refreshTimer);
                loadTripRequests();
                refreshTimer = setInterval(loadTripRequests, REFRESH_INTERVAL);
            });
        });

        function loadTripRequests() {
            $('#loadingIndicator').show();
            
            $.ajax({
                url: '../fetch_hr_trips.php',
                method: 'GET',
                dataType: 'json',
                success: function(response) {
                    $('#loadingIndicator').hide();
                    if (response.error) {
                        showToast('Error', response.error, 'error');
                        return;
                    }
                    
                    let tableRows = '';
                    if (response.length === 0) {
                        tableRows = '<tr><td colspan="9" class="text-center">No trip requests found</td></tr>';
                    } else {
                        response.forEach(request => {
                            tableRows += generateTableRow(request);
                        });
                    }
                    
                    $('#tripRequestsTable').fadeOut(200, function() {
                        $(this).html(tableRows).fadeIn(200);
                    });
                },
                error: function(xhr, status, error) {
                    $('#loadingIndicator').hide();
                    showToast('Error', 'Failed to load trip requests', 'error');
                    console.error('AJAX Error:', error);
                }
            });
        }

        function showToast(title, message, icon) {
            Swal.fire({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000,
                title: title,
                text: message,
                icon: icon
            });
        }

        // Update the generateTableRow function to include approval dates
        function generateTableRow(request) {
            return `<tr>
                <td>${request.id}</td>
                <td>${request.requestor_name}</td>
                <td>${request.department}</td>
                <td>${request.date_needed}</td>
                <td>
                    <span class="badge ${getStatusBadgeClass(request.approvers.manager.status)}">
                        ${request.approvers.manager.status}
                    </span><br>
                    <small>${request.approvers.manager.name || 'Not Assigned'}</small>
                    ${request.approvers.manager.approval_date ? 
                        `<br><small class="text-muted">Approved: ${formatDate(request.approvers.manager.approval_date)}</small>` : ''}
                </td>
                <td>
                    <span class="badge ${getStatusBadgeClass(request.approvers.admin.status)}">
                        ${request.approvers.admin.status}
                    </span><br>
                    <small>${request.approvers.admin.name || 'Not Assigned'}</small>
                    ${request.approvers.admin.approval_date ? 
                        `<br><small class="text-muted">Approved: ${formatDate(request.approvers.admin.approval_date)}</small>` : ''}
                </td>
                <td>
                    <span class="badge ${getStatusBadgeClass(request.approvers.hr_manager.status)}">
                        ${request.approvers.hr_manager.status}
                    </span><br>
                    <small>${request.approvers.hr_manager.name || 'Not Assigned'}</small>
                    ${request.approvers.hr_manager.approval_date ? 
                        `<br><small class="text-muted">Approved: ${formatDate(request.approvers.hr_manager.approval_date)}</small>` : ''}
                </td>
                <td>
                    <span class="badge ${getStatusBadgeClass(request.status)}">
                        ${request.status}
                    </span>
                </td>
                <td>
                    <div class="btn-group">
                        <button class="btn btn-sm btn-primary view-trip-btn" data-id="${request.id}">
                            <i class="fas fa-eye"></i> View
                        </button>
                        ${request.status === 'Admin Approved' ? `
                            <button class="btn btn-success btn-sm approve-btn" data-id="${request.id}" title="Approve Request">
                                <i class="fas fa-check"></i> Approve
                            </button>
                            <button class="btn btn-danger btn-sm reject-btn" data-id="${request.id}" title="Reject Request">
                                <i class="fas fa-times"></i> Reject
                            </button>
                        ` : ''}
                    </div>
                </td>
            </tr>`;
        }

        // Update approve button handler with better confirmation
        $(document).on('click', '.approve-btn', function() {
            const tripId = $(this).data('id');
            const requestor = $(this).closest('tr').find('td:eq(1)').text();

            Swal.fire({
                title: `Approve Trip Request for ${requestor}?`,
                input: 'textarea',
                inputLabel: 'Comments',
                inputPlaceholder: 'Enter your approval comments...',
                showCancelButton: true,
                confirmButtonText: 'Approve',
                confirmButtonColor: '#28a745',
                showLoaderOnConfirm: true,
                inputValidator: (value) => {
                    if (!value || !value.trim()) {
                        return 'Please provide approval comments';
                    }
                },
                preConfirm: (comment) => {
                    return $.ajax({
                        url: 'hr_approve_request.php',
                        method: 'POST',
                        data: { trip_id: tripId, comment: comment }
                    }).catch(error => {
                        Swal.showValidationMessage(`Request failed: ${error.responseText}`);
                    });
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    if (result.value.status === 'success') {
                        showToast('Success', 'Request approved successfully', 'success');
                        loadTripRequests();
                    } else {
                        showToast('Error', result.value.message || 'Failed to approve request', 'error');
                    }
                }
            });
        });

        // Similar update for reject button handler
        $(document).on('click', '.reject-btn', function() {
            const tripId = $(this).data('id');
            const requestor = $(this).closest('tr').find('td:eq(1)').text();

            Swal.fire({
                title: `Reject Trip Request for ${requestor}?`,
                input: 'textarea',
                inputLabel: 'Reason for Rejection',
                inputPlaceholder: 'Please provide a reason...',
                showCancelButton: true,
                confirmButtonText: 'Reject',
                confirmButtonColor: '#dc3545',
                showLoaderOnConfirm: true,
                inputValidator: (value) => {
                    if (!value || !value.trim()) {
                        return 'You need to provide a reason for rejection';
                    }
                },
                preConfirm: (comment) => {
                    return $.ajax({
                        url: 'hr_reject_request.php',
                        method: 'POST',
                        data: { trip_id: tripId, comment: comment }
                    }).catch(error => {
                        Swal.showValidationMessage(`Request failed: ${error.responseText}`);
                    });
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    if (result.value.status === 'success') {
                        showToast('Success', 'Request rejected successfully', 'success');
                        loadTripRequests();
                    } else {
                        showToast('Error', result.value.message || 'Failed to reject request', 'error');
                    }
                }
            });
        });
    </script>
</body>
</html>