<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'Manager') {
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

$manager_id = $_SESSION['id'];

$query = "SELECT t.*, u.name as manager_name,
          COALESCE(a.status, 'Pending') as approval_status,
          a.comment as manager_comment
          FROM trip_requests t
          LEFT JOIN users u ON u.id = t.manager_id
          LEFT JOIN approvals a ON a.trip_id = t.id AND a.approver_role = 'manager'
          WHERE t.manager_id = ? 
          AND t.archived = 0"; // Only show non-archived requests

$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $manager_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$trips = [];
while ($row = mysqli_fetch_assoc($result)) {
    $trips[] = [
        'id' => $row['id'],
        'requestor_name' => $row['requestor_name'],
        'department' => $row['department'],
        'date_needed' => date('M d, Y', strtotime($row['date_needed'])),
        'time_needed' => date('h:i A', strtotime($row['time_needed'])),
        'time_return' => !empty($row['time_return']) ? date('h:i A', strtotime($row['time_return'])) : '',
        'route_from' => $row['route_from'],
        'route_to' => $row['route_to'],
        'passengers' => $row['passengers'],
        'purpose' => $row['purpose'],
        'approval_status' => $row['approval_status'],
        'manager_comment' => $row['manager_comment']
    ];
}

echo json_encode($trips);
?>