<?php



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trip Ticket Request</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
          :root {
        --primary: #6366f1;
        --primary-dark: #4f46e5;
        --secondary: #06b6d4;
        --success: #10b981;
        --background: #f8fafc;
    }

    body {
        background: var(--background);
        font-family: 'Inter', sans-serif;
    }

    .card {
        border: none;
        border-radius: 24px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.08);
    }

    .card-header {
        background: linear-gradient(135deg, var(--primary), var(--secondary));
        border-radius: 24px 24px 0 0 !important;
        padding: 2rem;
    }

    .form-control, .form-select {
    border-radius: 12px;
    padding: 0.875rem;
    border: 2px solid #e2e8f0;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.form-control:focus, .form-select:focus {
    border-color: var(--primary);
    box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.1);
    transform: translateY(-2px);
}

.form-label {
    font-weight: 500;
    color: #475569;
    margin-bottom: 0.75rem;
    transition: color 0.3s ease;
}

.form-control:focus + .form-label,
.form-select:focus + .form-label {
    color: var(--primary);
}

.btn-success {
    background: linear-gradient(135deg, var(--success), #059669);
    border: none;
    border-radius: 12px;
    padding: 1rem 1.5rem;
    font-weight: 600;
    letter-spacing: 0.5px;
    transition: all 0.3s ease;
}

.btn-success:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 25px rgba(16, 185, 129, 0.25);
}

.btn-success:active {
    transform: translateY(-1px);
}
/* Add hover effects for select dropdowns */
.form-select:hover {
    background-color: #f8fafc;
    cursor: pointer;
}

/* Add icon animations */
.fas {
    transition: transform 0.3s ease;
}

.form-control:focus + label .fas,
.form-select:focus + label .fas {
    transform: scale(1.2);
    color: var(--primary);
}


.section-heading {
    transition: all 0.3s ease;
}

.section-heading.completed {
    background: linear-gradient(135deg, var(--success), #059669);
}

.section-heading.completed .section-number {
    background: rgba(255, 255, 255, 0.4);
}

.section-heading.completed::after {
    content: '✓';
    margin-left: auto;
    font-weight: bold;
}

/* Animated section transitions */
.section-heading {
    animation: slideIn 0.5s ease-out;
}

  /* Logo container styles */
  .logo-container {
        max-width: 150px; /* Adjust this value to make logo smaller/larger */
        margin: 0 auto 1rem;
    }

    .logo-container img {
        width: 100%;
        height: auto;
        object-fit: contain;
    }


@keyframes slideIn {
    from {
        opacity: 0;
        transform: translateX(-20px);
    }
    to {
        opacity: 1;
        transform: translateX(0);
    }
}
@media (max-width: 768px) {
    .container {
        padding: 1rem;
    }
    
    .card {
        border-radius: 16px;
    }
    
    .card-header {
        padding: 1.5rem;
    }
    
    .row {
        margin-bottom: 1rem;
    }
    
    .col-md-4, .col-md-6 {
        margin-bottom: 1rem;
    }
}

/* Step Indicator Styles */
.section-heading {
    background: linear-gradient(135deg, var(--primary), var(--secondary));
    color: white;
    padding: 0.75rem 1.25rem;
    border-radius: 12px;
    margin-bottom: 1.5rem;
    display: flex;
    align-items: center;
    gap: 1rem;
}

.section-number {
    background: rgba(255, 255, 255, 0.2);
    width: 30px;
    height: 30px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    font-weight: 600;
}

.progress-container {
    margin: 2rem 0;
    padding: 0 1rem;
}

.progress {
    height: 6px;
    background-color: #e2e8f0;
    border-radius: 999px;
}

.progress-bar {
    transition: width 0.4s ease;
    background: linear-gradient(135deg, var(--primary), var(--secondary));
}
    </style>
</head>
<body>
    <div class="container mt-5 mb-5">
        <div class="card shadow-lg">
            <div class="card-header">
                <div class="logo-container">
                    <img src="img/logo.png" alt="Company Logo" class="img-fluid">
                </div>
                <h4 class="text-center text-white mb-0">VEHICLE </h4>
            </div>
            <div class="card-body p-4">
                <!-- Progress Bar -->
                <div class="progress-container">
                    <div class="progress">
                        <div class="progress-bar" role="progressbar" style="width: 0%"></div>
                    </div>
                </div>

                <form id="tripRequestForm">
                    <!-- Section 1: Personal Information -->
                    <div class="section-heading">
                        <span class="section-number">1</span>
                        <h5 class="mb-0">Personal Information</h5>
                    </div>
                    <!-- Personal Information Section -->
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label"><i class="fas fa-user me-2"></i>Name:</label>
                                <input type="text" name="requestor_name" class="form-control" required>
                            </div>
                            <!-- Added Email field -->
                            <div class="mb-3">
                                <label class="form-label"><i class="fas fa-envelope me-2"></i>Email:</label>
                                <input type="email" name="requestor_email" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label"><i class="fas fa-building me-2"></i>Department:</label>
                                <select name="department" class="form-select" required>
                                <option value="" disabled="disabled">Choose your Department:</option>
                                    <option value="CRD">Customer Relations Department</option>
                                    <option value="FAD">Finance and Accounting Department</option>
                                    <option value="HRAD">Human Resources and Admin Department</option>
                                    <option value="PD">Parts Department</option>
                                    <option value="SD">Service Department</option>
                                    <option value="VSD">Vehicle Sales Department</option>
                                    <option value="TSURE">TSURE</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <!-- Manager Selection -->
                    <div class="mb-4">
                        <label class="form-label"><i class="fas fa-user-tie me-2" ></i>Choose Manager:</label>
                        <select name="manager_id" class="form-select" required>
                            <option value=""  disabled="disabled">Select your Manager:</option>
                            <?php
                            require 'db.php';
                            $manager_query = "SELECT id, name FROM users WHERE role = 'Manager' ORDER BY name";
                            $manager_result = mysqli_query($conn, $manager_query);

                            if ($manager_result) {
                                while ($manager = mysqli_fetch_assoc($manager_result)) {
                                    echo "<option value='" . $manager['id'] . "'>" . htmlspecialchars($manager['name']) . "</option>";
                                }
                            }
                            mysqli_close($conn);
                            ?>
                        </select>
                    </div>

                    <!-- Section 2: Trip Schedule -->
                    <div class="section-heading">
                        <span class="section-number">2</span>
                        <h5 class="mb-0">Trip Schedule</h5>
                    </div>
                    <!-- Date and Time Section -->
                    <div class="row mb-4">
                        <div class="col-md-4">
                            <label class="form-label"><i class="fas fa-calendar me-2"></i>Date Needed:</label>
                            <input type="date" name="date_needed" class="form-control" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label"><i class="fas fa-clock me-2"></i>Time Needed:</label>
                            <select name="time_needed" class="form-select" required>
                                <option value="">Select Time Needed</option>
                                <option value="06:00">06:00 AM</option>
                                <option value="06:30">06:30 AM</option>
                                <option value="07:00">07:00 AM</option>
                                <option value="07:30">07:30 AM</option>
                                <option value="08:00">08:00 AM</option>
                                <option value="08:30">08:30 AM</option>
                                <option value="09:00">09:00 AM</option>
                                <option value="09:30">09:30 AM</option>
                                <option value="10:00">10:00 AM</option>
                                <option value="10:30">10:30 AM</option>
                                <option value="11:00">11:00 AM</option>
                                <option value="11:30">11:30 AM</option>
                                <option value="12:00">12:00 PM</option>
                                <option value="12:30">12:30 PM</option>
                                <option value="13:00">01:00 PM</option>
                                <option value="13:30">01:30 PM</option>
                                <option value="14:00">02:00 PM</option>
                                <option value="14:30">02:30 PM</option>
                                <option value="15:00">03:00 PM</option>
                                <option value="15:30">03:30 PM</option>
                                <option value="16:00">04:00 PM</option>
                                <option value="16:30">04:30 PM</option>
                                <option value="17:00">05:00 PM</option>
                                <option value="17:30">05:30 PM</option>
                                <option value="18:00">06:00 PM</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label"><i class="fas fa-clock me-2"></i>Time of Return:</label>
                            <select name="time_return" class="form-select">
                                <option value="">Select Time of Return</option>
                                <option value="06:00">06:00 AM</option>
                                <option value="06:30">06:30 AM</option>
                                <option value="07:00">07:00 AM</option>
                                <option value="07:30">07:30 AM</option>
                                <option value="08:00">08:00 AM</option>
                                <option value="08:30">08:30 AM</option>
                                <option value="09:00">09:00 AM</option>
                                <option value="09:30">09:30 AM</option>
                                <option value="10:00">10:00 AM</option>
                                <option value="10:30">10:30 AM</option>
                                <option value="11:00">11:00 AM</option>
                                <option value="11:30">11:30 AM</option>
                                <option value="12:00">12:00 PM</option>
                                <option value="12:30">12:30 PM</option>
                                <option value="13:00">01:00 PM</option>
                                <option value="13:30">01:30 PM</option>
                                <option value="14:00">02:00 PM</option>
                                <option value="14:30">02:30 PM</option>
                                <option value="15:00">03:00 PM</option>
                                <option value="15:30">03:30 PM</option>
                                <option value="16:00">04:00 PM</option>
                                <option value="16:30">04:30 PM</option>
                                <option value="17:00">05:00 PM</option>
                                <option value="17:30">05:30 PM</option>
                                <option value="18:00">06:00 PM</option>
                            </select>
                        </div>
                    </div>

                    <!-- Section 3: Route Details -->
                    <div class="section-heading">
                        <span class="section-number">3</span>
                        <h5 class="mb-0">Route Information</h5>
                    </div>
                    <!-- Route Information -->
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <label class="form-label"><i class="fas fa-map-marker-alt me-2"></i>Planned Route From:</label>
                            <input type="text" name="route_from" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label"><i class="fas fa-map-marker me-2"></i>Planned Route To:</label>
                            <input type="text" name="route_to" class="form-control" required>
                        </div>
                    </div>

                    <!-- Section 4: Additional Details -->
                    <div class="section-heading">
                        <span class="section-number">4</span>
                        <h5 class="mb-0">Trip Details</h5>
                    </div>
                    <!-- Additional Details -->
                    <div class="mb-4">
                        <label class="form-label"><i class="fas fa-users me-2"></i>Passengers:</label>
                        <input type="text" name="passengers" class="form-control">
                    </div>

                    <div class="mb-4">
                        <label class="form-label"><i class="fas fa-clipboard me-2"></i>Purpose of Trip:</label>
                        <textarea name="purpose" class="form-control" rows="3" required></textarea>
                    </div>

                    <!-- Section 5: Vehicle Information -->
                    <div class="section-heading">
                        <span class="section-number">5</span>
                        <h5 class="mb-0">Vehicle Details</h5>
                    </div>
                    <!-- Company Vehicle Selection -->
                    <div class="mb-4">
                        <label class="form-label"><i class="fas fa-car me-2"></i>Company Vehicle with Driver?</label>
                        <select name="company_vehicle" class="form-select">
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                        </select>
                    </div>
                    <!-- New Self Driven Field, displayed only if Company Vehicle is No -->
                    <div class="mb-4" id="selfDrivenContainer" style="display:none;">
                        <label class="form-label"><i class="fas fa-car-side me-2"></i>Company Vehicle Self Driven:</label>
                        <select name="self_driven" class="form-select">
                            <option value="Yes">Yes</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-success w-100">
                        <i class="fas fa-paper-plane me-2"></i>Submit Request
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
       $(document).ready(function() {
    $("#tripRequestForm").submit(function(event) {
        event.preventDefault(); // Prevent default form submission

        let formData = $(this).serialize();
        console.log("Sending data:", formData); // Debugging: See what data is sent

        $.ajax({
            url: "submit_request.php",
            type: "POST",
            data: formData,
            dataType: "json",
            success: function(response) {
                console.log("Server response:", response); // Debugging: See response from PHP
                if (response.status === "success") {
                    Swal.fire({
                        icon: "success",
                        title: "Success!",
                        text: response.message
                    }).then(() => {
                        location.reload(); // Reload page on success
                    });
                } else {
                    Swal.fire({
                        icon: "error",
                        title: "Error!",
                        text: response.message
                    });
                }
            },
            error: function(xhr, status, error) {
                console.error("AJAX error:", xhr.responseText); // Debugging: Show detailed error
                Swal.fire({
                    icon: "error",
                    title: "AJAX Error",
                    text: "Check console for details"
                });
            }
        });
    });

    // Toggle self_driven field based on company_vehicle value
    $('select[name="company_vehicle"]').change(function() {
        if ($(this).val() === "No") {
            $("#selfDrivenContainer").show();
        } else {
            $("#selfDrivenContainer").hide();
        }
    });
});

// Track form progress
const totalSections = 5;
let completedSections = 0;

function updateProgress() {
    const progress = (completedSections / totalSections) * 100;
    $('.progress-bar').css('width', progress + '%');
}

// Monitor input changes in each section
$('.card-body').on('change', 'input, select, textarea', function() {
    const section = $(this).closest('.section-heading').nextUntil('.section-heading');
    const sectionInputs = section.find('input, select, textarea').filter('[required]');
    const sectionComplete = Array.from(sectionInputs).every(input => input.value);
    
    if (sectionComplete) {
        completedSections++;
        updateProgress();
        
        // Animate section completion
        $(this).closest('.section-heading')
            .addClass('completed')
            .css('transform', 'translateX(10px)')
            .animate({transform: 'translateX(0)'}, 300);
    }
});

// Add floating labels animation
$('.form-control, .form-select').on('focus blur', function(e) {
    $(this).parents('.form-group').toggleClass('focused', (e.type === 'focus'));
});

// Add to existing script section
function showLoadingState(button) {
    const originalText = button.html();
    button.html('<span class="spinner-border spinner-border-sm me-2"></span>Processing...');
    button.prop('disabled', true);
    return originalText;
}
    </script>

</body>
</html>
