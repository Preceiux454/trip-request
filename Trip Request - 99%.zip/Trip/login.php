<?php
session_start();
require 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    // Use prepared statement for security
    $query = "SELECT * FROM users WHERE email = ? LIMIT 1";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result && mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);
        
        // Verify password
        if (password_verify($password, $user['password'])) {
            // Store user data in session
            $_SESSION['id'] = $user['id'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['email'] = $user['email'];
            
            // Redirect based on role
            switch($user['role']) {
                case 'Manager':
                    header("Location: manager/manager_dash.php");
                    break;
                    case 'Master Admin':
                        header("Location: admin/admin_master_dash.php");
                        break;
                case 'Admin':
                    header("Location: admin_approver/admin_approver.php");
                    break;
                case 'HR Manager':
                    header("Location: hr_manager/hr_manager_dash.php");
                    break;
                default:
                    // Regular users go to index.php
                    header("Location: index.php");
                    break;
            }
            exit();
        } else {
            $error = "Invalid password!";
        }
    } else {
        $error = "User not found!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login to Trip Ticket</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body, html {
            height: 100%;
            margin: 0;
        }
        .login-container {
            display: flex;
            height: 100vh;
        }
        .left-section {
            width: 50%;
            background: #ff5f5f; /* Change this if needed */
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .left-section img {
            max-width: 60%;
            height: auto;
        }
        .right-section {
            width: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #f8f9fa;
        }
        .login-box {
            width: 100%;
            max-width: 400px;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(255, 255, 255, 0.81);
        }
    </style>
</head>
<body>
    <div class="login-container">
        <!-- Left Section (Logo) -->
        <div class="left-section">
            <img src="img/logo.png" alt="Company Logo">
        </div>

        <!-- Right Section (Login Form) -->
        <div class="right-section">
            <div class="login-box">
                <h1 class="text-center mb-4">Login to Trip Ticket</h1>
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Login</button>
                </form>
            </div>
        </div>
    </div>
    
  <?php if (isset($error)): ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: '<?php echo $error; ?>',
        });
    </script>
    <?php endif; ?>
</body>
</html>
