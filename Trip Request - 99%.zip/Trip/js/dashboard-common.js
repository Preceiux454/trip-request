// Clear any previous declarations if they exist
window.DashboardManager = window.DashboardManager || {
    REFRESH_INTERVAL: 5000,

    setupDashboard: function(options = {}) {
        const {
            loadFunction,
            refreshInterval = this.REFRESH_INTERVAL
        } = options;

        // Clear any existing intervals
        if (window.dashboardInterval) {
            clearInterval(window.dashboardInterval);
        }

        // Setup the auto-refresh
        window.dashboardInterval = setInterval(loadFunction, refreshInterval);

        // Set up loading indicators
        $(document).ajaxStart(function() {
            $('#loadingIndicator').show();
        }).ajaxStop(function() {
            $('#loadingIndicator').hide();
        });
    },

    getStatusBadgeClass: function(status) {
        if (!status) return 'badge-secondary';
        
        switch(status.toLowerCase()) {
            case 'approved': return 'badge-success';
            case 'rejected': return 'badge-danger';
            case 'admin approved': return 'badge-info';
            case 'manager approved': return 'badge-primary';
            case 'final approved': return 'badge-success';
            case 'pending': return 'badge-warning';
            default: return 'badge-secondary';
        }
    }
};