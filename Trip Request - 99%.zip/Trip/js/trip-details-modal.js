/**
 * Trip Details Modal Handler
 * This script handles the fetching and displaying of trip request details in the modal
 */

const TripDetailsModal = {
    /**
     * Initialize the trip details modal functionality
     */
    init: function() {
        console.log('Initializing TripDetailsModal...');
        
        // Debug all view buttons on the page
        this.debugViewButtons();
        
        // Set up event delegation for trip detail links with multiple selectors to catch all buttons
        $(document).on('click', '.view-trip-details, .view-trip-btn, [data-action="view"], .btn-view-trip', function(e) {
            e.preventDefault();
            e.stopPropagation(); // Prevent event bubbling
            
            const tripId = $(this).data('id');
            console.log('Trip details requested for ID:', tripId);
            
            // Debug the clicked element
            console.log('Clicked element:', this);
            console.log('Element data attributes:', $(this).data());
            
            if (!tripId) {
                console.error("No trip ID found on clicked element:", this);
                alert("Error: Could not determine trip ID. Please try again.");
                return;
            }
            
            TripDetailsModal.loadTripDetails(tripId);
        });
        
        // Add direct onclick attribute to all view buttons for redundancy
        this.addOnClickHandlers();
    },
    
    /**
     * Add direct onclick handlers to all view buttons
     */
    addOnClickHandlers: function() {
        $('.view-trip-details, .view-trip-btn, [data-action="view"], .btn-view-trip').each(function() {
            const tripId = $(this).data('id');
            if (tripId) {
                $(this).attr('onclick', `event.preventDefault(); TripDetailsModal.loadTripDetails(${tripId}); return false;`);
            }
        });
    },
    
    /**
     * Debug function to check all view buttons on the page
     */
    debugViewButtons: function() {
        console.log('Debugging all view buttons on the page:');
        
        // Check for view-trip-details buttons
        const viewTripDetails = $('.view-trip-details');
        console.log('Found .view-trip-details buttons:', viewTripDetails.length);
        viewTripDetails.each(function(i) {
            console.log(`Button ${i+1} data-id:`, $(this).data('id'));
        });
        
        // Check for view-trip-btn buttons
        const viewTripBtn = $('.view-trip-btn');
        console.log('Found .view-trip-btn buttons:', viewTripBtn.length);
        viewTripBtn.each(function(i) {
            console.log(`Button ${i+1} data-id:`, $(this).data('id'));
        });
        
        // Check for data-action="view" buttons
        const dataActionView = $('[data-action="view"]');
        console.log('Found [data-action="view"] buttons:', dataActionView.length);
        dataActionView.each(function(i) {
            console.log(`Button ${i+1} data-id:`, $(this).data('id'));
        });
        
        // Check for btn-view-trip buttons
        const btnViewTrip = $('.btn-view-trip');
        console.log('Found .btn-view-trip buttons:', btnViewTrip.length);
        btnViewTrip.each(function(i) {
            console.log(`Button ${i+1} data-id:`, $(this).data('id'));
        });
    },

    /**
     * Format time from 24-hour to 12-hour format
     * @param {string} timeString - Time in 24-hour format (HH:MM)
     * @returns {string} - Time in 12-hour format with AM/PM
     */
    formatTime: function(timeString) {
        if (!timeString) return 'N/A';
        
        // Check if the time is already in 12-hour format (contains AM/PM)
        if (timeString.includes('AM') || timeString.includes('PM')) {
            return timeString;
        }
        
        // Parse the time string
        const timeParts = timeString.split(':');
        if (timeParts.length < 2) return timeString;
        
        let hours = parseInt(timeParts[0], 10);
        const minutes = timeParts[1];
        const ampm = hours >= 12 ? 'PM' : 'AM';
        
        // Convert hours to 12-hour format
        hours = hours % 12;
        hours = hours ? hours : 12; // Convert '0' to '12'
        
        return `${hours}:${minutes} ${ampm}`;
    },

    /**
     * Load trip details from the server
     * @param {number} tripId - The ID of the trip to load
     */
    loadTripDetails: function(tripId) {
        console.log('Loading trip details for ID:', tripId);
        
        // Check if tripId is valid
        if (!tripId) {
            console.error('Invalid trip ID:', tripId);
            alert('Error: Missing trip ID. Please try again or contact support.');
            return;
        }
        
        // Determine the correct path based on the current URL
        let fetchUrl = 'fetch_trip_details.php';
        const currentPath = window.location.pathname;
        console.log('Current path:', currentPath);
        
        if (currentPath.includes('/admin/')) {
            fetchUrl = 'fetch_trip_details.php'; // We're already in admin directory
        } else if (currentPath.includes('/Trip/')) {
            fetchUrl = 'fetch_trip_details.php'; // We're in the root Trip directory
        } else {
            fetchUrl = '../admin/fetch_trip_details.php'; // We're in another directory
        }
        
        console.log('Fetching from URL:', fetchUrl);
        
        $.ajax({
            url: fetchUrl,
            type: 'GET',
            data: { id: tripId },
            dataType: 'json',
            beforeSend: function() {
                console.log('Sending AJAX request for trip ID:', tripId);
            },
            success: function(response) {
                console.log('Received response:', response);
                if (response.error) {
                    console.error('Error in response:', response.error);
                    alert(response.error);
                    return;
                }
                TripDetailsModal.displayTripDetails(response);
                $('#tripDetailsModal').modal('show');
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', error);
                console.error('Status:', status);
                console.error('Response Text:', xhr.responseText);
                
                // Try to parse the response if it's JSON
                try {
                    const errorResponse = JSON.parse(xhr.responseText);
                    console.error('Parsed error response:', errorResponse);
                    if (errorResponse.error) {
                        alert('Error: ' + errorResponse.error);
                        return;
                    }
                } catch (e) {
                    console.error('Could not parse error response as JSON');
                }
                
                alert('Failed to load trip details. Please try again.');
            }
        });
    },

    /**
     * Display trip details in the modal
     * @param {Object} tripData - The trip data to display
     */
    displayTripDetails: function(tripData) {
        console.log('Displaying trip details:', tripData);
        
        // Clear any previous data
        this.clearModalFields();
        
        // Basic trip information
        $('#modal-requestor').text(tripData.requestor_name || 'N/A');
        $('#modal-requestor_email').text(tripData.requestor_email || 'N/A');
        $('#modal-department').text(tripData.department || 'N/A');
        $('#modal-date').text(tripData.date_needed || 'N/A');
        $('#modal-time').text(this.formatTime(tripData.time_needed) || 'N/A');
        $('#modal-time-return').text(this.formatTime(tripData.time_return) || 'N/A');
        $('#modal-company-vehicle').text(tripData.company_vehicle || 'N/A');
        $('#modal-route-from').text(tripData.route_from || 'N/A');
        $('#modal-route-to').text(tripData.route_to || 'N/A');
        $('#modal-passengers').text(tripData.passengers || 'N/A');
        $('#modal-purpose').text(tripData.purpose || 'N/A');

        // Manager approval information
        const manager = tripData.approvers.manager;
        $('#modal-manager-name').text(manager.name || 'Not Assigned');
        $('#modal-manager-role').text(manager.role || 'Manager');
        
        // Use our own getStatusBadgeClass function if DashboardManager is not available
        const getStatusClass = (typeof DashboardManager !== 'undefined') ? 
            DashboardManager.getStatusBadgeClass : this.getStatusBadgeClass;
        
        const managerStatusClass = getStatusClass(manager.status || 'Pending');
        $('#manager-status-comment').html(`<span class="badge ${managerStatusClass}">${manager.status || 'Pending'}</span>`);
        $('#manager-comment').text(manager.comment || 'No comment provided');
        $('#manager-comment-date').text(manager.date || 'N/A');

        // Admin approval information
        const admin = tripData.approvers.admin;
        $('#modal-admin-name').text(admin.name || 'Not Assigned');
        $('#modal-admin-role').text(admin.role || 'Admin');
        
        const adminStatusClass = getStatusClass(admin.status || 'Pending');
        $('#admin-status-comment').html(`<span class="badge ${adminStatusClass}">${admin.status || 'Pending'}</span>`);
        $('#admin-comment').text(admin.comment || 'No comment provided');
        $('#admin-comment-date').text(admin.date || 'N/A');

        // Vehicle and Driver information (if company vehicle is requested)
        if (tripData.company_vehicle === 'Yes') {
            let vehicleInfo = '';
            let driverInfo = '';
            
            // Add vehicle information if available
            if (admin.vehicle && admin.vehicle.name) {
                vehicleInfo = `
                    <div class="alert alert-info mb-2">
                        <h6 class="mb-2"><i class="fas fa-car mr-2"></i>Vehicle Information</h6>
                        <p class="mb-1"><strong>Vehicle:</strong> ${admin.vehicle.name}</p>
                        <p class="mb-1"><strong>Plate Number:</strong> ${admin.vehicle.plate_number || 'N/A'}</p>
                        <p class="mb-0"><strong>Status:</strong> 
                            <span class="badge ${getStatusClass(admin.vehicle.status)}">${admin.vehicle.status || 'Available'}</span>
                        </p>
                    </div>
                `;
            }
            
            // Add driver information if available
            if (admin.driver && admin.driver.name) {
                driverInfo = `
                    <div class="alert alert-secondary mb-2">
                        <h6 class="mb-2"><i class="fas fa-user mr-2"></i>Driver Information</h6>
                        <p class="mb-1"><strong>Driver:</strong> ${admin.driver.name}</p>
                        <p class="mb-1"><strong>Contact:</strong> ${admin.driver.contact || 'N/A'}</p>
                        <p class="mb-1"><strong>License:</strong> ${admin.driver.license || 'N/A'}</p>
                        <p class="mb-0"><strong>Status:</strong> 
                            <span class="badge ${getStatusClass(admin.driver.status)}">${admin.driver.status || 'Available'}</span>
                        </p>
                    </div>
                `;
            }
            
            // Display the information
            $('#admin-vehicle-info').html(vehicleInfo);
            $('#admin-driver-info').html(driverInfo);
            
            // If no vehicle or driver is assigned yet
            if (!vehicleInfo && !driverInfo) {
                $('#admin-vehicle-info').html('<div class="alert alert-warning">Company vehicle requested but not yet assigned.</div>');
                $('#admin-driver-info').empty();
            }
        } else {
            // No company vehicle requested
            $('#admin-vehicle-info').empty();
            $('#admin-driver-info').empty();
        }

        // HR Manager approval information
        const hr = tripData.approvers.hr_manager;
        $('#modal-hr-name').text(hr.name || 'Not Assigned');
        $('#modal-hr-role').text(hr.role || 'HR Manager');
        
        const hrStatusClass = getStatusClass(hr.status || 'Pending');
        $('#hr-status-comment').html(`<span class="badge ${hrStatusClass}">${hr.status || 'Pending'}</span>`);
        $('#hr-comment').text(hr.comment || 'No comment provided');
        $('#hr-comment-date').text(hr.date || 'N/A');
    },

    /**
     * Clear all modal fields to prevent showing stale data
     */
    clearModalFields: function() {
        // Basic info
        $('#modal-requestor, #modal-requestor_email, #modal-department, #modal-date, #modal-time, #modal-time-return, #modal-company-vehicle, #modal-route-from, #modal-route-to, #modal-passengers, #modal-purpose').text('');
        
        // Manager info
        $('#modal-manager-name, #modal-manager-role, #manager-status-comment, #manager-comment, #manager-comment-date').text('');
        
        // Admin info
        $('#modal-admin-name, #modal-admin-role, #admin-status-comment, #admin-comment, #admin-comment-date').text('');
        $('#admin-vehicle-info, #admin-driver-info').empty();
        
        // HR info
        $('#modal-hr-name, #modal-hr-role, #hr-status-comment, #hr-comment, #hr-comment-date').text('');
    },
    
    /**
     * Get the appropriate badge class for a status
     * @param {string} status - The status value
     * @returns {string} - The CSS class for the badge
     */
    getStatusBadgeClass: function(status) {
        if (!status) return 'badge-secondary';
        
        switch (status.toLowerCase()) {
            case 'approved':
                return 'badge-success';
            case 'rejected':
                return 'badge-danger';
            case 'pending':
                return 'badge-warning';
            case 'in use':
                return 'badge-primary';
            case 'maintenance':
                return 'badge-secondary';
            case 'available':
                return 'badge-info';
            default:
                return 'badge-secondary';
        }
    }
};

// Initialize when document is ready
$(document).ready(function() {
    TripDetailsModal.init();
    
    // Re-initialize on AJAX complete to catch dynamically added buttons
    $(document).ajaxComplete(function() {
        console.log('AJAX request completed, checking for new view buttons...');
        TripDetailsModal.debugViewButtons();
        TripDetailsModal.addOnClickHandlers(); // Add onclick handlers to new buttons
    });
});

// Add a global function for direct HTML onclick attributes
function viewTripDetails(tripId) {
    if (tripId) {
        TripDetailsModal.loadTripDetails(tripId);
        return false;
    }
    return true;
}
