window.ModalHandler = window.ModalHandler || {
    init: function() {
        this.bindViewButtons();
    },

    bindViewButtons: function() {
        $(document).on('click', '.view-trip-btn', function(e) {
            e.preventDefault();
            const tripId = $(this).data('id');
            ModalHandler.loadTripDetails(tripId);
        });
    },

    loadTripDetails: function(tripId) {
        $.ajax({
            url: '../fetch_trip_details.php',
            method: 'GET',
            data: { id: tripId },
            dataType: 'json',
            beforeSend: function() {
                $('#loadingIndicator').show();
            },
            success: function(response) {
                if (response.error) {
                    Swal.fire('Error', response.error, 'error');
                    return;
                }
                ModalHandler.updateModalContent(response);
                $('#tripDetailsModal').modal('show');
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', error);
                Swal.fire('Error', 'Failed to load trip details', 'error');
            },
            complete: function() {
                $('#loadingIndicator').hide();
            }
        });
    },

    updateModalContent: function(data) {
        if (!data) return;
        
        // Basic trip details
        $('#modal-requestor').text(data.requestor_name || 'N/A');
        $('#modal-requestor_email').text(data.requestor_email || 'N/A');
        $('#modal-department').text(data.department || 'N/A');
        $('#modal-date').text(data.date_needed || 'N/A');
        $('#modal-time').text(data.time_needed || 'N/A');
        $('#modal-time-return').text(data.time_return || 'N/A');
        $('#modal-route-from').text(data.route_from || 'N/A');
        $('#modal-route-to').text(data.route_to || 'N/A');
        $('#modal-passengers').text(data.passengers || 'N/A');
        $('#modal-purpose').text(data.purpose || 'N/A');
        $('#modal-company-vehicle').text(data.company_vehicle || 'N/A');
        
        // Update approvers sections
        if (data.approvers) {
            // Manager approval
            this.updateApproverSection('manager', data.approvers.manager);
            
            // Admin approval
            this.updateApproverSection('admin', data.approvers.admin);
            
            // HR Manager approval
            this.updateApproverSection('hr_manager', data.approvers.hr_manager);
        }
    },

    // Update specific approver section
    updateApproverSection: function(role, approver = {}) {
        const statusClass = this.getStatusBadgeClass(approver.status || 'Pending');
        const statusHtml = `<span class="badge ${statusClass}">${approver.status || 'Pending'}</span>`;
        
        // Set approver details based on role
        const rolePrefix = role === 'hr_manager' ? 'hr' : role;
        
        $(`#modal-${rolePrefix}-name`).text(approver.name || 'Not Assigned');
        $(`#modal-${rolePrefix}-role`).text(this.formatRole(role));
        $(`#${rolePrefix}-status-comment`).html(statusHtml);
        $(`#${rolePrefix}-comment`).text(approver.comment || 'No comment provided');
        $(`#${rolePrefix}-comment-date`).text(approver.date || 'N/A');

        // Handle vehicle info for admin
        if (role === 'admin' && approver.vehicle) {
            const vehicleInfo = `
                <p class="mb-1"><strong>Assigned Vehicle:</strong> 
                    ${approver.vehicle.name} (${approver.vehicle.plate_number})
                </p>
                <p class="mb-1"><strong>Vehicle Status:</strong> 
                    <span class="badge badge-info">${approver.vehicle.status}</span>
                </p>
            `;
            $(`#admin-vehicle-info`).html(vehicleInfo);
        }
    },

    getStatusBadgeClass: function(status) {
        switch (status) {
            case 'Approved': return 'badge-success';
            case 'Rejected': return 'badge-danger';
            case 'Pending': return 'badge-warning';
            default: return 'badge-secondary';
        }
    },

    formatRole: function(role) {
        switch (role) {
            case 'manager': return 'Manager';
            case 'admin': return 'Admin';
            case 'hr_manager': return 'HR Manager';
            default: return role;
        }
    }
};

// Initialize the handler
ModalHandler.init();