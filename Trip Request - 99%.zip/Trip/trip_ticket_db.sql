-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 13, 2025 at 06:10 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `trip_ticket_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `approvals`
--

CREATE TABLE `approvals` (
  `id` int(11) NOT NULL,
  `trip_id` int(11) NOT NULL,
  `approver_role` enum('manager','admin','hr') NOT NULL,
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `comment` text DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `approval_date` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `approvals`
--

INSERT INTO `approvals` (`id`, `trip_id`, `approver_role`, `status`, `comment`, `timestamp`, `approval_date`, `created_at`) VALUES
(80, 45, 'manager', 'Approved', 'g', '2025-03-12 13:54:55', NULL, '2025-03-12 13:55:06'),
(81, 45, 'admin', 'Approved', 'g', '2025-03-12 13:55:24', NULL, '2025-03-12 13:55:24'),
(82, 46, 'manager', 'Approved', 'dain', '2025-03-12 13:56:03', NULL, '2025-03-12 13:56:44'),
(83, 46, 'admin', 'Approved', 'GGG', '2025-03-12 13:57:03', NULL, '2025-03-12 13:57:03'),
(84, 47, 'manager', 'Approved', 'g', '2025-03-12 14:03:17', NULL, '2025-03-12 14:03:30'),
(85, 46, 'hr', 'Approved', 'g', '2025-03-12 14:05:29', NULL, '2025-03-12 14:05:29'),
(86, 45, 'hr', 'Approved', 'g', '2025-03-12 14:05:32', NULL, '2025-03-12 14:05:32'),
(87, 47, 'admin', 'Approved', 'g', '2025-03-12 14:06:20', NULL, '2025-03-12 14:06:20'),
(88, 47, 'hr', 'Approved', 'g', '2025-03-12 14:06:40', NULL, '2025-03-12 14:06:40'),
(89, 48, 'manager', 'Approved', 's', '2025-03-12 14:34:32', NULL, '2025-03-12 15:26:04'),
(90, 49, 'manager', 'Approved', 'd', '2025-03-12 14:35:25', NULL, '2025-03-12 15:26:08'),
(91, 50, 'manager', 'Approved', '', '2025-03-12 14:59:55', NULL, '2025-03-12 15:26:10'),
(92, 50, 'admin', 'Approved', 'sd', '2025-03-12 15:26:33', NULL, '2025-03-12 15:26:33'),
(93, 49, 'admin', 'Approved', 'sd', '2025-03-12 15:26:37', NULL, '2025-03-12 15:26:37'),
(94, 48, 'admin', 'Approved', 'asd', '2025-03-12 15:26:40', NULL, '2025-03-12 15:26:40'),
(95, 50, 'hr', 'Approved', 's', '2025-03-12 15:27:11', NULL, '2025-03-12 15:27:11'),
(96, 51, 'manager', 'Approved', 'iok', '2025-03-12 19:02:30', NULL, '2025-03-12 19:11:51'),
(97, 51, 'admin', 'Approved', 'go', '2025-03-12 19:13:37', NULL, '2025-03-12 19:13:37'),
(98, 48, 'hr', 'Approved', 'gho', '2025-03-12 19:15:24', NULL, '2025-03-12 19:15:24'),
(99, 52, 'manager', 'Approved', 'Go 123', '2025-03-12 19:47:54', NULL, '2025-03-13 05:11:23'),
(100, 53, 'manager', 'Approved', 'GGG', '2025-03-12 19:51:10', NULL, '2025-03-13 07:16:26'),
(101, 54, 'manager', 'Approved', 'G', '2025-03-13 04:14:02', NULL, '2025-03-13 08:12:32'),
(102, 55, 'manager', 'Approved', 'GGGG', '2025-03-13 04:25:55', NULL, '2025-03-13 08:14:06'),
(103, 52, 'admin', 'Approved', 'Go 1234', '2025-03-13 05:11:56', NULL, '2025-03-13 05:11:56'),
(104, 53, 'admin', 'Approved', 'G', '2025-03-13 07:16:52', NULL, '2025-03-13 07:16:52'),
(105, 53, 'hr', 'Approved', 'GGGGGGGGGGG', '2025-03-13 07:17:21', NULL, '2025-03-13 07:17:21'),
(106, 54, 'admin', 'Approved', '123', '2025-03-13 08:13:05', NULL, '2025-03-13 08:13:05'),
(107, 55, 'admin', 'Approved', 'Go birsd', '2025-03-13 08:14:38', NULL, '2025-03-13 08:14:38'),
(108, 55, 'hr', 'Approved', 'GOOOOOOOOOOO', '2025-03-13 08:15:42', NULL, '2025-03-13 08:15:42'),
(109, 56, 'manager', 'Approved', 'G', '2025-03-13 09:11:59', NULL, '2025-03-13 09:12:09'),
(110, 56, 'admin', 'Approved', 'g', '2025-03-13 09:12:32', NULL, '2025-03-13 09:12:32'),
(111, 56, 'hr', 'Approved', 'F', '2025-03-13 09:18:22', NULL, '2025-03-13 09:18:22'),
(112, 54, 'hr', 'Approved', 'ggg', '2025-03-13 09:18:26', NULL, '2025-03-13 09:18:26'),
(113, 52, 'hr', 'Approved', 'gg', '2025-03-13 09:18:28', NULL, '2025-03-13 09:18:28'),
(114, 51, 'hr', 'Approved', 'jjj', '2025-03-13 09:18:31', NULL, '2025-03-13 09:18:31'),
(115, 49, 'hr', 'Approved', 'kkkkkkkkkkkk', '2025-03-13 09:18:34', NULL, '2025-03-13 09:18:34'),
(116, 57, 'manager', 'Approved', 'g', '2025-03-13 09:32:48', NULL, '2025-03-13 09:34:52'),
(117, 58, 'manager', 'Approved', 'TEETTS2', '2025-03-13 09:37:15', NULL, '2025-03-13 09:37:21'),
(118, 59, 'manager', 'Approved', 'g', '2025-03-13 09:39:07', NULL, '2025-03-13 09:39:25'),
(119, 60, 'manager', 'Approved', 'g', '2025-03-13 09:40:18', NULL, '2025-03-13 09:41:10'),
(120, 61, 'manager', 'Approved', 'ghfgh', '2025-03-13 09:42:05', NULL, '2025-03-13 09:48:13'),
(121, 62, 'manager', 'Approved', 'kkkk', '2025-03-13 09:46:07', NULL, '2025-03-13 09:48:09'),
(122, 63, 'manager', 'Pending', NULL, '2025-03-13 10:08:18', NULL, '2025-03-13 10:08:18'),
(123, 64, 'manager', 'Approved', 'gs', '2025-03-13 11:25:03', NULL, '2025-03-13 11:59:05'),
(124, 64, 'admin', 'Approved', 'g', '2025-03-13 11:55:44', NULL, '2025-03-13 11:55:44'),
(125, 64, 'hr', 'Approved', 'go go', '2025-03-13 11:56:05', NULL, '2025-03-13 11:56:05'),
(126, 65, 'manager', 'Pending', NULL, '2025-03-13 12:24:30', NULL, '2025-03-13 12:24:30'),
(127, 66, 'manager', 'Pending', NULL, '2025-03-13 12:39:51', NULL, '2025-03-13 12:39:51'),
(128, 67, 'manager', 'Pending', NULL, '2025-03-13 12:49:06', NULL, '2025-03-13 12:49:06'),
(129, 68, 'manager', 'Approved', 'g', '2025-03-13 12:55:55', NULL, '2025-03-13 13:40:28'),
(130, 69, 'manager', 'Approved', 'GGGGGGGGGGG', '2025-03-13 13:01:42', NULL, '2025-03-13 13:34:21'),
(131, 70, 'manager', 'Approved', 'k', '2025-03-13 13:07:29', NULL, '2025-03-13 13:29:53'),
(132, 71, 'manager', 'Approved', 'gio', '2025-03-13 13:12:00', NULL, '2025-03-13 13:23:34'),
(133, 71, 'admin', 'Approved', 'g', '2025-03-13 13:46:41', NULL, '2025-03-13 13:46:41'),
(134, 70, 'admin', 'Approved', 'd', '2025-03-13 13:54:25', NULL, '2025-03-13 13:54:25'),
(135, 70, 'hr', 'Approved', 'yey', '2025-03-13 14:01:49', NULL, '2025-03-13 14:01:49'),
(136, 71, 'hr', 'Approved', 'g', '2025-03-13 14:03:00', NULL, '2025-03-13 14:03:00'),
(137, 58, 'admin', 'Approved', 'G', '2025-03-13 14:09:24', NULL, '2025-03-13 14:09:24'),
(138, 58, 'hr', 'Approved', 'k', '2025-03-13 14:09:42', NULL, '2025-03-13 14:09:42'),
(139, 69, 'admin', 'Approved', 'G', '2025-03-13 14:20:14', NULL, '2025-03-13 14:20:14'),
(140, 69, 'hr', 'Approved', 'GGGGGGGGGGGGGG', '2025-03-13 14:20:27', NULL, '2025-03-13 14:20:27'),
(141, 57, 'admin', 'Approved', 'g', '2025-03-13 14:21:03', NULL, '2025-03-13 14:21:03'),
(142, 57, 'hr', 'Approved', 'g', '2025-03-13 14:21:15', NULL, '2025-03-13 14:21:15'),
(143, 68, 'admin', 'Approved', 'GGGGGGG', '2025-03-13 14:26:33', NULL, '2025-03-13 14:26:33'),
(144, 68, 'hr', 'Approved', 'pls na', '2025-03-13 14:26:46', NULL, '2025-03-13 14:26:46'),
(145, 62, 'admin', 'Approved', 'd', '2025-03-13 14:28:06', NULL, '2025-03-13 14:28:06'),
(147, 61, 'admin', 'Approved', 'FFF', '2025-03-13 14:37:56', NULL, '2025-03-13 14:37:56'),
(160, 72, 'manager', 'Approved', 'G', '2025-03-13 16:36:33', NULL, '2025-03-13 16:37:31'),
(161, 72, 'admin', 'Approved', 'GG', '2025-03-13 16:39:15', NULL, '2025-03-13 16:39:15'),
(170, 72, '', 'Approved', 'g', '2025-03-13 17:09:13', NULL, '2025-03-13 17:09:13');

-- --------------------------------------------------------

--
-- Table structure for table `trip_archives`
--

CREATE TABLE `trip_archives` (
  `archive_id` int(11) NOT NULL,
  `trip_id` int(11) NOT NULL,
  `approver_id` int(11) NOT NULL,
  `approver_role` enum('Manager','Admin','HR Manager') NOT NULL,
  `archived_date` datetime DEFAULT current_timestamp(),
  `archive_status` varchar(50) NOT NULL,
  `archive_comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trip_archives`
--

INSERT INTO `trip_archives` (`archive_id`, `trip_id`, `approver_id`, `approver_role`, `archived_date`, `archive_status`, `archive_comment`) VALUES
(1, 57, 19, 'Manager', '2025-03-13 17:34:52', 'Approved', 'g'),
(2, 58, 19, 'Manager', '2025-03-13 17:37:21', 'Approved', 'TEETTS2'),
(3, 59, 19, 'Manager', '2025-03-13 17:39:25', 'Approved', 'g'),
(4, 60, 19, 'Manager', '2025-03-13 17:41:10', 'Approved', 'g'),
(5, 60, 19, 'Manager', '2025-03-13 17:54:02', 'Archived', 'Archived by manager'),
(6, 59, 19, 'Manager', '2025-03-13 17:57:13', 'Archived', 'Archived by manager'),
(7, 45, 19, 'Manager', '2025-03-13 17:59:51', 'Archived', 'Archived by manager'),
(8, 58, 19, 'Manager', '2025-03-13 18:00:04', 'Archived', 'Archived by manager'),
(9, 55, 19, 'Manager', '2025-03-13 18:00:12', 'Archived', 'Archived by manager');

-- --------------------------------------------------------

--
-- Table structure for table `trip_requests`
--

CREATE TABLE `trip_requests` (
  `id` int(11) NOT NULL,
  `requestor_name` varchar(255) NOT NULL,
  `requestor_email` varchar(255) NOT NULL,
  `department` enum('CRD','FAD','HRAD','PD','SD','VSD','TSURE') NOT NULL,
  `manager_id` int(11) NOT NULL,
  `date_needed` date NOT NULL,
  `time_needed` time NOT NULL,
  `time_return` time NOT NULL,
  `route_from` varchar(255) NOT NULL,
  `route_to` varchar(255) NOT NULL,
  `passengers` text NOT NULL,
  `purpose` text NOT NULL,
  `company_vehicle` enum('Yes','No') NOT NULL,
  `status` enum('Pending','Manager Approved','Admin Approved','Rejected') DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `vehicle_id` int(11) DEFAULT NULL,
  `archived` tinyint(1) DEFAULT 0,
  `archive_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trip_requests`
--

INSERT INTO `trip_requests` (`id`, `requestor_name`, `requestor_email`, `department`, `manager_id`, `date_needed`, `time_needed`, `time_return`, `route_from`, `route_to`, `passengers`, `purpose`, `company_vehicle`, `status`, `created_at`, `vehicle_id`, `archived`, `archive_date`) VALUES
(45, 'Test1', '', '', 19, '2025-03-14', '21:57:00', '09:54:00', 'Santa', 'Rosies', 'Dee', 'dd', 'Yes', '', '2025-03-12 13:54:55', NULL, 0, NULL),
(46, 'Lalong Tumatamis', '', '', 14, '2025-03-13', '09:55:00', '21:56:00', 'Santa Rosa ', 'Calamba', 'assa', 'assa', 'Yes', '', '2025-03-12 13:56:03', NULL, 0, NULL),
(47, 'ikaw at ikaw', '', '', 19, '2025-03-06', '22:04:00', '10:03:00', 'Santa', 's', 's', 's', 'Yes', '', '2025-03-12 14:03:17', NULL, 0, NULL),
(48, 'Lalong Tumatamis', 'masteradmin@tsr.local', '', 19, '2025-03-13', '14:30:00', '14:30:00', 'Lalong Tumatamis', 'ROsyz', 'Arvs, Missy  , John', 'asd', 'Yes', '', '2025-03-12 14:34:32', NULL, 0, NULL),
(49, 'Lalong Tumatamis', 'johnarvie454@gmail.com', '', 19, '2025-03-13', '14:30:00', '14:30:00', 'A', 'A', 'a', 'a', 'Yes', '', '2025-03-12 14:35:25', NULL, 0, NULL),
(50, 'Test 3', 'john@john.com', 'TSURE', 19, '2025-03-14', '14:00:00', '14:30:00', 'Santa', 'ROsyz', 'sada', 'asd', 'Yes', '', '2025-03-12 14:59:55', NULL, 0, NULL),
(51, 'Arvs', 'masteradmin@tsr.local', 'FAD', 19, '2025-03-06', '14:30:00', '14:30:00', 'ooo', 'kkj', 'asdas', 'kk', 'Yes', '', '2025-03-12 19:02:30', NULL, 0, NULL),
(52, 'Lalong Tumatamis', 'johnarvie454@gmail.com', 'CRD', 19, '2025-04-04', '14:00:00', '14:30:00', 'Santa', 'Calamba', 'Lalong Tumatamis', 'sad', 'Yes', '', '2025-03-12 19:47:53', NULL, 0, NULL),
(53, 'Lalong Tumatamis', 'masteradmin@tsr.local', 'FAD', 19, '2025-03-21', '15:00:00', '15:00:00', 'Santa', 'ROsyz', 'Arvs, Missy  , John', 'asd', 'Yes', '', '2025-03-12 19:51:10', NULL, 0, NULL),
(54, 'Lalong Tumatamis', 'arvsss@gmail.com', 'CRD', 19, '2025-03-14', '15:00:00', '14:30:00', 'Santa', 'Calamba', 'Lalong Tumatamis', 'ad', 'No', '', '2025-03-13 04:14:02', 24, 0, NULL),
(55, 'Lalong Tumatamis SR.', 'arvsss@gmail.com', 'CRD', 19, '2025-03-14', '14:30:00', '14:30:00', 'Santa', 'Calamba', 'Lalong Tumatamis', 'k', 'No', '', '2025-03-13 04:25:55', 25, 0, NULL),
(56, 'Mag Numb', 'magnumb@gmail.com', 'TSURE', 19, '2025-03-14', '15:00:00', '14:00:00', 'New York', 'Calamba', 'Lalong Tumatamis', 'Secrett', 'Yes', '', '2025-03-13 09:11:59', 26, 0, NULL),
(57, 'TEST123', 'TEST123@gmail.com', 'PD', 19, '2025-03-14', '14:30:00', '15:00:00', 'TEST123', 'TEST123', 'TEST123', 'TEST123', 'No', '', '2025-03-13 09:32:48', 32, 1, '2025-03-13 17:34:52'),
(58, 'TEETTS2', 'TEETTS2@TEETTS2.com', 'FAD', 19, '2025-03-28', '14:30:00', '15:00:00', 'Santa', 'Calamba', 'TEETTS2', 'TEETTS2', 'Yes', '', '2025-03-13 09:37:15', 30, 1, '2025-03-13 17:37:21'),
(59, 'g', 'gTEETTS2@asd.casd', 'CRD', 19, '2025-03-21', '14:30:00', '14:30:00', 'Santa', 'ROsyz', 'Arvs, Missy  , John', 'asd', 'Yes', '', '2025-03-13 09:39:07', NULL, 1, '2025-03-13 17:39:25'),
(60, 'g', 'arvsss@gmail.coms', 'CRD', 19, '2025-03-15', '15:00:00', '15:00:00', 'Lalong Tumatamis', 'ROsyz', 'asa', 'asd', 'Yes', '', '2025-03-13 09:40:18', NULL, 1, '2025-03-13 17:41:10'),
(61, 'asdasdad', 'TEST123s@gmail.com', 'FAD', 8, '2025-03-14', '15:00:00', '15:00:00', 'asdasd', 'asdad', 'asd', 'asdasd', 'Yes', 'Admin Approved', '2025-03-13 09:42:04', 35, 0, NULL),
(62, 'Lalong Tumatamiss na kitaaa', 'arvsss@gmail.com', 'TSURE', 8, '2025-04-04', '14:30:00', '14:30:00', 'Lalong Tumatamis', 'Calamba', 'Arvs, Missy  , John', 'asd', 'Yes', 'Admin Approved', '2025-03-13 09:46:07', 34, 0, NULL),
(63, 'Mizy', 'misz@gmail.cm', 'PD', 15, '2025-03-15', '14:30:00', '15:00:00', 'Secret', 'Calamba', 'Secret', 'Secret', 'Yes', 'Pending', '2025-03-13 10:08:18', NULL, 0, NULL),
(64, 'Al James', 'aljames@tsr.local', 'FAD', 19, '2025-03-14', '14:30:00', '15:00:00', 'BGC Manila', 'Calamba New York City', 'Lalong Tumatamis', 'Unwind', 'Yes', '', '2025-03-13 11:25:03', 27, 0, NULL),
(65, 'asdas', 'magnumb@gmail.com', 'FAD', 19, '2025-03-06', '14:30:00', '15:00:00', 'asda', 'asd', 'asd', 'as', 'Yes', 'Pending', '2025-03-13 12:24:30', NULL, 0, NULL),
(66, 'Gusto ko Sakin Ka lang', 'akinkalang@gmail.com', 'FAD', 19, '2025-03-21', '14:00:00', '14:30:00', 'Santa Rosa ', 'asdasda', 'Gusto ko Sakin Ka lang', 'Gusto ko Sakin Ka lang', 'Yes', 'Pending', '2025-03-13 12:39:51', NULL, 0, NULL),
(67, 'Sakin ka parin babalik', 'akin@kalang.com', 'FAD', 19, '2025-03-31', '15:00:00', '15:00:00', 'Secret', 'Secret', 'Secret', 'Secret', 'Yes', 'Pending', '2025-03-13 12:49:06', NULL, 0, NULL),
(68, 'Mr. Dito Ka Sa Akin 2', 'arvsss@gmail.com', 'FAD', 19, '2025-03-28', '14:30:00', '14:30:00', 'Lalong Tumatamis', '</strong> ', '</strong> ', '</strong> ', 'Yes', '', '2025-03-13 12:55:55', 33, 0, NULL),
(69, 'Mr. Pakisss', 'pakiss@nga.com', 'FAD', 19, '2025-03-07', '15:00:00', '15:00:00', 'assa', 'asa', 'asas', 'asas', 'Yes', '', '2025-03-13 13:01:42', 31, 0, NULL),
(70, 'hhrhrh', 'asas@das.fg', 'CRD', 19, '2025-03-14', '15:00:00', '15:00:00', 'as', 'as', 's', 's', 'Yes', '', '2025-03-13 13:07:29', 29, 0, NULL),
(71, 'asas', 'asas2sa2@asas.as', 'CRD', 19, '2025-03-27', '14:30:00', '14:30:00', 'sa', 'as', 'sa', 's', 'Yes', '', '2025-03-13 13:12:00', 28, 0, NULL),
(72, 'Mr. Saitamazkie', 'arvsss@gmail.com', 'FAD', 19, '2025-03-13', '14:30:00', '14:30:00', 'sa', 'd', 'ss', 'asdddd', 'No', '', '2025-03-13 16:36:33', 36, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('Master Admin','User','Manager','Admin','HR Manager') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`) VALUES
(8, 'Gojo Satoru', 'gojo@tsr.local', '$2y$10$2PWqi3cHUaOftslLIQ7/NeVoOAsG9Um01QzEBYpxlG46kFb004UDy', 'Manager'),
(11, 'Dito Ka Sakin', 'ditoka@tsr.local', '$2y$10$9ML3lSja2ytUWPHbnx3nEeR.Rnl2lOI8tzZPa0FrGyKFiXPgjn8Zi', 'User'),
(13, 'Victor Schevalier', 'vic@tsr.local', '$2y$10$aNzVkQ4BsPD8s3oqSeNLoOSNCk6xrmUeXa3pO3IkvVOFxfVFZ6GZe', 'Manager'),
(14, 'Dainty', 'dainty@tsr.local', '$2y$10$e2ax0QpnBdzhv3nAYXDf6OpX2tj1dEauDdIejK4Hxg0.mbkACAc2m', 'Manager'),
(15, 'Marie', 'marie@tsr.local', '$2y$10$v3WleJGXud4D0ER7L8ZK2eDAvHpcIsF.u4ewvCLxWSMAZ0ASN1jXq', 'Manager'),
(16, 'AdminMaster', 'masteradmin@tsr.local', '$2y$10$UObkL9qEHz.5qwH34NhsGuuXjX6LnQMG5IOqQZQ6d2bWeD5uhuM5G', 'Master Admin'),
(17, 'Shelby', 'johnarvie454@gmail.com', '$2y$10$TQ99aKKZ0Mq0NEagcmRojelm0Bq9LliwG4nSG5D8DVcV5q4IPtFoK', 'Admin'),
(18, 'Lalong Tumatamis', 'gptproject8@gmail.com', '$2y$10$ZioygyyC5wlZRlAmNjIrSOoyxCyBdUZz60N4NOT85psO09R07dj9y', 'HR Manager'),
(19, 'Bossingg', 'rdacc714@gmail.com', '$2y$10$ZKuFo2EShFt390996jp.luIJ1AF9hweJebReN/7b3BT6v9NPJ0f66', 'Manager');

-- --------------------------------------------------------

--
-- Table structure for table `vehicles`
--

CREATE TABLE `vehicles` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `plate_number` varchar(20) NOT NULL,
  `status` enum('Available','In Use','Maintenance') DEFAULT 'Available',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vehicles`
--

INSERT INTO `vehicles` (`id`, `name`, `plate_number`, `status`, `created_at`) VALUES
(6, 'Hilux GRS ', 'Ak1nkalan9', 'In Use', '2025-03-09 12:41:26'),
(7, 'Toyota GR86', 'B4byyy', 'In Use', '2025-03-09 12:42:00'),
(8, 'Lamborghini Aventador', 'Dit0kaSakin', 'In Use', '2025-03-09 12:42:46'),
(9, 'Mercedes', 'Ocak3s', 'In Use', '2025-03-09 12:43:30'),
(10, 'Groti', '2dff', 'In Use', '2025-03-10 17:36:55'),
(11, 'g', '3', 'In Use', '2025-03-12 13:45:49'),
(12, '1', '2', 'In Use', '2025-03-12 13:49:34'),
(13, '23123', '123', 'In Use', '2025-03-12 13:49:37'),
(14, '12312', '333', 'In Use', '2025-03-12 13:49:39'),
(15, 'g', '2', 'In Use', '2025-03-12 13:55:20'),
(16, 'GGG', 'G', 'In Use', '2025-03-12 13:56:56'),
(17, 'test1', 'test', 'In Use', '2025-03-12 14:03:47'),
(18, 'g', 'g', 'In Use', '2025-03-12 15:26:23'),
(19, 'as', 's', 'In Use', '2025-03-12 15:26:26'),
(20, 'assaas', 'sadsaa', 'In Use', '2025-03-12 15:26:29'),
(21, 'g', 'ko', 'In Use', '2025-03-12 19:06:34'),
(22, 'groti', '123', 'In Use', '2025-03-12 19:13:23'),
(23, 'ggg', 'ggg', 'In Use', '2025-03-13 07:16:45'),
(24, 'Viruz', '123', 'In Use', '2025-03-13 08:12:47'),
(25, 'Nyenye', '2134', 'In Use', '2025-03-13 08:14:24'),
(26, 'test', 'sg', 'In Use', '2025-03-13 09:12:22'),
(27, 'GG', '2d', 'In Use', '2025-03-13 11:55:39'),
(28, 'wwwww', 'ww', 'In Use', '2025-03-13 13:46:36'),
(29, 'g', 'gs', 'In Use', '2025-03-13 13:54:19'),
(30, 'G', 's', 'In Use', '2025-03-13 14:09:18'),
(31, 'TOyota ', 'GRS', 'In Use', '2025-03-13 14:20:09'),
(32, 'GGG', 'ggg', 'In Use', '2025-03-13 14:20:58'),
(33, 'G', '22', 'In Use', '2025-03-13 14:26:27'),
(34, 'gg', '2ff', 'In Use', '2025-03-13 14:28:02'),
(35, 'G', '2131', 'In Use', '2025-03-13 14:37:50'),
(36, 'Toyoty', 'B3e', 'In Use', '2025-03-13 16:38:28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `approvals`
--
ALTER TABLE `approvals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_trip_approvals` (`trip_id`,`approver_role`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `trip_archives`
--
ALTER TABLE `trip_archives`
  ADD PRIMARY KEY (`archive_id`),
  ADD KEY `trip_id` (`trip_id`),
  ADD KEY `approver_id` (`approver_id`);

--
-- Indexes for table `trip_requests`
--
ALTER TABLE `trip_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_manager_id` (`manager_id`),
  ADD KEY `idx_vehicle_id` (`vehicle_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `approvals`
--
ALTER TABLE `approvals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=171;

--
-- AUTO_INCREMENT for table `trip_archives`
--
ALTER TABLE `trip_archives`
  MODIFY `archive_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `trip_requests`
--
ALTER TABLE `trip_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `vehicles`
--
ALTER TABLE `vehicles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `approvals`
--
ALTER TABLE `approvals`
  ADD CONSTRAINT `approvals_ibfk_1` FOREIGN KEY (`trip_id`) REFERENCES `trip_requests` (`id`);

--
-- Constraints for table `trip_archives`
--
ALTER TABLE `trip_archives`
  ADD CONSTRAINT `trip_archives_ibfk_1` FOREIGN KEY (`trip_id`) REFERENCES `trip_requests` (`id`),
  ADD CONSTRAINT `trip_archives_ibfk_2` FOREIGN KEY (`approver_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `trip_requests`
--
ALTER TABLE `trip_requests`
  ADD CONSTRAINT `trip_requests_ibfk_1` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
