<?php
session_start();
require_once 'db.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', 'php_errors.log');

header('Content-Type: application/json');

// Log the request for debugging
error_log("Trip details request received: " . json_encode($_GET));

// Check authentication
if (!isset($_SESSION['id'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Not authenticated']);
    exit;
}

// Validate trip ID
if (!isset($_GET['id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Trip ID is required']);
    exit;
}

try {
    $trip_id = intval($_GET['id']);
    error_log("Processing trip ID: $trip_id");
    
    // Simple query to get basic trip information first
    $check_query = "SELECT id FROM trip_requests WHERE id = ?";
    $check_stmt = mysqli_prepare($conn, $check_query);
    
    if (!$check_stmt) {
        throw new Exception("Prepare check query failed: " . mysqli_error($conn));
    }
    
    mysqli_stmt_bind_param($check_stmt, "i", $trip_id);
    mysqli_stmt_execute($check_stmt);
    mysqli_stmt_store_result($check_stmt);
    
    if (mysqli_stmt_num_rows($check_stmt) === 0) {
        http_response_code(404);
        echo json_encode(['error' => 'Trip request not found']);
        exit;
    }
    
    mysqli_stmt_close($check_stmt);
    
    // Now get the full trip details
    $query = "SELECT 
        tr.id,
        tr.requestor_name,
        tr.requestor_email,
        tr.department,
        tr.date_needed,
        tr.time_needed,
        tr.time_return,
        tr.route_from,
        tr.route_to,
        tr.passengers,
        tr.company_vehicle,
        tr.purpose,
        tr.status,
        tr.manager_id,
        tr.vehicle_id,
        tr.driver_id,
        
        /* Manager information */
        manager.name as manager_name,
        manager.role as manager_role,
        
        /* HR Manager information */
        (SELECT u.name 
         FROM users u 
         WHERE u.role = 'HR Manager' 
         LIMIT 1) as hr_manager_name,
        'HR Manager' as hr_manager_role,
        
        /* Admin information */
        (SELECT u.name 
         FROM users u 
         WHERE u.role = 'Admin' 
         LIMIT 1) as admin_name,
        'Admin' as admin_role,
        
        /* Approval information */
        COALESCE(manager_approval.status, 'Pending') as manager_status,
        manager_approval.comment as manager_comment,
        manager_approval.created_at as manager_date,
        
        COALESCE(hr_approval.status, 'Pending') as hr_status,
        hr_approval.comment as hr_comment,
        hr_approval.created_at as hr_date,
        
        COALESCE(admin_approval.status, 'Pending') as admin_status,
        admin_approval.comment as admin_comment,
        admin_approval.created_at as admin_date,
        
        /* Vehicle information */
        v.name as vehicle_name,
        v.plate_number,
        v.status as vehicle_status,
        
        /* Driver information */
        d.name as driver_name,
        d.contact as driver_contact,
        d.license_number as driver_license,
        d.status as driver_status
        
        FROM trip_requests tr
        
        /* Join for manager information */
        LEFT JOIN users manager ON tr.manager_id = manager.id
        
        /* Join for approval information */
        LEFT JOIN approvals manager_approval ON tr.id = manager_approval.trip_id AND manager_approval.approver_role = 'manager'
        LEFT JOIN approvals admin_approval ON tr.id = admin_approval.trip_id AND admin_approval.approver_role = 'admin'
        LEFT JOIN approvals hr_approval ON tr.id = hr_approval.trip_id AND hr_approval.approver_role = 'hr'
        
        /* Join for vehicle information */
        LEFT JOIN vehicles v ON tr.vehicle_id = v.id
        
        /* Join for driver information */
        LEFT JOIN drivers d ON tr.driver_id = d.id
        
        WHERE tr.id = ?";

    $stmt = mysqli_prepare($conn, $query);
    if (!$stmt) {
        throw new Exception("Prepare failed: " . mysqli_error($conn));
    }

    mysqli_stmt_bind_param($stmt, "i", $trip_id);
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Execute failed: " . mysqli_stmt_error($stmt));
    }

    $result = mysqli_stmt_get_result($stmt);
    if (!$result) {
        throw new Exception("Get result failed: " . mysqli_error($conn));
    }

    $trip = mysqli_fetch_assoc($result);
    if (!$trip) {
        http_response_code(404);
        echo json_encode(['error' => 'Trip request details could not be retrieved']);
        exit;
    }

    error_log("Trip data retrieved successfully for ID: $trip_id");

    $response = [
        'id' => $trip['id'],
        'requestor_name' => htmlspecialchars($trip['requestor_name']),
        'requestor_email' => htmlspecialchars($trip['requestor_email'] ?? 'N/A'),
        'department' => htmlspecialchars($trip['department']),
        'date_needed' => date('M d, Y', strtotime($trip['date_needed'])),
        'time_needed' => date('h:i A', strtotime($trip['time_needed'])),
        'time_return' => !empty($trip['time_return']) ? date('h:i A', strtotime($trip['time_return'])) : '',
        'route_from' => htmlspecialchars($trip['route_from']),
        'route_to' => htmlspecialchars($trip['route_to']),
        'passengers' => htmlspecialchars($trip['passengers']),
        'purpose' => htmlspecialchars($trip['purpose']),
        'company_vehicle' => $trip['company_vehicle'],
        'status' => $trip['status'] ?? 'Pending',
        'approvers' => [
            'manager' => [
                'name' => htmlspecialchars($trip['manager_name'] ?? 'Not Assigned'),
                'role' => htmlspecialchars($trip['manager_role'] ?? 'Manager'),
                'status' => $trip['manager_status'] ?? 'Pending',
                'comment' => htmlspecialchars($trip['manager_comment'] ?? ''),
                'date' => $trip['manager_date'] ?? ''
            ],
            'admin' => [
                'name' => htmlspecialchars($trip['admin_name'] ?? 'Not Assigned'),
                'role' => htmlspecialchars($trip['admin_role'] ?? 'Admin'),
                'status' => $trip['admin_status'] ?? 'Pending',
                'comment' => htmlspecialchars($trip['admin_comment'] ?? ''),
                'date' => $trip['admin_date'] ?? '',
                'vehicle' => $trip['vehicle_name'] ? [
                    'name' => htmlspecialchars($trip['vehicle_name']),
                    'plate_number' => htmlspecialchars($trip['plate_number']),
                    'status' => $trip['vehicle_status'] ?? 'Available'
                ] : null,
                'driver' => $trip['driver_name'] ? [
                    'name' => htmlspecialchars($trip['driver_name']),
                    'contact' => htmlspecialchars($trip['driver_contact'] ?? ''),
                    'license' => htmlspecialchars($trip['driver_license'] ?? ''),
                    'status' => $trip['driver_status'] ?? 'Available'
                ] : null
            ],
            'hr_manager' => [
                'name' => htmlspecialchars($trip['hr_manager_name'] ?? 'Not Assigned'),
                'role' => htmlspecialchars($trip['hr_manager_role'] ?? 'HR Manager'),
                'status' => $trip['hr_status'] ?? 'Pending',
                'comment' => htmlspecialchars($trip['hr_comment'] ?? ''),
                'date' => $trip['hr_date'] ?? ''
            ]
        ]
    ];

    echo json_encode($response);
    error_log("Response sent successfully for trip ID: $trip_id");

} catch (Exception $e) {
    error_log("Trip Details Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Failed to load trip details: ' . $e->getMessage()]);
}

mysqli_close($conn);
