<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

// Test recipient emails
$recipients = [
    'gptproject8@gmail.com', // Replace with actual email
    'johnarvie454@gmail.com', // Replace with actual email
    'rdacc714@gmail.com'  // Replace with actual email
];

// Sample data for email content
$requestor_name = "John Doe";
$managerName = "Jane Smith";
$adminName = "Michael Johnson";
$hrName = "Lisa Brown";
$managerComment = "Approved with no issues.";
$adminComment = "All details verified.";
$hrComment = "Final approval granted.";

// Create a new PHPMailer instance
$mail = new PHPMailer(true);

try {
    // SMTP Server Settings
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;
    $mail->Username   = 'furfectmatch00@gmail.com'; // Change to your email
    $mail->Password   = 'hshp joln vbgl yddk'; // Change to your app password

    // Set sender email
    $mail->setFrom('furfectmatch00@gmail.com', 'Vehicle Request');

    // Add multiple recipients
    foreach ($recipients as $email) {
        $mail->addAddress($email);
    }

    // Email subject
    $mail->Subject = 'Test Email - Vehicle Request Approved';

    // Email body (HTML format)
    $mail->isHTML(true);
    $mail->Body = "
    <html>
    <head>
        <title>Vehicle Request - Approved</title>
    </head>
    <body style='font-family: Arial, sans-serif; color: #333;'>
        <p><b>Good Day,</b></p>

        <p>The trip request submitted by <b>{$requestor_name}</b> has been approved by the HR Manager <b>{$hrName}</b> and is now completed.</p>

        <h3>Approval Details:</h3>
        <p>
            <strong>Requestor Name:</strong> {$requestor_name} <br>
            <strong>Manager:</strong> {$managerName} <br>
            <strong>Manager Comment:</strong> {$managerComment} <br>
            <strong>Admin:</strong> {$adminName} <br>
            <strong>Admin Comment:</strong> {$adminComment} <br>
            <strong>HR Manager:</strong> {$hrName} <br>
            <strong>HR Comment:</strong> {$hrComment} <br>
        </p>

        <p>
            <b>You may access this link:</b> 
            <a href='http://localhost/Trip/login.php'>Trip Ticket System</a>
        </p>

        <p><b>IMPORTANT:</b> This is an automated notification. For technical assistance, please contact the IT Help Desk.</p>
    </body>
    </html>";

    // Send email
    if ($mail->send()) {
        echo "Test email sent successfully to multiple recipients!";
    } else {
        echo "Email sending failed: " . $mail->ErrorInfo;
    }

} catch (Exception $e) {
    echo "Mailer Error: " . $mail->ErrorInfo;
}
?>
