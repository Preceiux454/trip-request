<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toyota</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Roboto', sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #f9f9f9;
        }
        
        /* Header Styles */
        header {
            background-color: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 0;
        }
        
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .header-content {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .logo-container {
            display: flex;
            align-items: center;
        }
        
        .logo {
            height: 50px;
            margin-right: 15px;
        }
        
        .company-name {
            font-size: 24px;
            font-weight: 700;
            color: #E50000;
        }
        
        /* Navigation Styles */
        nav {
            background-color: #f2f2f2;
            padding: 10px 0;
            border-bottom: 1px solid #e1e1e1;
        }
        
        .nav-list {
            list-style: none;
            display: flex;
        }
        
        .nav-item {
            margin-right: 20px;
        }
        
        .nav-item a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            padding: 5px 10px;
            border-radius: 4px;
            transition: all 0.3s ease;
        }
        
        .nav-item a:hover {
            background-color: #e1e1e1;
            color: #E50000;
        }
        
        .nav-item a.active {
            background-color: #E50000;
            color: white;
        }
        
        /* Main Content Styles */
        main {
            padding: 40px 0;
        }
        
        .hero {
            background-image: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('https://www.toyota.com/imgix/responsive/images/homepage/hero/2023/dec/homepage-hero-camry-desktop.png');
            background-size: cover;
            background-position: center;
            color: white;
            text-align: center;
            padding: 100px 20px;
            margin-bottom: 40px;
            border-radius: 8px;
        }
        
        .hero h1 {
            font-size: 36px;
            margin-bottom: 20px;
        }
        
        .hero p {
            font-size: 18px;
            max-width: 800px;
            margin: 0 auto 30px;
        }
        
        .btn {
            display: inline-block;
            background-color: #E50000;
            color: white;
            padding: 12px 24px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: 500;
            transition: background-color 0.3s ease;
        }
        
        .btn:hover {
            background-color: #cc0000;
        }
        
        .about-section {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 40px;
            margin-bottom: 40px;
        }
        
        .about-content h2 {
            font-size: 28px;
            margin-bottom: 20px;
            color: #333;
        }
        
        .about-content p {
            margin-bottom: 15px;
        }
        
        .about-image {
            border-radius: 8px;
            overflow: hidden;
        }
        
        .about-image img {
            width: 100%;
            height: auto;
            display: block;
        }
        
        .features {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 30px;
            margin-bottom: 40px;
        }
        
        .feature-card {
            background-color: white;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            text-align: center;
        }
        
        .feature-icon {
            font-size: 36px;
            color: #E50000;
            margin-bottom: 20px;
        }
        
        .feature-card h3 {
            font-size: 20px;
            margin-bottom: 15px;
        }
        
        /* Responsive Styles */
        @media (max-width: 768px) {
            .about-section {
                grid-template-columns: 1fr;
            }
            
            .features {
                grid-template-columns: 1fr;
            }
            
            .nav-list {
                flex-direction: column;
            }
            
            .nav-item {
                margin-right: 0;
                margin-bottom: 10px;
            }
        }
        @import url('https://fonts.googleapis.com/css2?family=Lexend:wght@300;400;500;600;700&display=swap');

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Lexend', sans-serif;
    line-height: 1.6;
    color: #333;
    background-color: #f9f9f9;
}

.container {
    width: 90%;
    max-width: 1200px;
    margin: 0 auto;
}

/* Enhanced Header Styles */
.enhanced-header {
    background-color: white;
    box-shadow: 0 4px 12px rgba(0,0,0,0.05);
    padding: 15px 0;
    position: relative;
}

.header-content {
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.logo-container {
    display: flex;
    align-items: center;
}

.logo {
    height: 40px;
    margin-right: 12px;
    filter: drop-shadow(0 2px 4px rgba(0,0,0,0.1));
    transition: transform 0.3s ease;
}

.logo:hover {
    transform: scale(1.05);
}

.company-name {
    font-size: 24px;
    font-weight: 700;
    color: #E50000;
    letter-spacing: 1px;
    position: relative;
    padding-bottom: 2px;
}

.company-name::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 2px;
    background: linear-gradient(90deg, #E50000, transparent);
}

.header-right {
    display: flex;
    align-items: center;
}

.search-container {
    display: flex;
    margin-right: 20px;
}

.search-input {
    padding: 8px 12px;
    border: 1px solid #e1e1e1;
    border-radius: 20px 0 0 20px;
    font-family: 'Lexend', sans-serif;
    width: 200px;
    transition: all 0.3s ease;
}

.search-input:focus {
    outline: none;
    width: 250px;
    border-color: #E50000;
}

.search-btn {
    background-color: #E50000;
    color: white;
    border: none;
    padding: 8px 15px;
    border-radius: 0 20px 20px 0;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.search-btn:hover {
    background-color: #cc0000;
}

.header-actions {
    display: flex;
}

.header-action {
    color: #555;
    font-size: 18px;
    margin-left: 15px;
    text-decoration: none;
    transition: all 0.3s ease;
}

.header-action:hover {
    color: #E50000;
    transform: translateY(-2px);
}

/* Enhanced Navigation Styles */
.enhanced-nav {
    background: linear-gradient(to right, #f8f8f8, #f2f2f2);
    padding: 0;
    border-bottom: 1px solid #e1e1e1;
    position: relative;
}

.nav-list {
    list-style: none;
    display: flex;
    margin: 0;
    padding: 0;
}

.nav-item {
    position: relative;
}

.nav-item a {
    text-decoration: none;
    color: #333;
    font-weight: 500;
    padding: 15px 20px;
    display: flex;
    align-items: center;
    transition: all 0.3s ease;
}

.nav-icon {
    margin-right: 8px;
    font-size: 14px;
}

.dropdown-icon {
    font-size: 10px;
    margin-left: 5px;
}

.nav-item a:hover {
    background-color: rgba(229, 0, 0, 0.05);
    color: #E50000;
}

.nav-item a.active {
    background-color: #E50000;
    color: white;
    position: relative;
}

.nav-item a.active::after {
    content: '';
    position: absolute;
    bottom: -10px;
    left: 50%;
    transform: translateX(-50%);
    border-left: 10px solid transparent;
    border-right: 10px solid transparent;
    border-top: 10px solid #E50000;
}

/* Dropdown styles */
.dropdown {
    position: relative;
}

.dropdown-menu {
    position: absolute;
    top: 100%;
    left: 0;
    background-color: white;
    min-width: 220px;
    box-shadow: 0 8px 16px rgba(0,0,0,0.1);
    border-radius: 4px;
    padding: 10px 0;
    z-index: 100;
    opacity: 0;
    visibility: hidden;
    transform: translateY(10px);
    transition: all 0.3s ease;
}

.dropdown:hover .dropdown-menu {
    opacity: 1;
    visibility: visible;
    transform: translateY(0);
}

.dropdown-menu a {
    display: block;
    padding: 10px 20px;
    color: #333;
    text-decoration: none;
    transition: all 0.2s ease;
}

.dropdown-menu a:hover {
    background-color: #f8f8f8;
    color: #E50000;
    padding-left: 25px;
}

/* Responsive styles */
@media (max-width: 992px) {
    .search-container {
        display: none;
    }
    
    .nav-list {
        flex-wrap: wrap;
    }
    
    .nav-item a {
        padding: 12px 15px;
    }
}

@media (max-width: 768px) {
    .header-content {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .header-right {
        margin-top: 15px;
        width: 100%;
        justify-content: flex-end;
    }
    
    .nav-list {
        flex-direction: column;
    }
    
    .nav-item {
        width: 100%;
    }
    
    .dropdown-menu {
        position: static;
        box-shadow: none;
        opacity: 1;
        visibility: visible;
        transform: none;
        padding-left: 20px;
    }
    
    .nav-item a.active::after {
        display: none;
    }
}
    </style>
</head>
<body>
   <!-- Enhanced Header -->
<header class="enhanced-header">
    <div class="container">
        <div class="header-content">
            <div class="logo-container">
                <img src="https://www.toyota.com/favicon.ico" alt="Toyota Logo" class="logo">
                <div class="company-name">TOYOTA</div>
            </div>
            <div class="header-right">
                <div class="search-container">
                    <input type="text" placeholder="Search..." class="search-input">
                    <button class="search-btn"><i class="fas fa-search"></i></button>
                </div>
                <div class="header-actions">
                    <a href="#" class="header-action"><i class="fas fa-user"></i></a>
                    <a href="#" class="header-action"><i class="fas fa-shopping-cart"></i></a>
                    <a href="#" class="header-action"><i class="fas fa-map-marker-alt"></i></a>
                </div>
            </div>
        </div>
    </div>
</header>

<!-- Enhanced Navigation -->
<nav class="enhanced-nav">
    <div class="container">
        <ul class="nav-list">
            <li class="nav-item"><a href="#" class="active"><i class="fas fa-home nav-icon"></i>Home</a></li>
            <li class="nav-item dropdown">
                <a href="#"><i class="fas fa-car nav-icon"></i>Request Forms <i class="fas fa-chevron-down dropdown-icon"></i></a>
                <div class="dropdown-menu">
                    <a href="index.php">Vehicle Request </a>
                    <a href="test-drive.php">Test Drive Request</a>
                    <a href="#">Test Request</a>
       
                </div>
            </li>
            <li class="nav-item"><a href="#"><i class="fas fa-info-circle nav-icon"></i>About Us</a></li>
            <li class="nav-item"><a href="https://masterlist.toyotasantarosa.com.ph/IMS/login.php">Masterlist      <i class="fas fa-wrench nav-icon"></i></a></li>
            <li class="nav-item"><a href="#"><i class="fas fa-envelope nav-icon"></i>Contact</a></li>
        </ul>
    </div>
</nav>
    
    <!-- Main Content -->
    <main>
        <div class="container">
            <!-- Hero Section -->
            <section class="hero">
                <h1>Experience the Toyota Difference</h1>
                <p>Innovative technology, exceptional quality, and reliability that lasts for generations.</p>
                <a href="#" class="btn">Explore Our Vehicles</a>
            </section>
            
         
            
            <!-- Features Section -->
            <section class="features">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-car"></i>
                    </div>
                    <h3>Quality Vehicles</h3>
                    <p>Toyota is committed to building high-quality, reliable vehicles that stand the test of time.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-leaf"></i>
                    </div>
                    <h3>Environmental Leadership</h3>
                    <p>Pioneering hybrid technology and sustainable manufacturing practices for a greener future.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <h3>Safety Innovation</h3>
                    <p>Advanced safety features and technologies to protect drivers and passengers.</p>
                </div>
            </section>
        </div>
    </main>
</body>
</html>

