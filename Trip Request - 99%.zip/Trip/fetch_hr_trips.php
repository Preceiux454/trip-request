<?php
session_start();
require_once 'db.php';

header('Content-Type: application/json');

if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'HR Manager') {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

// Fetch and sanitize company vehicle info if provided
$company_vehicle = '';
if (isset($_POST['company_vehicle'])) {
    $company_vehicle = mysqli_real_escape_string($conn, $_POST['company_vehicle']);
}

try {
    // Build the query with dynamic filter condition
    $query = "SELECT 
        tr.*,
        m.name as manager_name,
        hr.name as hr_manager_name,
        adm.name as admin_name,
        ma.status as manager_status,
        ma.created_at as manager_approval_date,
        ada.status as admin_status,
        ada.created_at as admin_approval_date,
        hra.status as hr_status,
        hra.created_at as hr_approval_date,
        v.name as vehicle_name,
        v.plate_number
    FROM trip_requests tr
    LEFT JOIN users m ON tr.manager_id = m.id
    LEFT JOIN users hr ON hr.role = 'HR Manager'
    LEFT JOIN users adm ON adm.role = 'Admin'
    LEFT JOIN approvals ma ON ma.trip_id = tr.id AND ma.approver_role = 'manager'
    LEFT JOIN approvals ada ON ada.trip_id = tr.id AND ada.approver_role = 'admin'
    LEFT JOIN approvals hra ON hra.trip_id = tr.id AND hra.approver_role = 'hr'
    LEFT JOIN vehicles v ON v.id = tr.company_vehicle
    WHERE ada.status = 'Approved' 
    AND (hra.status IS NULL OR hra.status = 'Pending')";
    
    // Append company vehicle filter if provided
    if (!empty($company_vehicle)) {
        $query .= " AND tr.company_vehicle = '$company_vehicle'";
    }
    
    $query .= " ORDER BY tr.created_at DESC";

    $result = mysqli_query($conn, $query);

    if (!$result) {
        throw new Exception(mysqli_error($conn));
    }

    // Update the response structure to include dates
    $trips = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $trips[] = [
            'id' => $row['id'],
            'requestor_name' => $row['requestor_name'], // Now directly from tr table
            'department' => $row['department'],
            'date_needed' => date('M d, Y', strtotime($row['date_needed'])),
            'status' => $row['status'],
            'approvers' => [
                'manager' => [
                    'name' => $row['manager_name'] ?? 'Not Assigned',
                    'status' => $row['manager_status'] ?? 'Pending',
                    'approval_date' => $row['manager_approval_date'] ? 
                        date('M d, Y h:i A', strtotime($row['manager_approval_date'])) : null
                ],
                'admin' => [
                    'name' => $row['admin_name'] ?? 'Not Assigned',
                    'status' => $row['admin_status'] ?? 'Pending',
                    'approval_date' => $row['admin_approval_date'] ? 
                        date('M d, Y h:i A', strtotime($row['admin_approval_date'])) : null,
                    'vehicle' => $row['vehicle_name'] ? [
                        'name' => $row['vehicle_name'],
                        'plate_number' => $row['plate_number']
                    ] : null
                ],
                'hr_manager' => [
                    'name' => $row['hr_manager_name'] ?? 'Not Assigned',
                    'status' => $row['hr_status'] ?? 'Pending',
                    'approval_date' => $row['hr_approval_date'] ? 
                        date('M d, Y h:i A', strtotime($row['hr_approval_date'])) : null
                ]
            ]
        ];
    }

    echo json_encode($trips);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}

mysqli_close($conn);