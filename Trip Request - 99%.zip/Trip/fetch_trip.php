<?php
session_start();
require_once 'db.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', 'php_errors.log');

header('Content-Type: application/json');

// Check authentication
if (!isset($_SESSION['id'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Not authenticated']);
    exit;
}

try {
    // Log the request parameters
    error_log("Fetching trips with parameters: " . json_encode($_GET));
    
    // Get filter parameters
    $search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
    $status = isset($_GET['status']) ? mysqli_real_escape_string($conn, $_GET['status']) : '';
    $department = isset($_GET['department']) ? mysqli_real_escape_string($conn, $_GET['department']) : '';
    $date = isset($_GET['date']) ? mysqli_real_escape_string($conn, $_GET['date']) : '';
    
    // Build the base query without any WHERE conditions initially
    $query = "SELECT 
        tr.id,
        tr.requestor_name,
        tr.department,
        tr.date_needed,
        tr.time_needed,
        tr.route_from,
        tr.route_to,
        tr.passengers,
        tr.company_vehicle,
        tr.purpose,
        tr.status,
        tr.manager_id,
        m.name as manager_name,
        (SELECT u.name 
         FROM users u 
         INNER JOIN approvals a ON a.trip_id = tr.id 
         WHERE u.role = 'HR Manager' AND a.approver_role = 'hr'
         LIMIT 1) as hr_manager_name,
        (SELECT u.name 
         FROM users u 
         INNER JOIN approvals a ON a.trip_id = tr.id 
         WHERE u.role = 'Admin' AND a.approver_role = 'admin'
         LIMIT 1) as admin_name,
        COALESCE(ma.status, 'Pending') as manager_status,
        COALESCE(hra.status, 'Pending') as hr_status,
        COALESCE(ada.status, 'Pending') as admin_status,
        ma.comment as manager_comment,
        hra.comment as hr_comment,
        ada.comment as admin_comment,
        ma.created_at as manager_date,
        hra.created_at as hr_date,
        ada.created_at as admin_date
    FROM trip_requests tr
    LEFT JOIN users m ON m.id = tr.manager_id
    LEFT JOIN approvals ma ON ma.trip_id = tr.id AND ma.approver_role = 'manager'
    LEFT JOIN approvals hra ON hra.trip_id = tr.id AND hra.approver_role = 'hr'
    LEFT JOIN approvals ada ON ada.trip_id = tr.id AND ada.approver_role = 'admin'";
    
    // Build WHERE conditions array
    $conditions = [];
    $params = [];
    $types = "";
    
    // Add search condition if provided
    if (!empty($search)) {
        $conditions[] = "(tr.requestor_name LIKE ? OR tr.department LIKE ? OR tr.purpose LIKE ?)";
        $searchParam = "%$search%";
        $params[] = $searchParam;
        $params[] = $searchParam;
        $params[] = $searchParam;
        $types .= "sss";
    }
    
    // Add status condition if provided
    if (!empty($status)) {
        if ($status === 'Pending') {
            $conditions[] = "tr.status = 'Pending'";
        } else if ($status === 'Approved') {
            $conditions[] = "tr.status = 'Approved'";
        } else if ($status === 'Rejected') {
            $conditions[] = "tr.status = 'Rejected'";
        }
    }
    
    // Add department condition if provided
    if (!empty($department)) {
        $conditions[] = "tr.department = ?";
        $params[] = $department;
        $types .= "s";
    }
    
    // Add date condition if provided
    if (!empty($date)) {
        $conditions[] = "DATE(tr.date_needed) = ?";
        $params[] = $date;
        $types .= "s";
    }
    
    // Add archived condition to exclude archived trips
    $conditions[] = "(tr.archived = 0 OR tr.archived IS NULL)";
    
    // Combine all conditions with AND
    if (!empty($conditions)) {
        $query .= " WHERE " . implode(" AND ", $conditions);
    }
    
    // Add order by
    $query .= " ORDER BY tr.id DESC";
    
    // Log the final query for debugging
    error_log("Final query: $query");
    error_log("Query parameters: " . json_encode($params));
    
    // Prepare and execute the query
    $stmt = mysqli_prepare($conn, $query);
    
    if (!$stmt) {
        throw new Exception("Prepare failed: " . mysqli_error($conn));
    }
    
    // Bind parameters if any
    if (!empty($params)) {
        mysqli_stmt_bind_param($stmt, $types, ...$params);
    }
    
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Execute failed: " . mysqli_stmt_error($stmt));
    }
    
    $result = mysqli_stmt_get_result($stmt);
    if (!$result) {
        throw new Exception("Get result failed: " . mysqli_error($conn));
    }
    
    // Fetch all trips
    $trips = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $trips[] = [
            'id' => $row['id'],
            'requestor_name' => htmlspecialchars($row['requestor_name']),
            'department' => htmlspecialchars($row['department']),
            'date_needed' => date('M d, Y', strtotime($row['date_needed'])),
            'time_needed' => date('h:i A', strtotime($row['time_needed'])),
            'route_from' => htmlspecialchars($row['route_from']),
            'route_to' => htmlspecialchars($row['route_to']),
            'passengers' => htmlspecialchars($row['passengers']),
            'company_vehicle' => $row['company_vehicle'],
            'purpose' => htmlspecialchars($row['purpose']),
            'status' => $row['status'],
            'approvers' => [
                'manager' => [
                    'name' => htmlspecialchars($row['manager_name'] ?? ''),
                    'status' => $row['manager_status'],
                    'comment' => htmlspecialchars($row['manager_comment'] ?? ''),
                    'date' => $row['manager_date'] ? date('M d, Y h:i A', strtotime($row['manager_date'])) : null
                ],
                'hr_manager' => [
                    'name' => htmlspecialchars($row['hr_manager_name'] ?? ''),
                    'status' => $row['hr_status'],
                    'comment' => htmlspecialchars($row['hr_comment'] ?? ''),
                    'date' => $row['hr_date'] ? date('M d, Y h:i A', strtotime($row['hr_date'])) : null
                ],
                'admin' => [
                    'name' => htmlspecialchars($row['admin_name'] ?? ''),
                    'status' => $row['admin_status'],
                    'comment' => htmlspecialchars($row['admin_comment'] ?? ''),
                    'date' => $row['admin_date'] ? date('M d, Y h:i A', strtotime($row['admin_date'])) : null
                ]
            ]
        ];
    }
    
    // Log the number of trips found
    error_log("Found " . count($trips) . " trips");
    
    echo json_encode(['trips' => $trips]);

} catch (Exception $e) {
    error_log("Error fetching trips: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Failed to fetch trips: ' . $e->getMessage()]);
}

mysqli_close($conn);
