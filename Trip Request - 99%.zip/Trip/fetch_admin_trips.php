<?php
session_start();
require_once 'db.php';

header('Content-Type: application/json');

// Update role check to include Master Admin
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'Master Admin') {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

try {
    $query = "SELECT 
        tr.*,
        m.name as manager_name,
        ma.status as manager_status,
        ma.approval_date as manager_approval_date,
        hr.name as hr_manager_name,
        hra.status as hr_status,
        hra.approval_date as hr_approval_date,
        adm.name as admin_name,
        ada.status as admin_status,
        ada.approval_date as admin_approval_date,
        v.name as vehicle_name,
        v.plate_number,
        v.status as vehicle_status
    FROM trip_requests tr
    LEFT JOIN users m ON tr.manager_id = m.id
    LEFT JOIN users hr ON hr.role = 'HR Manager'
    LEFT JOIN users adm ON adm.role = 'Admin'
    LEFT JOIN approvals ma ON ma.trip_id = tr.id AND ma.approver_role = 'manager'
    LEFT JOIN approvals ada ON ada.trip_id = tr.id AND ada.approver_role = 'admin'
    LEFT JOIN approvals hra ON hra.trip_id = tr.id AND hra.approver_role = 'hr'
    LEFT JOIN vehicles v ON v.id = tr.vehicle_id
    ORDER BY tr.created_at DESC";

    $result = mysqli_query($conn, $query);

    if (!$result) {
        throw new Exception(mysqli_error($conn));
    }

    $trips = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $trips[] = [
            'id' => $row['id'],
            'requestor_name' => $row['requestor_name'],
            'requestor_email' => $row['requestor_email'] ?? 'N/A',
            'department' => $row['department'],
            'date_needed' => date('M d, Y', strtotime($row['date_needed'])),
            'status' => $row['status'],
            'approvers' => [
                'manager' => [
                    'name' => $row['manager_name'] ?? 'Not Assigned',
                    'status' => $row['manager_status'] ?? 'Pending',
                    'approval_date' => $row['manager_approval_date'] ? 
                        date('M d, Y h:i A', strtotime($row['manager_approval_date'])) : null
                ],
                'admin' => [
                    'name' => $row['admin_name'] ?? 'Not Assigned',
                    'status' => $row['admin_status'] ?? 'Pending',
                    'approval_date' => $row['admin_approval_date'] ? 
                        date('M d, Y h:i A', strtotime($row['admin_approval_date'])) : null,
                    'vehicle' => $row['vehicle_name'] ? [
                        'name' => $row['vehicle_name'],
                        'plate_number' => $row['plate_number'],
                        'status' => $row['vehicle_status']
                    ] : null
                ],
                'hr_manager' => [
                    'name' => $row['hr_manager_name'] ?? 'Not Assigned',
                    'status' => $row['hr_status'] ?? 'Pending',
                    'approval_date' => $row['hr_approval_date'] ? 
                        date('M d, Y h:i A', strtotime($row['hr_approval_date'])) : null
                ]
            ]
        ];
    }

    echo json_encode($trips);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}

mysqli_close($conn);
?>