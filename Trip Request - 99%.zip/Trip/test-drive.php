<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toyota Test Drive Request</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .form-container {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            padding: 30px;
            margin-top: 30px;
            margin-bottom: 30px;
        }
        .form-header {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
        }
        .form-header h1 {
            font-weight: 600;
            color: #E50000;
        }
        .form-header img {
            max-height: 60px;
            margin-bottom: 20px;
        }
        .section-title {
            background-color: #E50000;
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            font-size: 18px;
            font-weight: 500;
        }
        .form-label {
            font-weight: 500;
            color: #333;
        }
        .required:after {
            content: " *";
            color: #E50000;
        }
        .btn-toyota {
            background-color: #E50000;
            color: white;
            border: none;
            padding: 10px 30px;
            font-weight: 500;
            border-radius: 5px;
            transition: all 0.3s;
        }
        .btn-toyota:hover {
            background-color: #cc0000;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .responsibility-text {
            font-style: italic;
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border-left: 4px solid #E50000;
        }
        .form-select, .form-control {
            border-radius: 5px;
            padding: 10px 15px;
        }
        .form-select:focus, .form-control:focus {
            border-color: #E50000;
            box-shadow: 0 0 0 0.25rem rgba(229, 0, 0, 0.25);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 form-container">
                <div class="form-header">
                    <img src="https://www.toyota.com/favicon.ico" alt="Toyota Logo">
                    <h1>Test Drive Request</h1>
                    <p>Fill out the form below to schedule your test drive experience</p>
                </div>

                <form id="testDriveForm" method="POST" action="process-test-drive.php">
                    <!-- Responsibility Statement -->
                    <div class="responsibility-text">
                        <strong>Note:</strong> I will take full responsibility when I test drive the demo vehicle as detailed in this form.
                    </div>

                    <!-- Test Drive Details Section -->
                    <div class="section-title">
                        <i class="fas fa-car me-2"></i> Test Drive Details
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label required">Test Drive Type</label>
                            <select class="form-select" name="test_drive_type" required>
                                <option value="" selected disabled>Select an option</option>
                                <option value="walkin">Walk-in</option>
                                <option value="schedule">Schedule</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label required">Preferred Date</label>
                            <input type="date" class="form-control" name="preferred_date" required>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label required">Preferred Time</label>
                            <input type="time" class="form-control" name="preferred_time" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label required">Vehicle Model</label>
                            <select class="form-select" name="vehicle_model" required>
                                <option value="" selected disabled>Select a model</option>
                                <option value="Vios">Vios</option>
                                <option value="Corolla Altis">Corolla Altis</option>
                                <option value="Corolla Cross">Corolla Cross</option>
                                <option value="Fortuner">Fortuner</option>
                                <option value="Innova">Innova</option>
                                <option value="Hilux">Hilux</option>
                                <option value="RAV4">RAV4</option>
                                <option value="Camry">Camry</option>
                                <option value="Land Cruiser">Land Cruiser</option>
                                <option value="Hiace">Hiace</option>
                            </select>
                        </div>
                    </div>

                    <div class="row mb-4">
                        <div class="col-md-6">
                            <label class="form-label">Vehicle Plate No. (if known)</label>
                            <input type="text" class="form-control" name="vehicle_plate">
                        </div>
                    </div>

                    <!-- Customer Information Section -->
                    <div class="section-title">
                        <i class="fas fa-user me-2"></i> Customer Information
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label required">Full Name</label>
                            <input type="text" class="form-control" name="full_name" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label required">Contact Number</label>
                            <input type="tel" class="form-control" name="contact_number" required>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-12">
                            <label class="form-label required">Complete Address</label>
                            <textarea class="form-control" name="address" rows="2" required></textarea>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label required">Email Address</label>
                            <input type="email" class="form-control" name="email" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label required">Driver's License Number</label>
                            <input type="text" class="form-control" name="license_number" required>
                        </div>
                    </div>

                    <div class="row mb-4">
                        <div class="col-md-6">
                            <label class="form-label required">License Validity Date</label>
                            <input type="date" class="form-control" name="license_validity" required>
                        </div>
                    </div>

                    <!-- Terms and Submit -->
                    <div class="row mb-3">
                        <div class="col-12">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="termsCheck" required>
                                <label class="form-check-label" for="termsCheck">
                                    I agree to the <a href="#" data-bs-toggle="modal" data-bs-target="#termsModal">terms and conditions</a> and consent to the processing of my personal information.
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12 text-center">
                            <button type="submit" class="btn btn-toyota">
                                <i class="fas fa-paper-plane me-2"></i> Submit Test Drive Request
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Terms and Conditions Modal -->
    <div class="modal fade" id="termsModal" tabindex="-1" aria-labelledby="termsModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="termsModalLabel">Terms and Conditions</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <h6>Test Drive Terms and Conditions</h6>
                    <p>By requesting a test drive, you agree to the following terms:</p>
                    <ol>
                        <li>You must possess a valid driver's license.</li>
                        <li>You will be responsible for the vehicle during the test drive.</li>
                        <li>You will follow all traffic laws and regulations during the test drive.</li>
                        <li>You will not be under the influence of alcohol, drugs, or any substance that may impair your driving ability.</li>
                        <li>You will be liable for any damage caused to the vehicle due to negligence or misuse.</li>
                        <li>Toyota reserves the right to refuse a test drive to anyone for any reason.</li>
                        <li>Test drives are subject to vehicle availability and may be rescheduled if necessary.</li>
                    </ol>
                    
                    <h6>Privacy Policy</h6>
                    <p>The personal information collected will be used to process your test drive request and may be used for marketing purposes. We will not share your information with third parties without your consent.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Form validation
        document.getElementById('testDriveForm').addEventListener('submit', function(event) {
            const form = this;
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    </script>
</body>
</html></qodoArtifact>





## Test Drive Form Features

I've created a comprehensive test drive request form based on your outline, with the following features:

### Form Structure

1. **Header Section**
   - Toyota logo and title
   - Brief description of the form's purpose

2. **Responsibility Statement**
   - Highlighted statement about taking responsibility for the test drive

3. **Test Drive Details Section**
   - Test drive type (Walk-in or Schedule)
   - Preferred date and time
   - Vehicle model selection (dropdown with popular Toyota models)
   - Optional vehicle plate number field

4. **Customer Information Section**
   - Full name and contact details
   - Complete address
   - Email address
   - Driver's license information and validity date

5. **Terms and Submission**
   - Terms and conditions checkbox
   - Submit button with icon

### Design Elements

1. **Toyota Branding**
   - Used Toyota's signature red color (#E50000)
   - Included Toyota logo
   - Clean, professional design

2. **User-Friendly Features**
   - Clearly labeled form fields
   - Required field indicators
   - Section headers with icons
   - Responsive layout (works on mobile and desktop)

3. **Visual Enhancements**
   - Card-style form container with shadow
   - Styled section headers
   - Custom button styling
   - Highlighted responsibility statement

4. **Validation and Interaction**
   - Form validation for required fields
   - Terms and conditions modal
   - Interactive button hover effects

### Technical Implementation

1. **Modern Technologies**
   - HTML5 form elements
   - Bootstrap 5 for responsive layout
   - Font Awesome icons
   - Custom CSS for styling

2. **Accessibility**
   - Proper form labels
   - Semantic HTML structure
   - Responsive design for all devices

This form provides a complete solution for collecting test drive requests, with all the fields from your outline organized in a user-friendly, visually appealing layout.