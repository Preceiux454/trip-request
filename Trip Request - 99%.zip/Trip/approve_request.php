<?php
include 'db.php';
$data = json_decode(file_get_contents("php://input"));

$id = $data->id;
$status = $data->status;

$sql = "UPDATE trip_requests SET status='$status' WHERE id=$id";

if (mysqli_query($conn, $sql)) {
    echo "Request $status successfully!";
} else {
    echo "Error: " . mysqli_error($conn);
}
?>
