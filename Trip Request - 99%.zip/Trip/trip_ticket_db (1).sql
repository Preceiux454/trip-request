-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 09, 2025 at 10:01 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `trip_ticket_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `approvals`
--

CREATE TABLE `approvals` (
  `id` int(11) NOT NULL,
  `trip_id` int(11) NOT NULL,
  `approver_role` enum('manager','admin','hr') NOT NULL,
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `comment` text DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `approval_date` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `approvals`
--

INSERT INTO `approvals` (`id`, `trip_id`, `approver_role`, `status`, `comment`, `timestamp`, `approval_date`, `created_at`) VALUES
(47, 30, 'manager', 'Approved', 'Go Go Goooo!!!!!!!!!', '2025-03-09 12:39:15', NULL, '2025-03-09 12:45:53'),
(48, 30, 'admin', 'Approved', 'Ingat po', '2025-03-09 12:48:00', NULL, '2025-03-09 12:48:00'),
(49, 30, 'hr', 'Approved', 'kk', '2025-03-09 12:54:13', NULL, '2025-03-09 12:54:13'),
(50, 31, 'manager', 'Approved', 'go go gooo', '2025-03-09 13:01:34', NULL, '2025-03-09 13:11:45'),
(51, 31, 'admin', 'Approved', 'ocakes', '2025-03-09 13:12:22', NULL, '2025-03-09 13:12:22'),
(52, 31, 'hr', 'Rejected', 'sorry :<', '2025-03-09 13:13:37', NULL, '2025-03-09 13:13:37'),
(53, 32, 'manager', 'Pending', NULL, '2025-03-09 13:43:51', NULL, '2025-03-09 13:43:51'),
(54, 33, 'manager', 'Approved', 'nicee', '2025-03-09 13:51:40', NULL, '2025-03-09 20:41:43'),
(55, 33, 'admin', 'Approved', 'go go\\n', '2025-03-09 20:43:02', NULL, '2025-03-09 20:43:02');

-- --------------------------------------------------------

--
-- Table structure for table `trip_requests`
--

CREATE TABLE `trip_requests` (
  `id` int(11) NOT NULL,
  `requestor_name` varchar(255) NOT NULL,
  `department` enum('HR','IT','Finance','Operations') NOT NULL,
  `manager_id` int(11) NOT NULL,
  `date_needed` date NOT NULL,
  `time_needed` time NOT NULL,
  `time_return` time NOT NULL,
  `route_from` varchar(255) NOT NULL,
  `route_to` varchar(255) NOT NULL,
  `passengers` text NOT NULL,
  `purpose` text NOT NULL,
  `company_vehicle` enum('Yes','No') NOT NULL,
  `status` enum('Pending','Manager Approved','Admin Approved','Final Approved','Rejected') DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trip_requests`
--

INSERT INTO `trip_requests` (`id`, `requestor_name`, `department`, `manager_id`, `date_needed`, `time_needed`, `time_return`, `route_from`, `route_to`, `passengers`, `purpose`, `company_vehicle`, `status`, `created_at`) VALUES
(30, 'Mr. Lalong Tumatamis', 'IT', 15, '2025-03-10', '21:36:00', '09:36:00', 'Brgy. Milagrosa', 'Toyota Santa Rosa', 'Thomas Shelby , Gojo Satoru , Chae Lee', 'Business Meeting', 'Yes', 'Final Approved', '2025-03-09 12:39:15'),
(31, 'Mr. Gusto Ko Sakin Kalang ', 'IT', 8, '2025-03-18', '10:01:00', '12:01:00', 'Toyota Santa Rose', 'Sa Puso Mo <3 ', 'Lalong Tumatamis , Al James , Arvz', 'Secrett wala pong clue hehehe', 'Yes', 'Rejected', '2025-03-09 13:01:34'),
(32, 'Arvs', 'IT', 13, '2025-03-10', '21:43:00', '21:43:00', 'Santa Rosa ', 'Calamba', 'Arvs, Missy  , John', 'Secretttttttttttt', 'Yes', 'Pending', '2025-03-09 13:43:51'),
(33, 'Lalong Tumatamis', 'IT', 14, '2025-03-10', '21:51:00', '21:51:00', 'Santa', 'ROsyz', 'asd', 'asd', 'Yes', 'Admin Approved', '2025-03-09 13:51:40');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('Master Admin','User','Manager','Admin','HR Manager') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`) VALUES
(7, 'Lalong Tumatamis', 'lalongtumatamis@tsr.local', '$2y$10$yApWxIWQM6YIa/SLuc70CuM/o7/dfsYOlFiyb3NIUIyWZfF7XNS6e', 'Admin'),
(8, 'Gojo Satoru', 'gojo@tsr.local', '$2y$10$2PWqi3cHUaOftslLIQ7/NeVoOAsG9Um01QzEBYpxlG46kFb004UDy', 'Manager'),
(9, 'Valerica', 'valerica@tsr.local', '$2y$10$Iji4QGKrdzZmuaP.PeAswuzIqNbGSoI9iFQRVTYsXcGAn3vP3RAa2', 'HR Manager'),
(11, 'Dito Ka Sakin', 'ditoka@tsr.local', '$2y$10$9ML3lSja2ytUWPHbnx3nEeR.Rnl2lOI8tzZPa0FrGyKFiXPgjn8Zi', 'User'),
(12, 'Master Admin', 'admin_master@tsr.local', '$2y$10$PUmH9X3LRm.1qMx.VHlCS.8/7hNhx36wu9LDnUS2rGpj6lCNlLhlG', 'Master Admin'),
(13, 'Victor Schevalier', 'vic@tsr.local', '$2y$10$aNzVkQ4BsPD8s3oqSeNLoOSNCk6xrmUeXa3pO3IkvVOFxfVFZ6GZe', 'Manager'),
(14, 'Dainty', 'dainty@tsr.local', '$2y$10$e2ax0QpnBdzhv3nAYXDf6OpX2tj1dEauDdIejK4Hxg0.mbkACAc2m', 'Manager'),
(15, 'Marie', 'marie@tsr.local', '$2y$10$v3WleJGXud4D0ER7L8ZK2eDAvHpcIsF.u4ewvCLxWSMAZ0ASN1jXq', 'Manager'),
(16, 'AdminMaster', 'masteradmin@tsr.local', '$2y$10$UObkL9qEHz.5qwH34NhsGuuXjX6LnQMG5IOqQZQ6d2bWeD5uhuM5G', 'Master Admin');

-- --------------------------------------------------------

--
-- Table structure for table `vehicles`
--

CREATE TABLE `vehicles` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `plate_number` varchar(20) NOT NULL,
  `status` enum('Available','In Use','Maintenance') DEFAULT 'Available',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vehicles`
--

INSERT INTO `vehicles` (`id`, `name`, `plate_number`, `status`, `created_at`) VALUES
(6, 'Hilux GRS ', 'Ak1nkalan9', 'In Use', '2025-03-09 12:41:26'),
(7, 'Toyota GR86', 'B4byyy', 'Available', '2025-03-09 12:42:00'),
(8, 'Lamborghini Aventador', 'Dit0kaSakin', 'In Use', '2025-03-09 12:42:46'),
(9, 'Mercedes', 'Ocak3s', 'In Use', '2025-03-09 12:43:30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `approvals`
--
ALTER TABLE `approvals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_trip_approvals` (`trip_id`,`approver_role`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `trip_requests`
--
ALTER TABLE `trip_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `manager_id` (`manager_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `approvals`
--
ALTER TABLE `approvals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `trip_requests`
--
ALTER TABLE `trip_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `vehicles`
--
ALTER TABLE `vehicles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `approvals`
--
ALTER TABLE `approvals`
  ADD CONSTRAINT `approvals_ibfk_1` FOREIGN KEY (`trip_id`) REFERENCES `trip_requests` (`id`);

--
-- Constraints for table `trip_requests`
--
ALTER TABLE `trip_requests`
  ADD CONSTRAINT `trip_requests_ibfk_1` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
