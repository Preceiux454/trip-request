<?php
require '../db.php';
session_start();

header('Content-Type: application/json');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';

function sendAdminNotification($adminEmail, $requestor_name, $managerName, $comment) {
    $mail = new PHPMailer(true);
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;
        $mail->Username   = 'furfectmatch00@gmail.com';
        $mail->Password   = 'hshp joln vbgl yddk';

        // Recipients
        $mail->setFrom('furfectmatch00@gmail.com', 'Vehicle Request');
        $mail->addAddress($adminEmail);

        // Build email content
        $emailBody = "
        <b> <p style='font-family: Arial, sans-serif; font-size: 16px; color: #333;'>Good Day Admin!,</p></b>
        <p style='font-family: Arial, sans-serif; font-size: 16px; color: #333;'>A trip request has been approved by <b>{$managerName}</b>, and would require your approval.</p>
        <p style='font-family: Arial, sans-serif; font-size: 16px; color: #333;'><strong>Approval Details:</strong><br>
        -----------------------------------------------<br>
        <b>Requestor Name:</b> {$requestor_name}<br>
        <b>Manager:</b> {$managerName}<br>
        <b>Comment:</b> {$comment}<br>
        -----------------------------------------------</p><br>
    <p style='font-family: Arial, sans-serif; font-size: 16px; color: #333;'> <b> You may access this link: </b> <a href='http://localhost/Trip/login.php'>localhost/Trip/login.php</a></p>
       <b> <p style='font-family: Arial, sans-serif; font-size: 16px; color: #333;'>IMPORTANT: This is an automated notification. For technical assistance, please contact the IT Help Desk.</b></p>  ";

        // Email content
        $mail->isHTML(true);
        $mail->Subject = 'Vehicle Request - Admin Approval';
        $mail->Body    = $emailBody;
        
        $mail->send();

    } catch (Exception $e) {
        throw new Exception("Mailer Error: {$mail->ErrorInfo}");
    }
}

// Verify manager is logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Manager') {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized access']);
    exit();
}

try {
    if (!isset($_POST['id'])) {
        throw new Exception('Trip ID is required');
    }

    $trip_id = (int)$_POST['id'];
    $manager_id = (int)$_SESSION['id'];
    $comment = mysqli_real_escape_string($conn, $_POST['comment'] ?? '');

    mysqli_begin_transaction($conn);

    // First check if column exists
    $check_column = mysqli_query($conn, "SHOW COLUMNS FROM approvals LIKE 'created_at'");
    
    if (mysqli_num_rows($check_column) > 0) {
        // Use created_at if it exists
        $approval_query = "UPDATE approvals 
                          SET status = 'Approved', 
                              comment = ?, 
                              created_at = NOW() 
                          WHERE trip_id = ? 
                          AND approver_role = 'Manager'";
    } else {
        // Skip the created_at field if it doesn't exist
        $approval_query = "UPDATE approvals 
                          SET status = 'Approved', 
                              comment = ? 
                          WHERE trip_id = ? 
                          AND approver_role = 'Manager'";
    }
    
    $stmt = mysqli_prepare($conn, $approval_query);
    mysqli_stmt_bind_param($stmt, "si", $comment, $trip_id);
    
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Failed to update approval status: " . mysqli_error($conn));
    }

    // Check if all required approvals are complete
    $check_query = "SELECT COUNT(*) as pending 
                   FROM approvals 
                   WHERE trip_id = ? 
                   AND status = 'Pending'";
    
    $stmt = mysqli_prepare($conn, $check_query);
    mysqli_stmt_bind_param($stmt, "i", $trip_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);

    // If no pending approvals remain, update trip status to Approved
    if ($row['pending'] == 0) {
        $trip_query = "UPDATE trip_requests SET status = 'Approved' WHERE id = ?";
        $stmt = mysqli_prepare($conn, $trip_query);
        mysqli_stmt_bind_param($stmt, "i", $trip_id);
        
        if (!mysqli_stmt_execute($stmt)) {
            throw new Exception("Failed to update trip status: " . mysqli_error($conn));
        }
    }

    // Commit transaction
    mysqli_commit($conn);

    // Fetch admin email dynamically
    $admin_query = "SELECT email FROM users WHERE role = 'Admin' LIMIT 1";
    $admin_result = mysqli_query($conn, $admin_query);
    if ($admin_result && mysqli_num_rows($admin_result) > 0) {
        $adminData = mysqli_fetch_assoc($admin_result);
        $adminEmail = $adminData['email'];
    } else {
        throw new Exception("Admin email not found");
    }

    // Fetch requestor name dynamically
    $requestor_query = "SELECT requestor_name FROM trip_requests WHERE id = ? LIMIT 1";
    $stmt = mysqli_prepare($conn, $requestor_query);
    mysqli_stmt_bind_param($stmt, "i", $trip_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    if ($result && mysqli_num_rows($result) > 0) {
        $requestorData = mysqli_fetch_assoc($result);
        $requestor_name = $requestorData['requestor_name'];
    } else {
        throw new Exception("Requestor name not found");
    }

    // Send email notification to the admin
    $managerName = $_SESSION['name']; // Assuming manager's name is stored in session
    sendAdminNotification($adminEmail, $requestor_name, $managerName, $comment);

    echo json_encode(['status' => 'success']);

} catch (Exception $e) {
    mysqli_rollback($conn);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}

mysqli_close($conn);