<?php
require '../db.php';
session_start();

// Add this after the session_start()
function getStatusBadgeClass($status) {
    switch ($status) {
        case 'Approved':
            return 'badge-success';
        case 'Rejected':
            return 'badge-danger';
        case 'Pending':
            return 'badge-warning';
        default:
            return 'badge-secondary';
    }
}

// Verify manager role and session
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Manager') {
    header("Location: ../login.php");
    exit();
}

// Get manager details from session
$user_id = intval($_SESSION['id']);
$manager_name = htmlspecialchars($_SESSION['name'] ?? 'Unknown Manager');

// Update the existing query
$query = "SELECT t.*, u.name as manager_name,
          COALESCE(a.status, 'Pending') as approval_status,
          a.comment as manager_comment,
          (SELECT GROUP_CONCAT(CONCAT(approver_role, ':', status) SEPARATOR ';')
           FROM approvals 
           WHERE trip_id = t.id) as all_approvals
          FROM trip_requests t
          LEFT JOIN users u ON u.id = t.manager_id
          LEFT JOIN approvals a ON a.trip_id = t.id AND a.approver_role = 'manager'
          WHERE t.manager_id = ? AND t.archived = 0
          ORDER BY t.id DESC";

$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (!$result) {
    die("Database Query Failed: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manager Trip Requests</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../js/dashboard-common.js"></script>
    <style>
        .badge {
            font-size: 0.875rem;
            padding: 0.375rem 0.5rem;
        }
        .badge-success {
            background-color: #28a745;
        }
        .badge-danger {
            background-color: #dc3545;
        }
        .badge-warning {
            background-color: #ffc107;
            color: #212529;
        }
        .badge-secondary {
            background-color: #6c757d;
        }
          /* Sidebar Styling */
    .main-sidebar {
        background: #1a1a1a;
        box-shadow: 4px 0 10px rgba(0, 0, 0, 0.1);
        border-right: 1px solid rgba(255,255,255,0.1);
    }

    .brand-container {
        background: #ffffff;
        padding: 1.5rem;
        text-align: center;
        border-bottom: 1px solid rgba(0,0,0,0.1);
    }

    .brand-link {
        display: flex;
        flex-direction: column;
        align-items: center;
        text-decoration: none !important;
    }

    .brand-image {
        height: 50px;
        margin-bottom: 0.75rem;
        transition: transform 0.3s ease;
    }

    .brand-image:hover {
        transform: scale(1.05);
    }

    .brand-text {
        color: #1a1a1a;
        font-size: 1.2rem;
        font-weight: 600;
        text-align: center;
    }

    .nav-sidebar .nav-link {
        color: rgba(255,255,255,0.8);
        border-radius: 8px;
        margin: 0.25rem 1rem;
        transition: all 0.3s ease;
        padding: 0.75rem 1rem;
    }

    .nav-sidebar .nav-link:hover {
        color: #ffffff;
        background: rgba(255,255,255,0.1);
        transform: translateX(5px);
    }

    .nav-sidebar .nav-link.active {
        background: #dc3545;
        color: #ffffff;
        box-shadow: 0 2px 4px rgba(220,53,69,0.4);
    }

    .nav-sidebar .nav-link i {
        margin-right: 0.75rem;
        width: 1.25rem;
        text-align: center;
        transition: all 0.3s ease;
    }

    .nav-sidebar .nav-link:hover i {
        transform: translateX(3px);
    }

    /* Update existing badge styles */
    .badge {
        font-size: 0.875rem;
        padding: 0.375rem 0.5rem;
    }

    /* Update header styling */
    .content-header h1 {
        display: flex;
        align-items: center;
        font-size: 1.8rem;
        margin: 0;
    }

    .content-header h1 i {
        margin-right: 0.5rem;
    }

    .text-muted {
        font-size: 1rem;
    }

    .float-right h5 {
        margin: 0;
        padding: 10px;
        border-radius: 5px;
        background: rgba(0,0,0,0.05);
    }

    /* Loading indicator */
    #loadingIndicator {
        background: rgba(255,255,255,0.8);
        z-index: 1050;
    }
      /* Sidebar Styling */
    .main-sidebar {
        background: #1a1a1a;
        box-shadow: 4px 0 10px rgba(0, 0, 0, 0.1);
        border-right: 1px solid rgba(255,255,255,0.1);
    }

    .brand-container {
        background: #ffffff;
        padding: 1.5rem;
        text-align: center;
        border-bottom: 1px solid rgba(0,0,0,0.1);
    }

    .brand-link {
        display: flex;
        flex-direction: column;
        align-items: center;
        text-decoration: none !important;
    }

    .brand-image {
        height: 50px;
        margin-bottom: 0.75rem;
        transition: transform 0.3s ease;
    }

    .brand-image:hover {
        transform: scale(1.05);
    }

    .brand-text {
        color: #1a1a1a;
        font-size: 1.2rem;
        font-weight: 600;
        text-align: center;
    }

    .nav-sidebar .nav-link {
        color: rgba(255,255,255,0.8);
        border-radius: 8px;
        margin: 0.25rem 1rem;
        transition: all 0.3s ease;
        padding: 0.75rem 1rem;
    }

    .nav-sidebar .nav-link:hover {
        color: #ffffff;
        background: rgba(255,255,255,0.1);
        transform: translateX(5px);
    }

    .nav-sidebar .nav-link.active {
        background: #dc3545;
        color: #ffffff;
        box-shadow: 0 2px 4px rgba(220,53,69,0.4);
    }

    .nav-sidebar .nav-link i {
        margin-right: 0.75rem;
        width: 1.25rem;
        text-align: center;
        transition: all 0.3s ease;
    }

    .nav-sidebar .nav-link:hover i {
        transform: translateX(3px);
    }

    /* Update existing badge styles */
    .badge {
        font-size: 0.875rem;
        padding: 0.375rem 0.5rem;
    }

    /* Update header styling */
    .content-header h1 {
        display: flex;
        align-items: center;
        font-size: 1.8rem;
        margin: 0;
    }

    .content-header h1 i {
        margin-right: 0.5rem;
    }

    .text-muted {
        font-size: 1rem;
    }

    .float-right h5 {
        margin: 0;
        padding: 10px;
        border-radius: 5px;
        background: rgba(255, 255, 255, 0.05);
    }

    /* Loading indicator */
    #loadingIndicator {
        background: rgba(255,255,255,0.8);
        z-index: 1050;
    }
        
    </style>
</head>
<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <!-- Include Manager Sidebar -->
        <?php include 'inc/manager_sidebar.php'; ?>

        <div class="content-wrapper">
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0">Pending Trip Requests</h1>
                        </div>
                        <div class="col-sm-6">
                            <div class="float-right">
                                <h5 class="text-muted">
                                    <i class="fas fa-user"></i> Bonjour, <?php echo $manager_name; ?>!
                                </h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <section class="content">
                <div class="container-fluid">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fas fa-list"></i> My Assigned Trip Requests</h3>
                        </div>
                        <div class="card-body">
                            <table class="table table-bordered table-hover" id="tripRequestsTable">
                                <thead class="thead-dark">
                                    <tr>
                                        <th>ID</th>
                                        <th>Requestor</th>
                                        <th>Department</th>
                                        <th>Route</th>
                                        <th>Date Needed</th>
                                        <th>Time Needed</th>
                                        <th>Passengers</th>
                                        <th>Purpose</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                                        <tr>
                                            <td><?= $row['id'] ?></td>
                                            <td><?= htmlspecialchars($row['requestor_name']) ?></td>
                                            <td><?= $row['department'] ?></td>
                                            <td><?= htmlspecialchars($row['route_from']) ?> ➝ <?= htmlspecialchars($row['route_to']) ?></td>
                                            <td><?= date('M d, Y', strtotime($row['date_needed'])) ?></td>
                                            <td><?= date('h:i A', strtotime($row['time_needed'])) ?></td>
                                            <td><?= htmlspecialchars($row['passengers']) ?></td>
                                            <td><?= htmlspecialchars($row['purpose']) ?></td>
                                            <td>
                                                <span class="badge <?= getStatusBadgeClass($row['approval_status']) ?>">
                                                    <?= htmlspecialchars($row['approval_status']) ?>
                                                </span>
                                            </td>
                                            <td>
                                                <button class="btn btn-sm btn-info view-trip-btn" data-id="<?= $row['id'] ?>">
                                                    <i class="fas fa-eye"></i> View
                                                </button>
                                                <button class="btn btn-sm btn-success approve-btn" data-id="<?= $row['id'] ?>" 
                                                        data-manager="<?= htmlspecialchars($manager_name) ?>"
                                                        data-current-status="<?= $row['approval_status'] ?>"
                                                        data-current-comment="<?= htmlspecialchars($row['manager_comment'] ?? '') ?>">
                                                    <i class="fas fa-check"></i> <?= $row['approval_status'] === 'Approved' ? 'Update Approval' : 'Approve' ?>
                                                </button>
                                                <button class="btn btn-sm btn-danger reject-btn" data-id="<?= $row['id'] ?>"
                                                        data-current-status="<?= $row['approval_status'] ?>"
                                                        data-current-comment="<?= htmlspecialchars($row['manager_comment'] ?? '') ?>">
                                                    <i class="fas fa-times"></i> <?= $row['approval_status'] === 'Rejected' ? 'Update Rejection' : 'Reject' ?>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                            <div id="loadingIndicator" style="display:none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);">
                                <div class="spinner-border text-primary" role="status">
                                    <span class="sr-only">Loading...</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    
<!-- Trip Details Modal -->
<div class="modal fade" id="tripDetailsModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="fas fa-clipboard-check mr-2"></i>Trip Request Details</h5>
                <button type="button" class="close text-white" data-dismiss="modal">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body px-4 py-4">
                <!-- Request Information Card -->
                <div class="card shadow-sm mb-4 border-0">
                    <div class="card-header bg-light">
                        <h6 class="mb-0"><i class="fas fa-info-circle mr-2"></i>Request Information</h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="info-group mb-3">
                                    <label class="text-muted small text-uppercase">Requestor</label>
                                    <p class="font-weight-bold mb-1" id="modal-requestor"></p>
                                </div>
                                <div class="info-group mb-3">
                                    <label class="text-muted small text-uppercase">Email</label>
                                    <p class="font-weight-bold mb-1" id="modal-requestor_email"></p>
                                </div>
                                <div class="info-group mb-3">
                                    <label class="text-muted small text-uppercase">Department</label>
                                    <p class="font-weight-bold mb-1" id="modal-department"></p>
                                </div>
                                <div class="info-group mb-3">
                                    <label class="text-muted small text-uppercase">Date Needed</label>
                                    <p class="font-weight-bold mb-1" id="modal-date"></p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="info-group mb-3">
                                    <label class="text-muted small text-uppercase">Time Needed</label>
                                    <p class="font-weight-bold mb-1" id="modal-time"></p>
                                </div>
                                <div class="info-group mb-3">
                                    <label class="text-muted small text-uppercase">Return Time</label>
                                    <p class="font-weight-bold mb-1" id="modal-time-return"></p>
                                </div>
                                <div class="info-group mb-3">
                                    <label class="text-muted small text-uppercase">Company Vehicle</label>
                                    <p class="font-weight-bold mb-1" id="modal-company-vehicle"></p>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="info-group mb-3">
                                    <label class="text-muted small text-uppercase">Route From</label>
                                    <p class="font-weight-bold mb-1" id="modal-route-from"></p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="info-group mb-3">
                                    <label class="text-muted small text-uppercase">Route To</label>
                                    <p class="font-weight-bold mb-1" id="modal-route-to"></p>
                                </div>
                            </div>
                        </div>
                        <div class="info-group">
                            <label class="text-muted small text-uppercase">Passengers</label>
                            <p class="font-weight-bold mb-0" id="modal-passengers"></p>
                        </div>
                    </div>
                </div>

                <!-- Purpose Card -->
                <div class="card shadow-sm mb-4 border-0">
                    <div class="card-header bg-light">
                        <h6 class="mb-0"><i class="fas fa-bullseye mr-2"></i>Purpose</h6>
                    </div>
                    <div class="card-body">
                        <p id="modal-purpose" class="mb-0"></p>
                    </div>
                </div>

                <!-- Approval Status Card -->
                <div class="card shadow-sm mb-4 border-0">
                    <div class="card-header bg-light">
                        <h6 class="mb-0"><i class="fas fa-check-circle mr-2"></i>Approval Status</h6>
                    </div>
                    <div class="card-body p-0">
                        <!-- Manager Section -->
                        <div class="p-3 border-bottom">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <h6 class="text-primary mb-0">
                                    <i class="fas fa-user-tie mr-2"></i>Manager
                                </h6>
                                <span id="manager-status-comment" class="badge"></span>
                            </div>
                            <div class="ml-4">
                                <p class="mb-1"><span class="text-muted">Name:</span> <span id="modal-manager-name"></span></p>
                                <p class="mb-1"><span class="text-muted">Role:</span> <span id="modal-manager-role"></span></p>
                                <p class="mb-1"><span class="text-muted">Comment:</span> <span id="manager-comment"></span></p>
                                <p class="mb-0 small text-muted">Approval Date: <span id="manager-comment-date"></span></p>
                            </div>
                        </div>

                        <!-- Admin Section -->
                        <div class="p-3 border-bottom">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <h6 class="text-primary mb-0">
                                    <i class="fas fa-user-cog mr-2"></i>Admin
                                </h6>
                                <span id="admin-status-comment" class="badge"></span>
                            </div>
                            <div class="ml-4">
                                <p class="mb-1"><span class="text-muted">Name:</span> <span id="modal-admin-name"></span></p>
                                <p class="mb-1"><span class="text-muted">Role:</span> <span id="modal-admin-role"></span></p>
                                
                                <!-- Vehicle and Driver Information Section -->
                                <div class="transport-info my-3">
                                    <div id="admin-vehicle-info" class="mb-2"></div>
                                    <div id="admin-driver-info" class="mb-2"></div>
                                </div>
                                
                                <p class="mb-1"><span class="text-muted">Comment:</span> <span id="admin-comment"></span></p>
                                <p class="mb-0 small text-muted">Approval Date: <span id="admin-comment-date"></span></p>
                            </div>
                        </div>

                        <!-- HR Section -->
                        <div class="p-3">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <h6 class="text-primary mb-0">
                                    <i class="fas fa-user-shield mr-2"></i>HR Manager
                                </h6>
                                <span id="hr-status-comment" class="badge"></span>
                            </div>
                            <div class="ml-4">
                                <p class="mb-1"><span class="text-muted">Name:</span> <span id="modal-hr-name"></span></p>
                                <p class="mb-1"><span class="text-muted">Role:</span> <span id="modal-hr-role"></span></p>
                                <p class="mb-1"><span class="text-muted">Comment:</span> <span id="hr-comment"></span></p>
                                <p class="mb-0 small text-muted">Approval Date: <span id="hr-comment-date"></span></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer bg-light">
                <button type="button" class="btn btn-secondary rounded-pill px-4" data-dismiss="modal">
                    <i class="fas fa-times mr-2"></i>Close
                </button>
            </div>
        </div>
    </div>
</div>

    <!-- Include the shared modal -->
    <?php include '../js/trip-details-modal.js'; ?>

    <script>
        $(".approve-btn").click(function() {
            let id = $(this).data("id");
            let currentStatus = $(this).data("current-status");
            let currentComment = $(this).data("current-comment");
            
            Swal.fire({
                title: currentStatus === 'Approved' ? 'Update Approval' : 'Approve Trip Request',
                input: 'textarea',
                inputLabel: 'Comments (optional)',
                inputPlaceholder: 'Add any comments here...',
                inputValue: currentComment,
                showCancelButton: true,
                confirmButtonText: currentStatus === 'Approved' ? 'Update' : 'Approve',
                confirmButtonColor: '#28a745',
                showLoaderOnConfirm: true,
                preConfirm: (comment) => {
                    return $.ajax({
                        url: "approve_trip.php",
                        method: "POST",
                        data: { 
                            id: id,
                            comment: comment || ''
                        },
                        dataType: 'json'
                    }).then(response => {
                        if (response.status !== 'success') {
                            throw new Error(response.message || 'Failed to approve trip');
                        }
                        return response;
                    }).catch(error => {
                        Swal.showValidationMessage(error.message);
                    });
                },
                allowOutsideClick: () => !Swal.isLoading()
            }).then((result) => {
                if (result.isConfirmed) {
                    // Archive the trip after approval
                    $.ajax({
                        url: "archive_trip.php",
                        method: "POST",
                        data: { trip_id: id },
                        dataType: 'json'
                    }).then(archiveResponse => {
                        if (archiveResponse.status === 'success') {
                            Swal.fire({
                                title: "Success!",
                                text: "Trip request has been approved and archived",
                                icon: "success",
                                timer: 2000,
                                showConfirmButton: false
                            }).then(() => {
                                window.location.href = 'archived_trips.php';
                            });
                        } else {
                            throw new Error('Failed to archive trip');
                        }
                    }).catch(error => {
                        Swal.fire('Error', error.message, 'error');
                    });
                }
            });
        });
        
// Function to update modal content
function updateModalContent(tripData) {
    console.log('Updating modal with data:', tripData);
    
  // Format time function to display in 24-hour format
  function formatTime(timeString) {
        if (!timeString) return 'N/A';
        
        try {
            // Parse the time string
            const [hours, minutes] = timeString.split(':').map(num => parseInt(num, 10));
            
            if (isNaN(hours) || isNaN(minutes)) {
                return 'Invalid Time';
            }
            
            // Format in 24-hour format: "13:30" or "09:05"
            const displayHours = hours.toString().padStart(2, '0');
            const displayMinutes = minutes.toString().padStart(2, '0');
            
            return `${displayHours}:${displayMinutes}`;
        } catch (error) {
            console.error('Time formatting error:', error);
            return 'Invalid Time Format';
        }
    }
    
    // Basic trip information
    $('#modal-requestor').text(tripData.requestor_name || 'N/A');
    $('#modal-requestor_email').text(tripData.requestor_email || 'N/A');
    $('#modal-department').text(tripData.department || 'N/A');
    $('#modal-date').text(tripData.date_needed || 'N/A');
    $('#modal-time').text(formatTime(tripData.time_needed) || 'N/A');
    $('#modal-time-return').text(formatTime(tripData.time_return) || 'N/A');
    $('#modal-company-vehicle').text(tripData.company_vehicle || 'N/A');
    $('#modal-route-from').text(tripData.route_from || 'N/A');
    $('#modal-route-to').text(tripData.route_to || 'N/A');
    $('#modal-passengers').text(tripData.passengers || 'N/A');
    $('#modal-purpose').text(tripData.purpose || 'N/A');

    // Manager approval information
    const manager = tripData.approvers.manager;
    $('#modal-manager-name').text(manager.name || 'Not Assigned');
    $('#modal-manager-role').text(manager.role || 'N/A');
    
    if (manager.status) {
        const managerStatusBadge = `<span class="badge ${DashboardManager.getStatusBadgeClass(manager.status)}">${manager.status}</span>`;
        $('#manager-status-comment').html(managerStatusBadge);
    } else {
        $('#manager-status-comment').text('Pending');
    }
    
    $('#manager-comment').text(manager.comment || 'No comment');
    $('#manager-comment-date').text(manager.date || 'N/A');

    // Admin approval information
    const admin = tripData.approvers.admin;
    $('#modal-admin-name').text(admin.name || 'Not Assigned');
    $('#modal-admin-role').text(admin.role || 'N/A');
    
    if (admin.status) {
        const adminStatusBadge = `<span class="badge ${DashboardManager.getStatusBadgeClass(admin.status)}">${admin.status}</span>`;
        $('#admin-status-comment').html(adminStatusBadge);
    } else {
        $('#admin-status-comment').text('Pending');
    }
    
    $('#admin-comment').text(admin.comment || 'No comment');
    $('#admin-comment-date').text(admin.date || 'N/A');

    // Vehicle and Driver information (if assigned by admin)
    if (tripData.company_vehicle === 'Yes') {
        let vehicleInfo = '';
        let driverInfo = '';
        
        // Add vehicle information if available
        if (admin.vehicle && admin.vehicle.name) {
            vehicleInfo = `
                <div class="alert alert-info mb-2">
                    <h6 class="mb-2"><i class="fas fa-car"></i> Vehicle Information</h6>
                    <p class="mb-1"><strong>Vehicle:</strong> ${admin.vehicle.name}</p>
                    <p class="mb-1"><strong>Plate Number:</strong> ${admin.vehicle.plate_number || 'Not provided'}</p>
                    <p class="mb-0"><strong>Status:</strong> 
                        <span class="badge ${DashboardManager.getStatusBadgeClass(admin.vehicle.status)}">${admin.vehicle.status || 'Pending'}</span>
                    </p>
                </div>
            `;
        }
        
        // Add driver information if available
        if (admin.driver && admin.driver.name) {
            driverInfo = `
                <div class="alert alert-secondary mb-2">
                    <h6 class="mb-2"><i class="fas fa-user"></i> Driver Information</h6>
                    <p class="mb-1"><strong>Name:</strong> ${admin.driver.name}</p>
                    <p class="mb-1"><strong>Contact:</strong> ${admin.driver.contact || 'Not provided'}</p>
                    <p class="mb-1"><strong>License:</strong> ${admin.driver.license || 'Not provided'}</p>
                    <p class="mb-0"><strong>Status:</strong> 
                        <span class="badge ${DashboardManager.getStatusBadgeClass(admin.driver.status)}">${admin.driver.status || 'Available'}</span>
                    </p>
                </div>
            `;
        }
        
        // Display vehicle and driver information separately
        $('#admin-vehicle-info').html(vehicleInfo);
        $('#admin-driver-info').html(driverInfo);
    } else {
        // If company vehicle is not requested, show a message
        $('#admin-vehicle-info').html('<div class="alert alert-light">No company vehicle requested</div>');
        $('#admin-driver-info').empty();
    }

    // HR Manager approval information
    const hr = tripData.approvers.hr_manager;
    $('#modal-hr-name').text(hr.name || 'Not Assigned');
    $('#modal-hr-role').text(hr.role || 'N/A');
    
    if (hr.status) {
        const hrStatusBadge = `<span class="badge ${DashboardManager.getStatusBadgeClass(hr.status)}">${hr.status}</span>`;
        $('#hr-status-comment').html(hrStatusBadge);
    } else {
        $('#hr-status-comment').text('Pending');
    }
    
    $('#hr-comment').text(hr.comment || 'No comment');
    $('#hr-comment-date').text(hr.date || 'N/A');
}

        $(".reject-btn").click(function() {
            let id = $(this).data("id");
            let currentStatus = $(this).data("current-status");
            let currentComment = $(this).data("current-comment");
            
            Swal.fire({
                title: currentStatus === 'Rejected' ? 'Update Rejection' : 'Reject Trip Request',
                input: 'textarea',
                inputLabel: 'Reason for Rejection',
                inputPlaceholder: 'Please provide a reason...',
                inputValue: currentComment, // Pre-fill with existing comment
                inputValidator: (value) => {
                    if (!value) {
                        return 'You need to provide a reason for rejection!';
                    }
                },
                showCancelButton: true,
                confirmButtonText: currentStatus === 'Rejected' ? 'Update' : 'Reject',
                confirmButtonColor: '#dc3545',
                icon: "warning"
            }).then((result) => {
                if (result.isConfirmed) {
                    $.post("reject_trip.php", { 
                        id: id,
                        comment: result.value
                    }, function(response) {
                        if (response.status === 'success') {
                            // Archive the trip after rejection
                            $.post("archive_trip.php", { trip_id: id }, function(archiveResponse) {
                                if (archiveResponse.status === 'success') {
                                    Swal.fire({
                                        title: "Success",
                                        text: "Trip rejected and archived!",
                                        icon: "info",
                                        timer: 2000
                                    }).then(() => {
                                        window.location.href = 'archived_trips.php';
                                    });
                                }
                            });
                        }
                    });
                }
            });
        });

        function loadTripRequests() {
            $.ajax({
                url: '../fetch_manager_trips.php',
                method: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.error) {
                        Swal.fire('Error', response.error, 'error');
                        return;
                    }
                    
                    let tableRows = '';
                    if (response.length === 0) {
                        tableRows = '<tr><td colspan="9" class="text-center">No trip requests found</td></tr>';
                    } else {
                        response.forEach(request => {
                            tableRows += generateTableRow(request);
                        });
                    }
                    
                    $('#tripRequestsTable').fadeOut(200, function() {
                        $(this).html(tableRows).fadeIn(200);
                    });
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', error);
                }
            });
        }

        // Initialize dashboard
        setupDashboard({ loadFunction: loadTripRequests });
        
        $(document).ready(function() {
            // Initialize modal handler
            if (typeof ModalHandler !== 'undefined') {
                ModalHandler.init();
            } else {
                console.error('ModalHandler not loaded');
            }
            
            // Setup dashboard with error handling
            try {
                DashboardManager.setupDashboard({ 
                    loadFunction: loadTripRequests 
                });
            } catch (e) {
                console.error('Dashboard setup error:', e);
            }
        });
    </script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/js/adminlte.min.js"></script>
    <script src="../js/dashboard-common.js"></script>
    <script src="../js/modal-handler.js"></script>

    <!-- Trip Details Modal -->
    <div class="modal fade" id="tripDetailsModal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg">
            <div class="modal-content border-0 shadow">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title"><i class="fas fa-clipboard-check mr-2"></i>Trip Request Details</h5>
                    <button type="button" class="close text-white" data-dismiss="modal">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body px-4 py-4">
                    <!-- Request Information Card -->
                    <div class="card shadow-sm mb-4 border-0">
                        <!-- Same content structure as admin_master_dash.php -->
                        <!-- ... copy the modal body content from admin_master_dash.php ... -->
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary rounded-pill px-4" data-dismiss="modal">
                        <i class="fas fa-times mr-2"></i>Close
                    </button>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
