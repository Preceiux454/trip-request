<?php
require '../db.php';
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Manager') {
    header("Location: ../login.php");
    exit();
}

$user_id = intval($_SESSION['id']);
$manager_name = htmlspecialchars($_SESSION['name'] ?? 'Unknown Manager');

// Query for archived trips
$query = "SELECT t.*, u.name as manager_name,
          COALESCE(a.status, 'Pending') as approval_status,
          a.comment as manager_comment,
          t.archive_date
          FROM trip_requests t
          LEFT JOIN users u ON u.id = t.manager_id
          LEFT JOIN approvals a ON a.trip_id = t.id AND a.approver_role = 'manager'
          WHERE t.manager_id = ? AND t.archived = 1
          ORDER BY t.archive_date DESC";

$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Archived Trip Requests</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        .badge { font-size: 0.875rem; padding: 0.375rem 0.5rem; }
        .archive-date { color: #6c757d; font-size: 0.875rem; }
         /* Sidebar Styling */
    .main-sidebar {
        background: #1a1a1a;
        box-shadow: 4px 0 10px rgba(0, 0, 0, 0.1);
        border-right: 1px solid rgba(255,255,255,0.1);
    }

    .brand-container {
        background: #ffffff;
        padding: 1.5rem;
        text-align: center;
        border-bottom: 1px solid rgba(0,0,0,0.1);
    }

    .brand-link {
        display: flex;
        flex-direction: column;
        align-items: center;
        text-decoration: none !important;
    }

    .brand-image {
        height: 50px;
        margin-bottom: 0.75rem;
        transition: transform 0.3s ease;
    }

    .brand-image:hover {
        transform: scale(1.05);
    }

    .brand-text {
        color: #1a1a1a;
        font-size: 1.2rem;
        font-weight: 600;
        text-align: center;
    }

    .nav-sidebar .nav-link {
        color: rgba(255,255,255,0.8);
        border-radius: 8px;
        margin: 0.25rem 1rem;
        transition: all 0.3s ease;
        padding: 0.75rem 1rem;
    }

    .nav-sidebar .nav-link:hover {
        color: #ffffff;
        background: rgba(255,255,255,0.1);
        transform: translateX(5px);
    }

    .nav-sidebar .nav-link.active {
        background: #dc3545;
        color: #ffffff;
        box-shadow: 0 2px 4px rgba(220,53,69,0.4);
    }

    .nav-sidebar .nav-link i {
        margin-right: 0.75rem;
        width: 1.25rem;
        text-align: center;
        transition: all 0.3s ease;
    }

    .nav-sidebar .nav-link:hover i {
        transform: translateX(3px);
    }

    /* Update existing badge styles */
    .badge {
        font-size: 0.875rem;
        padding: 0.375rem 0.5rem;
    }

    /* Update header styling */
    .content-header h1 {
        display: flex;
        align-items: center;
        font-size: 1.8rem;
        margin: 0;
    }

    .content-header h1 i {
        margin-right: 0.5rem;
    }

    .text-muted {
        font-size: 1rem;
    }

    .float-right h5 {
        margin: 0;
        padding: 10px;
        border-radius: 5px;
        background: rgba(0,0,0,0.05);
    }

    /* Loading indicator */
    #loadingIndicator {
        background: rgba(255,255,255,0.8);
        z-index: 1050;
    }
      /* Sidebar Styling */
    .main-sidebar {
        background: #1a1a1a;
        box-shadow: 4px 0 10px rgba(0, 0, 0, 0.1);
        border-right: 1px solid rgba(255,255,255,0.1);
    }

    .brand-container {
        background: #ffffff;
        padding: 1.5rem;
        text-align: center;
        border-bottom: 1px solid rgba(0,0,0,0.1);
    }

    .brand-link {
        display: flex;
        flex-direction: column;
        align-items: center;
        text-decoration: none !important;
    }

    .brand-image {
        height: 50px;
        margin-bottom: 0.75rem;
        transition: transform 0.3s ease;
    }

    .brand-image:hover {
        transform: scale(1.05);
    }

    .brand-text {
        color: #1a1a1a;
        font-size: 1.2rem;
        font-weight: 600;
        text-align: center;
    }

    .nav-sidebar .nav-link {
        color: rgba(255,255,255,0.8);
        border-radius: 8px;
        margin: 0.25rem 1rem;
        transition: all 0.3s ease;
        padding: 0.75rem 1rem;
    }

    .nav-sidebar .nav-link:hover {
        color: #ffffff;
        background: rgba(255,255,255,0.1);
        transform: translateX(5px);
    }

    .nav-sidebar .nav-link.active {
        background: #dc3545;
        color: #ffffff;
        box-shadow: 0 2px 4px rgba(220,53,69,0.4);
    }

    .nav-sidebar .nav-link i {
        margin-right: 0.75rem;
        width: 1.25rem;
        text-align: center;
        transition: all 0.3s ease;
    }

    .nav-sidebar .nav-link:hover i {
        transform: translateX(3px);
    }

    /* Update existing badge styles */
    .badge {
        font-size: 0.875rem;
        padding: 0.375rem 0.5rem;
    }

    /* Update header styling */
    .content-header h1 {
        display: flex;
        align-items: center;
        font-size: 1.8rem;
        margin: 0;
    }

    .content-header h1 i {
        margin-right: 0.5rem;
    }

    .text-muted {
        font-size: 1rem;
    }

    .float-right h5 {
        margin: 0;
        padding: 10px;
        border-radius: 5px;
        background: rgba(255, 255, 255, 0.05);
    }

    /* Loading indicator */
    #loadingIndicator {
        background: rgba(255,255,255,0.8);
        z-index: 1050;
    }
        
    </style>
</head>
<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <?php include 'inc/manager_sidebar.php'; ?>
        
        <div class="content-wrapper">
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1><i class="fas fa-archive text-dark mr-2"></i> Archived Requests</h1>
                        </div>
                        <div class="col-sm-6">
                            <div class="float-right">
                                <h5 class="text-muted">
                                    <i class="fas fa-user mr-2"></i> 
                                    Bonjour, <?php echo $manager_name; ?>!
                                </h5>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section class="content">
                <div class="container-fluid">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fas fa-list"></i> Archived Trip Requests</h3>
                        </div>
                        <div class="card-body">
                            <!-- Add filters similar to admin master -->
                            <div class="row mb-3">
                                <div class="col-md-3">
                                    <input type="text" id="searchInput" class="form-control" placeholder="Search...">
                                </div>
                                <div class="col-md-3">
                                    <select id="statusFilter" class="form-control">
                                        <option value="">All Statuses</option>
                                        <option value="Approved">Approved</option>
                                        <option value="Rejected">Rejected</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <input type="date" id="dateFilter" class="form-control">
                                </div>
                                <div class="col-md-3">
                                    <button id="resetFilters" class="btn btn-secondary">
                                        <i class="fas fa-undo"></i> Reset Filters
                                    </button>
                                </div>
                            </div>
                            
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Requestor</th>
                                        <th>Route</th>
                                        <th>Date Needed</th>
                                        <th>Purpose</th>
                                        <th>Archive Date</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                                        <tr>
                                            <td><?= $row['id'] ?></td>
                                            <td><?= htmlspecialchars($row['requestor_name']) ?></td>
                                            <td><?= htmlspecialchars($row['route_from']) ?> → <?= htmlspecialchars($row['route_to']) ?></td>
                                            <td><?= date('M d, Y', strtotime($row['date_needed'])) ?></td>
                                            <td><?= htmlspecialchars($row['purpose']) ?></td>
                                            <td class="archive-date"><?= date('M d, Y h:i A', strtotime($row['archive_date'])) ?></td>
                                            <td><span class="badge badge-success">Archived</span></td>
                                            <td>
                                                <button class="btn btn-sm btn-info view-trip-btn" data-id="<?= $row['id'] ?>">
                                                    <i class="fas fa-eye"></i> View Details
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <?php include '../inc/trip_details_modal.php'; ?>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/js/adminlte.min.js"></script>
<script src="../js/dashboard-common.js"></script>
<script src="../js/modal-handler.js"></script>
    <script>
        // Add the same modal HTML and JavaScript code as above

        // Update your table row generation for archived trips
        function generateArchivedTableRow(request) {
            const viewButton = `
                <button type="button" 
                        class="btn btn-primary btn-sm view-trip-details" 
                        data-id="${request.id}" 
                        onclick="viewTripDetails(${request.id})">
                    <i class="fas fa-eye"></i> View
                </button>
            `;
            
            return `<tr>
                <!-- Your archived trip columns -->
                <td class="text-center">
                    ${viewButton}
                </td>
            </tr>`;
        }
    </script>
</body>
</html>
