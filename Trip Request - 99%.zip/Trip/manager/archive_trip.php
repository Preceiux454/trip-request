<?php
session_start();
require_once '../db.php';

if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'Manager') {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized access']);
    exit;
}

if (!isset($_POST['trip_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Missing trip ID']);
    exit;
}

$trip_id = intval($_POST['trip_id']);
$archive_date = date('Y-m-d H:i:s');

$query = "UPDATE trip_requests SET archived = 1, archive_date = ? WHERE id = ? AND manager_id = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "sii", $archive_date, $trip_id, $_SESSION['id']);

if (mysqli_stmt_execute($stmt)) {
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => mysqli_error($conn)]);
}

mysqli_close($conn);