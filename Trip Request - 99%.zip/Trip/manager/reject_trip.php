<?php
require '../db.php';
session_start();

header('Content-Type: application/json');

// Verify manager is logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Manager') {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized access']);
    exit();
}

try {
    if (!isset($_POST['id']) || !isset($_POST['comment'])) {
        throw new Exception('Trip ID and comment are required');
    }

    $trip_id = (int)$_POST['id'];
    $manager_id = (int)$_SESSION['id'];
    $comment = mysqli_real_escape_string($conn, $_POST['comment']);

    mysqli_begin_transaction($conn);

    // Update approval status using created_at instead of approval_date
    $approval_query = "UPDATE approvals 
                      SET status = 'Rejected', 
                          comment = ?, 
                          created_at = NOW() 
                      WHERE trip_id = ? 
                      AND approver_role = 'Manager'";
    
    $stmt = mysqli_prepare($conn, $approval_query);
    mysqli_stmt_bind_param($stmt, "si", $comment, $trip_id);
    
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Failed to update approval status");
    }

    // Update trip request status
    $trip_query = "UPDATE trip_requests SET status = 'Rejected' WHERE id = ?";
    $stmt = mysqli_prepare($conn, $trip_query);
    mysqli_stmt_bind_param($stmt, "i", $trip_id);
    
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Failed to update trip status");
    }

    mysqli_commit($conn);
    echo json_encode(['status' => 'success']);

} catch (Exception $e) {
    mysqli_rollback($conn);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}

mysqli_close($conn);