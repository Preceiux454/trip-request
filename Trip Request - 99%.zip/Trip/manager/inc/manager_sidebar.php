<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <div class="brand-container">
        <a href="manager_dash.php" class="brand-link">
            <img src="../img/logo.png" alt="Toyota Logo" class="brand-image">
            <span class="brand-text">VEHICLE REQUEST SYSTEM</span>
        </a>
    </div>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu">
                <!-- Dashboard -->
                <li class="nav-item">
                    <a href="manager_dash.php" class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'manager_dash.php') ? 'active' : '' ?>">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>Request Dashboard</p>
                    </a>
                </li>

           
                <!-- Archived Requests -->
                <li class="nav-item">
                    <a href="archived_trips.php" class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'archived_trips.php') ? 'active' : '' ?>">
                        <i class="nav-icon fas fa-archive"></i>
                        <p>Archived Requests</p>
                    </a>
                </li>

                

                <!-- Logout -->
                <li class="nav-item mt-auto">
                    <a href="../logout.php" class="nav-link text-danger">
                        <i class="nav-icon fas fa-sign-out-alt"></i>
                        <p>Logout</p>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</aside>