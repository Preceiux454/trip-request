<!-- Trip Details Modal -->
<div class="modal fade" id="tripDetailsModal" tabindex="-1" role="dialog" aria-labelledby="tripDetailsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="tripDetailsModalLabel">Trip Request Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- Basic Trip Information -->
                <div class="card mb-3">
                    <div class="card-header bg-primary text-white">
                        <h6 class="mb-0">Basic Information</h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <p><strong>Requestor:</strong> <span id="modal-requestor"></span></p>
                                <p><strong>Email:</strong> <span id="modal-requestor_email"></span></p>
                                <p><strong>Department:</strong> <span id="modal-department"></span></p>
                                <p><strong>Date Needed:</strong> <span id="modal-date"></span></p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>Time Needed:</strong> <span id="modal-time"></span></p>
                                <p><strong>Return Time:</strong> <span id="modal-time-return"></span></p>
                                <p><strong>Route:</strong> <span id="modal-route-from"></span> to <span id="modal-route-to"></span></p>
                                <p><strong>Passengers:</strong> <span id="modal-passengers"></span></p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <p><strong>Purpose:</strong> <span id="modal-purpose"></span></p>
                                <p><strong>Company Vehicle:</strong> <span id="modal-company-vehicle"></span></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Approval Status -->
                <div class="card mb-3">
                    <div class="card-header bg-info text-white">
                        <h6 class="mb-0">Approval Status</h6>
                    </div>
                    <div class="card-body">
                        <!-- Manager Approval -->
                        <div class="approval-section mb-3">
                            <h6>Manager Approval</h6>
                            <div class="row">
                                <div class="col-md-4">
                                    <p><strong>Name:</strong> <span id="modal-manager-name"></span></p>
                                    <p><strong>Role:</strong> <span id="modal-manager-role"></span></p>
                                </div>
                                <div class="col-md-8">
                                    <p><strong>Status:</strong> <span id="manager-status-comment"></span></p>
                                    <p><strong>Comment:</strong> <span id="manager-comment"></span></p>
                                    <p><strong>Date:</strong> <span id="manager-comment-date"></span></p>
                                </div>
                            </div>
                        </div>

                        <!-- Admin Approval -->
                        <div class="approval-section mb-3">
                            <h6>Admin Review</h6>
                            <div class="row">
                                <div class="col-md-4">
                                    <p><strong>Name:</strong> <span id="modal-admin-name"></span></p>
                                    <p><strong>Role:</strong> <span id="modal-admin-role"></span></p>
                                </div>
                                <div class="col-md-8">
                                    <p><strong>Status:</strong> <span id="admin-status-comment"></span></p>
                                    <p><strong>Comment:</strong> <span id="admin-comment"></span></p>
                                    <p><strong>Date:</strong> <span id="admin-comment-date"></span></p>
                                    <div id="admin-vehicle-info"></div>
                                </div>
                            </div>
                        </div>

                        <!-- HR Manager Approval -->
                        <div class="approval-section">
                            <h6>HR Manager Review</h6>
                            <div class="row">
                                <div class="col-md-4">
                                    <p><strong>Name:</strong> <span id="modal-hr-name"></span></p>
                                    <p><strong>Role:</strong> <span id="modal-hr-role"></span></p>
                                </div>
                                <div class="col-md-8">
                                    <p><strong>Status:</strong> <span id="hr-status-comment"></span></p>
                                    <p><strong>Comment:</strong> <span id="hr-comment"></span></p>
                                    <p><strong>Date:</strong> <span id="hr-comment-date"></span></p>
                                    <div id="hr-additional-info"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
