<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'Master Admin') {
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

// Add this function at the top of your PHP file
function isRequestCompleted($request) {
    return isset($request['approvers']) &&
           isset($request['approvers']['manager']) &&
           isset($request['approvers']['admin']) &&
           isset($request['approvers']['hr_manager']) &&
           $request['approvers']['manager']['status'] === 'Approved' &&
           $request['approvers']['admin']['status'] === 'Approved' &&
           $request['approvers']['hr_manager']['status'] === 'Approved';
}

try {
    $data = [
        'users' => [
            'total' => 0,
            'master_admin' => 0,
            'admins' => 0,
            'managers' => 0,
            'hr_managers' => 0,
            'users' => 0
        ],
        'requests' => [
            'total' => 0,
            'pending' => 0,
            'manager_approved' => 0,
            'admin_approved' => 0,
            'rejected' => 0,
            'by_department' => []
        ],
        'vehicles' => [
            'total' => 0,
            'available' => 0,
            'in_use' => 0,
            'maintenance' => 0
        ],
        'drivers' => [
            'total' => 0,
            'available' => 0,
            'assigned' => 0,
            'unavailable' => 0
        ],
        'approvals' => [
            'total' => 0,
            'by_role' => [
                'manager' => ['pending' => 0, 'approved' => 0, 'rejected' => 0],
                'admin' => ['pending' => 0, 'approved' => 0, 'rejected' => 0],
                'hr' => ['pending' => 0, 'approved' => 0, 'rejected' => 0]
            ]
        ],
        'departments' => [
            'total' => 7, // Fixed number based on enum values
            'requests' => []
        ]
    ];

    // Get user statistics
    $userQuery = "SELECT role, COUNT(*) as count FROM users GROUP BY role";
    $result = mysqli_query($conn, $userQuery);
    while ($row = mysqli_fetch_assoc($result)) {
        switch ($row['role']) {
            case 'Master Admin':
                $data['users']['master_admin'] = $row['count'];
                break;
            case 'Admin':
                $data['users']['admins'] = $row['count'];
                break;
            case 'Manager':
                $data['users']['managers'] = $row['count'];
                break;
            case 'HR Manager':
                $data['users']['hr_managers'] = $row['count'];
                break;
            case 'User':
                $data['users']['users'] = $row['count'];
                break;
        }
        $data['users']['total'] += $row['count'];
    }

    // Update the request statistics query
    $requestQuery = "
        SELECT 
            tr.*,
            JSON_OBJECT(
                'manager', JSON_OBJECT('status', manager.status),
                'admin', JSON_OBJECT('status', admin.status),
                'hr_manager', JSON_OBJECT('status', hr.status)
            ) as approvers
        FROM trip_requests tr
        LEFT JOIN approvals manager ON tr.id = manager.trip_id AND manager.approver_role = 'manager'
        LEFT JOIN approvals admin ON tr.id = admin.trip_id AND admin.approver_role = 'admin'
        LEFT JOIN approvals hr ON tr.id = hr.trip_id AND hr.approver_role = 'hr'
    ";

    $result = mysqli_query($conn, $requestQuery);
    $completedCount = 0;
    $pendingCount = 0;
    $rejectedCount = 0;

    while ($row = mysqli_fetch_assoc($result)) {
        $row['approvers'] = json_decode($row['approvers'], true);
        
        if (isRequestCompleted($row)) {
            $completedCount++;
        } elseif ($row['status'] === 'Rejected') {
            $rejectedCount++;
        } else {
            $pendingCount++;
        }
    }

    $data['requests'] = [
        'total' => mysqli_num_rows($result),
        'completed' => $completedCount,
        'pending' => $pendingCount,
        'rejected' => $rejectedCount
    ];

    // Get vehicle statistics
    $vehicleQuery = "SELECT status, COUNT(*) as count FROM vehicles GROUP BY status";
    $result = mysqli_query($conn, $vehicleQuery);
    while ($row = mysqli_fetch_assoc($result)) {
        $data['vehicles']['total'] += $row['count'];
        switch ($row['status']) {
            case 'Available':
                $data['vehicles']['available'] = $row['count'];
                break;
            case 'In Use':
                $data['vehicles']['in_use'] = $row['count'];
                break;
            case 'Maintenance':
                $data['vehicles']['maintenance'] = $row['count'];
                break;
        }
    }

    // Get driver statistics
    $driverQuery = "SELECT status, COUNT(*) as count FROM drivers GROUP BY status";
    $result = mysqli_query($conn, $driverQuery);
    while ($row = mysqli_fetch_assoc($result)) {
        $data['drivers']['total'] += $row['count'];
        switch ($row['status']) {
            case 'Available':
                $data['drivers']['available'] = $row['count'];
                break;
            case 'Assigned':
                $data['drivers']['assigned'] = $row['count'];
                break;
            case 'Unavailable':
                $data['drivers']['unavailable'] = $row['count'];
                break;
        }
    }

    // Get approval statistics
    $approvalQuery = "SELECT approver_role, status, COUNT(*) as count FROM approvals GROUP BY approver_role, status";
    $result = mysqli_query($conn, $approvalQuery);
    while ($row = mysqli_fetch_assoc($result)) {
        $data['approvals']['total'] += $row['count'];
        $role = $row['approver_role'];
        $status = strtolower($row['status']);
        $data['approvals']['by_role'][$role][$status] = $row['count'];
    }

    // Update the department statistics query
    $departmentQuery = "
        SELECT 
            department,
            COUNT(*) as request_count
        FROM trip_requests 
        GROUP BY department
        ORDER BY department ASC
    ";

    $result = mysqli_query($conn, $departmentQuery);
    $data['departments'] = [
        'total' => 7, // Fixed number based on enum values
        'requests' => []
    ];

    // Initialize all departments with 0 counts
    $allDepartments = ['CRD', 'FAD', 'HRAD', 'PD', 'SD', 'VSD', 'TSURE'];
    foreach ($allDepartments as $dept) {
        $data['departments']['requests'][$dept] = 0;
    }

    // Fill in actual counts
    while ($row = mysqli_fetch_assoc($result)) {
        if (isset($row['department'])) {
            $data['departments']['requests'][$row['department']] = (int)$row['request_count'];
        }
    }

    echo json_encode($data);
} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>