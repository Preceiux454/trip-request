<?php
session_start();

require '../db.php';

// Fetch users from the database
$query = "SELECT * FROM users";
$result = mysqli_query($conn, $query);

if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'Master Admin') {
    header("Location: ../login.php");
    exit();
}

$admin_name = $_SESSION['name'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users | Admin Dashboard</title>
    <!-- AdminLTE and other CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        :root {
            --primary-color: #4e73df;
            --secondary-color: #858796;
        }

        body {
            background-color: #f8f9fc;
            font-family: 'Nunito', sans-serif;
        }

        .content-wrapper {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }

        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }

        .card-header {
            background: white;
            border-bottom: 1px solid #e3e6f0;
            padding: 1.5rem;
        }

        .table {
            margin-bottom: 0;
        }

        .table th {
            background: white;
            color: #5a5c69;
            font-weight: 600;
            border-top: none;
            vertical-align: middle;
        }

        .table td {
            vertical-align: middle;
        }

        .btn-primary {
            background: var(--primary-color);
            border: none;
            border-radius: 7px;
            padding: 8px 16px;
            transition: all 0.3s;
        }

        .btn-primary:hover {
            background: #2e59d9;
            transform: translateY(-1px);
        }

        .badge {
            padding: 0.5em 1em;
            border-radius: 30px;
            font-weight: 600;
        }

        .modal-content {
            border: none;
            border-radius: 15px;
        }

        .modal-header {
            background: var(--primary-color);
            color: white;
            border-radius: 15px 15px 0 0;
        }

        .form-control {
            border-radius: 7px;
            padding: 10px 15px;
        }

        .user-role {
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.85em;
            font-weight: 600;
        }

        .role-admin { background: #e74a3b; color: white; }
        .role-manager { background: #1cc88a; color: white; }
        .role-user { background: #36b9cc; color: white; }
        .role-hr { background: #f6c23e; color: white; }

        /* Updated Sidebar Styling */
        .main-sidebar {
            background: #1a1a1a;
            box-shadow: 4px 0 10px rgba(0, 0, 0, 0.1);
            border-right: 1px solid rgba(255,255,255,0.1);
        }

        .brand-container {
            background: #ffffff;
            padding: 1.5rem;
            text-align: center;
            border-bottom: 1px solid rgba(0,0,0,0.1);
        }

        .brand-link {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none !important;
        }

        .brand-image {
            height: 50px;
            margin-bottom: 0.75rem;
            transition: transform 0.3s ease;
        }

        .brand-image:hover {
            transform: scale(1.05);
        }

        .brand-text {
            color: #1a1a1a;
            font-size: 1.2rem;
            font-weight: 600;
            text-align: center;
        }

        .sidebar .nav-pills .nav-link {
            color: rgba(255,255,255,0.8);
            border-radius: 8px;
            margin: 0.25rem 1rem;
            transition: all 0.3s ease;
            padding: 0.75rem 1rem;
        }

        .sidebar .nav-pills .nav-link:hover {
            color: #ffffff;
            background: rgba(255,255,255,0.1);
            transform: translateX(5px);
        }

        .sidebar .nav-pills .nav-link.active {
            background: #dc3545;
            color: #ffffff;
            box-shadow: 0 2px 4px rgba(220,53,69,0.4);
        }

        .nav-sidebar .nav-link i {
            margin-right: 0.75rem;
            width: 1.25rem;
            text-align: center;
            transition: all 0.3s ease;
        }

        .sidebar .nav-pills .nav-link:hover i {
            transform: translateX(3px);
        }

        .nav-sidebar > .nav-item {
            margin-bottom: 0.25rem;
        }

        .sidebar .mt-auto {
            margin-top: auto !important;
            border-top: 1px solid rgba(255,255,255,0.1);
            padding-top: 1rem;
        }

        .nav-sidebar .nav-link.text-danger {
            color: #dc3545 !important;
        }

        .nav-sidebar .nav-link.text-danger:hover {
            background: rgba(220,53,69,0.1);
        }
        .text-muted {
    font-size: 1rem;
}

.text-muted i {
    color:rgb(255, 72, 0);
}

.float-right h5 {
    margin: 0;
    padding: 10px;
    border-radius: 5px;
    background: rgba(255, 255, 255, 0.05);
}
    </style>
</head>
<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <?php include 'inc/admin_sidebar.php'; ?>
        
        <div class="content-wrapper">
            <div class="content-header">
                <div class="container-fluid">
                <div class="row mb-2">
    <div class="col-sm-6">
        <h1><i class="fas fa-users-cog text-dark mr-2"></i> Manage Users</h1>
    </div>
    <div class="col-sm-6">
        <div class="float-right">
            <h5 class="text-muted">
                <i class="fas fa-user mr-2"></i> 
                Bonjour, <?php echo htmlspecialchars($_SESSION['name']); ?>!
            </h5>
        </div>
    </div>
</div>
                    
                </div>
            </div>

            <section class="content">
                <div class="container-fluid">
                    <div class="card">
                        <div class="card-header">
                            <div class="d-flex justify-content-between align-items-center">
                                <h3 class="card-title">USER LIST</h3>
                                <button class="btn btn-primary" data-toggle="modal" data-target="#addUserModal">
                                    <i class="fas fa-user-plus mr-2"></i>Add New User
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Role</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while ($row = mysqli_fetch_assoc($result)) { 
                                            $roleClass = 'role-' . strtolower(str_replace(' ', '-', $row['role']));
                                        ?>
                                            <tr>
                                                <td><?= $row['id'] ?></td>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <img src="https://ui-avatars.com/api/?name=<?= urlencode($row['name']) ?>&background=random" 
                                                             class="rounded-circle mr-2" style="width: 32px; height: 32px;">
                                                        <?= htmlspecialchars($row['name']) ?>
                                                    </div>
                                                </td>
                                                <td><?= htmlspecialchars($row['email']) ?></td>
                                                <td><span class="user-role <?= $roleClass ?>"><?= htmlspecialchars($row['role']) ?></span></td>
                                                <td>
                                                    <button class="btn btn-sm btn-info mr-1" title="Edit">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                    <button class="btn btn-sm btn-danger" title="Delete">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <!-- Add User Modal -->
    <div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="addUserLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New User</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="add_users.php" method="POST">
                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" name="name" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Role</label>
                            <select name="role" class="form-control" required>
                                <option value="User">User</option>
                                <option value="Master Admin">Master Admin</option>
                                <option value="Admin">Admin</option>
                                <option value="Manager">Manager</option>
                                <option value="HR Manager">HR Manager</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Add User</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php include 'inc/footer.php'; ?>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/js/adminlte.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <script>
        $(document).ready(function () {
            const urlParams = new URLSearchParams(window.location.search);
            
            if (urlParams.has('success')) {
                Swal.fire({
                    icon: 'success',
                    title: 'User Added Successfully!',
                    showConfirmButton: false,
                    timer: 2000
                });
            }
            
            if (urlParams.has('error')) {
                Swal.fire({
                    icon: 'error',
                    title: 'Failed to Add User!',
                    text: 'Please try again.',
                    showConfirmButton: true
                });
            }
        });
    </script>
</body>
</html>