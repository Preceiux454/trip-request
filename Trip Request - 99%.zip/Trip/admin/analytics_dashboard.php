<?php
session_start();
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'Master Admin') {
    header('Location: ../login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .small-box {
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        
        .small-box:hover {
            transform: translateY(-5px);
        }

        .chart-container {
            background: #fff;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            height: 350px;
            position: relative;
        }

        .chart-wrapper {
            height: 300px;
            position: relative;
        }

        .chart-title {
            font-size: 1rem;
            font-weight: 600;
            color: #4e73df;
            margin-bottom: 1rem;
            text-align: center;
        }
        
        /* Updated Sidebar Styling */
        .main-sidebar {
            background: #1a1a1a;
            box-shadow: 4px 0 10px rgba(0, 0, 0, 0.1);
            border-right: 1px solid rgba(255,255,255,0.1);
        }

        .brand-container {
            background: #ffffff;
            padding: 1.5rem;
            text-align: center;
            border-bottom: 1px solid rgba(0,0,0,0.1);
        }

        .brand-link {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none !important;
        }

        .brand-image {
            height: 50px;
            margin-bottom: 0.75rem;
            transition: transform 0.3s ease;
        }

        .brand-image:hover {
            transform: scale(1.05);
        }

        .brand-text {
            color: #1a1a1a;
            font-size: 1.2rem;
            font-weight: 600;
            text-align: center;
        }

        .sidebar .nav-pills .nav-link {
            color: rgba(255,255,255,0.8);
            border-radius: 8px;
            margin: 0.25rem 1rem;
            transition: all 0.3s ease;
            padding: 0.75rem 1rem;
        }

        .sidebar .nav-pills .nav-link:hover {
            color: #ffffff;
            background: rgba(255,255,255,0.1);
            transform: translateX(5px);
        }

        .sidebar .nav-pills .nav-link.active {
            background: #dc3545;
            color: #ffffff;
            box-shadow: 0 2px 4px rgba(220,53,69,0.4);
        }

        .nav-sidebar .nav-link i {
            margin-right: 0.75rem;
            width: 1.25rem;
            text-align: center;
            transition: all 0.3s ease;
        }

        .sidebar .nav-pills .nav-link:hover i {
            transform: translateX(3px);
        }

        .nav-sidebar > .nav-item {
            margin-bottom: 0.25rem;
        }

        .sidebar .mt-auto {
            margin-top: auto !important;
            border-top: 1px solid rgba(255,255,255,0.1);
            padding-top: 1rem;
        }

        .nav-sidebar .nav-link.text-danger {
            color: #dc3545 !important;
        }

        .nav-sidebar .nav-link.text-danger:hover {
            background: rgba(220,53,69,0.1);
        }
        .text-muted {
    font-size: 1rem;
}

.text-muted i {
    color:rgb(255, 8, 0);
}

.float-right h5 {
    margin: 0;
    padding: 10px;
    border-radius: 5px;
    background: rgba(255, 255, 255, 0.05);
}
    </style>
</head>
<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <?php include 'inc/admin_sidebar.php'; ?>
        
        <div class="content-wrapper">
            <section class="content-header">
                <div class="container-fluid">
                <div class="row mb-2">
    <div class="col-sm-6">
        <h1><i class="fas fa-chart-line text-dark mr-2"></i> Analytics Dashboard</h1>
    </div>
    <div class="col-sm-6">
        <div class="float-right">
            <h5 class="text-muted">
                <i class="fas fa-user mr-2"></i> 
                Bonjour, <?php echo htmlspecialchars($_SESSION['name']); ?>!
            </h5>
        </div>
    </div>
</div>
                </div>
            </section>

            <section class="content">
                <div class="container-fluid">
                    <!-- User Statistics -->
                    <div class="row">
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-info">
                                <div class="inner">
                                    <h3 id="totalUsers">0</h3>
                                    <p>Total Users</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-users"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-success">
                                <div class="inner">
                                    <h3 id="totalAdmins">0</h3>
                                    <p>Total Admins</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-user-shield"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-warning">
                                <div class="inner">
                                    <h3 id="totalManagers">0</h3>
                                    <p>Total Managers</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-user-tie"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-danger">
                                <div class="inner">
                                    <h3 id="totalHRManagers">0</h3>
                                    <p>Total HR Managers</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-user-cog"></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Request Statistics -->
                    <div class="row">
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-primary">
                                <div class="inner">
                                    <h3 id="totalRequests">0</h3>
                                    <p>Total Requests</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-clipboard-list"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-success">
                                <div class="inner">
                                    <h3 id="totalCompleted">0</h3>
                                    <p>Completed Requests</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-warning">
                                <div class="inner">
                                    <h3 id="totalPending">0</h3>
                                    <p>Pending Requests</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-clock"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-danger">
                                <div class="inner">
                                    <h3 id="totalRejected">0</h3>
                                    <p>Rejected Requests</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-times-circle"></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Vehicle and Driver Statistics -->
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="small-box bg-purple">
                                <div class="inner">
                                    <h3 id="totalVehicles">0</h3>
                                    <p>Total Vehicles</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-car"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="small-box bg-indigo">
                                <div class="inner">
                                    <h3 id="totalDrivers">0</h3>
                                    <p>Total Drivers</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-id-card"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="small-box bg-teal">
                                <div class="inner">
                                    <h3 id="totalDepartments">0</h3>
                                    <p>Total Departments</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-building"></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Charts Section -->
                    <div class="row">
                        <div class="col-md-6">
                            <div class="chart-container">
                                <div class="chart-title">Request Status Distribution</div>
                                <div class="chart-wrapper">
                                    <canvas id="requestStatusChart"></canvas>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="chart-container">
                                <div class="chart-title">Requests by Department</div>
                                <div class="chart-wrapper">
                                    <canvas id="departmentRequestsChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/js/adminlte.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <script>
        $(document).ready(function() {
            loadAnalytics();
        });

        function loadAnalytics() {
            $.ajax({
                url: '../fetch_analytics.php',
                method: 'GET',
                dataType: 'json',
                success: function(response) {
                    console.log('Analytics Data:', response); // Debug log
                    if (response.departments && response.departments.requests) {
                        console.log('Department Data:', response.departments.requests);
                    }
                    updateDashboardStats(response);
                    initializeCharts(response);
                },
                error: function(xhr, status, error) {
                    console.error('Analytics loading error:', error);
                    console.error('Response:', xhr.responseText);
                }
            });
        }

        function updateDashboardStats(data) {
            // Update user statistics
            $('#totalUsers').text(data.users.total);
            $('#totalAdmins').text(data.users.admins);
            $('#totalManagers').text(data.users.managers);
            $('#totalHRManagers').text(data.users.hr_managers);
            
            // Update request statistics
            $('#totalRequests').text(data.requests.total);
            $('#totalCompleted').text(data.requests.completed); // Changed from admin_approved
            $('#totalPending').text(data.requests.pending);
            $('#totalRejected').text(data.requests.rejected);
            
            // Update vehicle and driver statistics
            $('#totalVehicles').text(data.vehicles.total);
            $('#totalAvailableVehicles').text(data.vehicles.available);
            $('#totalDrivers').text(data.drivers.total);
            $('#totalAvailableDrivers').text(data.drivers.available);
            $('#totalDepartments').text(data.departments.total);
        }

        function initializeCharts(data) {
            // Request Status Chart
            new Chart(document.getElementById('requestStatusChart'), {
                type: 'doughnut',
                data: {
                    labels: ['Completed', 'Pending', 'Rejected'],
                    datasets: [{
                        data: [
                            data.requests.completed,
                            data.requests.pending,
                            data.requests.rejected
                        ],
                        backgroundColor: ['#28a745', '#ffc107', '#dc3545']
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'right',
                            labels: {
                                boxWidth: 12,
                                padding: 15
                            }
                        }
                    }
                }
            });

            // Department Requests Chart
            new Chart(document.getElementById('departmentRequestsChart'), {
                type: 'bar',
                data: {
                    labels: Object.keys(data.departments.requests),
                    datasets: [{
                        label: 'Requests by Department',
                        data: Object.values(data.departments.requests),
                        backgroundColor: '#4e73df',
                        borderRadius: 5
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                stepSize: 1,
                                font: {
                                    size: 11
                                }
                            },
                            grid: {
                                drawBorder: false
                            }
                        },
                        x: {
                            ticks: {
                                font: {
                                    size: 11
                                },
                                maxRotation: 45,
                                minRotation: 45
                            },
                            grid: {
                                display: false
                            }
                        }
                    }
                }
            });
        }
    </script>
</body>
</html>