<?php
include '../db.php';

$query = "SELECT * FROM users ORDER BY id DESC";
$result = mysqli_query($conn, $query);

while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>
            <td>{$row['id']}</td>
            <td><i class='fas fa-user'></i> {$row['name']}</td>
            <td><i class='fas fa-envelope'></i> {$row['email']}</td>
            <td><span class='badge badge-info'>{$row['role']}</span></td>
            <td>
                <button class='btn btn-danger btn-sm deleteUser' data-id='{$row['id']}'>
                    <i class='fas fa-trash'></i> Delete
                </button>
            </td>
        </tr>";
}
?>
