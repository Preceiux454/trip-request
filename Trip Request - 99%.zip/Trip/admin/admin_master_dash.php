<?php
session_start();

// Add session check at the top of the file
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'Master Admin') {
    header('Location: ../login.php');
    exit;
}

// Add session debug if needed
if (isset($_GET['debug'])) {
    error_log('Session data: ' . print_r($_SESSION, true));
} ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Master Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/css/adminlte.min.css"> <!-- AdminLTE CSS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../js/dashboard-common.js"></script>
    <script src="../js/modal-handler.js"></script>
    <style>

        
        body {
            background-color: #f4f6f9;
        }
        .brand-link {
            font-size: 20px;
            font-weight: bold;
            text-align: center;
        }
        .content-wrapper {
            padding: 20px;
        }
        .table th {
            background-color: #222;
            color: white;
            text-align: center;
        }
        .table td {
            text-align: center;
            vertical-align: middle;
        }
        .btn {
            border-radius: 20px;
            font-weight: bold;
        }
        .approval-item {
            margin-bottom: 10px;
        }
        .approval-item strong {
            display: inline-block;
            min-width: 150px;
        }
        .comment-block {
            background-color: #f8f9fa;
            border-radius: 5px;
            padding: 10px;
        }
        .comment-block .card {
            border: 1px solid rgba(0,0,0,.125);
        }
        .comment-block h6 {
            margin-bottom: 10px;
        }
        .comment-block .card-body {
            padding: 15px;
        }
        .text-success {
            color: #28a745 !important;
        }
        .text-danger {
            color: #dc3545 !important;
        }
        .text-warning {
            color: #ffc107 !important;
        }
        .badge {
            font-size: 0.75rem;
            padding: 0.25rem 0.5rem;
            margin-bottom: 0.25rem;
        }
        td small {
            color: #6c757d;
            display: block;
            font-size: 0.75rem;
        }
        .badge-success {
            background-color: #28a745;
        }
        .badge-danger {
            background-color: #dc3545;
        }
        .badge-warning {
            background-color: #ffc107;
            color: #212529;
        }
        .badge-secondary {
            background-color: #6c757d;
        }
        .modal-body p {
    margin-bottom: 0.5rem;
}
.bg-primary {
    background-color: #222 !important;
}

.modal-body strong {
    display: inline-block;
    min-width: 120px;
}

.comment-block {
    margin-bottom: 1.5rem;
}

.comment-block:last-child {
    margin-bottom: 0;
}

.comment-block .card {
    box-shadow: none;
    margin-top: 0.5rem;
}

.comment-block .badge {
    font-size: 0.875rem;
    padding: 0.4em 0.8em;
}

.text-muted {
    font-size: 0.875rem;
}
   /* Modern styling for filters and pagination */
   .form-control:focus {
        border-color: #222;
        box-shadow: 0 0 0 0.2rem rgba(34, 34, 34, 0.25);
    }
    
    .btn-primary {
        background-color: #222;
        border-color: #222;
        transition: all 0.3s;
    }
    
    .btn-primary:hover, .btn-primary:focus {
        background-color: #444;
        border-color: #444;
        box-shadow: 0 0 0 0.2rem rgba(34, 34, 34, 0.25);
    }
    
    .btn-outline-secondary {
        color: #222;
        border-color: #222;
        transition: all 0.3s;
    }
    
    .btn-outline-secondary:hover {
        background-color: #222;
        border-color: #222;
    }
    
    .pagination .page-link {
        color: #222;
        transition: all 0.3s;
    }
    
    .pagination .page-item.active .page-link {
        background-color: #222;
        border-color: #222;
    }
    
    .pagination .page-link:focus {
        box-shadow: 0 0 0 0.2rem rgba(34, 34, 34, 0.25);
    }
    
    /* Card and table enhancements */
    .card {
        box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
        border-radius: 0.5rem;
        overflow: hidden;
        transition: all 0.3s;
    }
    
    .card:hover {
        box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
    }
    
    .table {
        margin-bottom: 0;
    }
    
    .table th {
        border-top: none;
    }
    
    /* Filter section styling */
    .card-body.border-bottom {
        background-color: #f8f9fa;
        padding: 1.25rem;
        border-bottom: 1px solid rgba(0,0,0,.125);
    }
    
    /* Animation for table rows */
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    #tripRequestsTable tr {
        animation: fadeIn 0.3s ease-in-out;
    }
    
    /* Responsive adjustments */
    @media (max-width: 768px) {
        .dataTables_info, .dataTables_paginate {
            text-align: center;
        }
        
        .pagination {
            justify-content: center !important;
            margin-top: 1rem;
        }
    }
     /* Modern Modal Styling */
     .modal-content {
        border-radius: 0.5rem;
        overflow: hidden;
    }
    
    .modal-header {
        padding: 1rem 1.5rem;
    }
    
    .modal-footer {
        padding: 1rem 1.5rem;
    }
    
    .card-header {
        padding: 0.75rem 1.25rem;
        border-bottom: 1px solid rgba(0,0,0,.05);
    }
    
    .info-group label {
        margin-bottom: 0.25rem;
        font-weight: 600;
        color: #6c757d;
    }
    
    .info-group p {
        color: #212529;
    }
    
    /* Vehicle and Driver Info Cards */
    .alert {
        border: none;
        border-radius: 0.5rem;
        box-shadow: 0 2px 4px rgba(0,0,0,.05);
    }
    
    .alert-info {
        background-color: #e8f4f8;
        color: #0c5460;
    }
    
    .alert-secondary {
        background-color: #f2f2f2;
        color: #383d41;
    }
    
    .alert-warning {
        background-color: #fff3cd;
        color: #856404;
    }
    
    .alert-light {
        background-color: #f8f9fa;
        color: #818182;
    }
    
    .alert h6 {
        font-weight: 600;
        margin-bottom: 0.75rem;
    }
    
    .alert p {
        margin-bottom: 0.5rem;
    }
    
    .alert p:last-child {
        margin-bottom: 0;
    }
    
    /* Badge styling */
    .badge {
        padding: 0.4em 0.8em;
        font-weight: 500;
        border-radius: 30px;
    }

        /* Updated Sidebar Styling */
        .main-sidebar {
            background: #1a1a1a;
            box-shadow: 4px 0 10px rgba(0, 0, 0, 0.1);
            border-right: 1px solid rgba(255,255,255,0.1);
        }

        .brand-container {
            background: #ffffff;
            padding: 1.5rem;
            text-align: center;
            border-bottom: 1px solid rgba(0,0,0,0.1);
        }

        .brand-link {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none !important;
        }

        .brand-image {
            height: 50px;
            margin-bottom: 0.75rem;
            transition: transform 0.3s ease;
        }

        .brand-image:hover {
            transform: scale(1.05);
        }

        .brand-text {
            color: #1a1a1a;
            font-size: 1.2rem;
            font-weight: 600;
            text-align: center;
        }

        .sidebar .nav-pills .nav-link {
            color: rgba(255,255,255,0.8);
            border-radius: 8px;
            margin: 0.25rem 1rem;
            transition: all 0.3s ease;
            padding: 0.75rem 1rem;
        }

        .sidebar .nav-pills .nav-link:hover {
            color: #ffffff;
            background: rgba(255,255,255,0.1);
            transform: translateX(5px);
        }

        .sidebar .nav-pills .nav-link.active {
            background: #dc3545;
            color: #ffffff;
            box-shadow: 0 2px 4px rgba(220,53,69,0.4);
        }

        .nav-sidebar .nav-link i {
            margin-right: 0.75rem;
            width: 1.25rem;
            text-align: center;
            transition: all 0.3s ease;
        }

        .sidebar .nav-pills .nav-link:hover i {
            transform: translateX(3px);
        }

        .nav-sidebar > .nav-item {
            margin-bottom: 0.25rem;
        }

        .sidebar .mt-auto {
            margin-top: auto !important;
            border-top: 1px solid rgba(255,255,255,0.1);
            padding-top: 1rem;
        }

        .nav-sidebar .nav-link.text-danger {
            color: #dc3545 !important;
        }

        .nav-sidebar .nav-link.text-danger:hover {
            background: rgba(220,53,69,0.1);
        }
        .text-muted {
    font-size: 1rem;
}

.text-muted i {
    color:rgb(255, 0, 0);
}

.float-right h5 {
    margin: 0;
    padding: 10px;
    border-radius: 5px;
    background: rgba(252, 252, 252, 0.05);
}
    </style></qodoArtifact>
</head>
<body>
    <div class="wrapper">
       <?php include 'inc/admin_sidebar.php'; ?>
        <!-- Content Wrapper -->
        <div class="content-wrapper">
            <section class="content-header">
                <div class="container-fluid">
                <div class="row mb-2">
    <div class="col-sm-6">
        <h1><i class="fas fa-clipboard-list text-dark mr-2"></i> Trip Requests</h1>
    </div>
    <div class="col-sm-6">
        <div class="float-right">
            <h5 class="text-muted">
                <i class="fas fa-user mr-2"></i> 
                Bonjour, <?php echo htmlspecialchars($_SESSION['name']); ?>!
            </h5>
        </div>
    </div>
</div>
                </div>
            </section>

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <div class="card shadow">
                        <div class="card-header bg-primary text-white">
                            <h3 class="card-title"><i class="fas fa-list"></i> All Trip Requests</h3>
                        </div>
                        <div class="card-body border-bottom">
                            <div class="row">
                                <div class="col-md-3 mb-2">
                                    <div class="input-group">
                                        <input type="text" id="searchInput" class="form-control" placeholder="Search...">
                                        <div class="input-group-append">
                                            <button id="searchButton" class="btn btn-primary"><i class="fas fa-search"></i></button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2 mb-2">
                                    <select id="statusFilter" class="form-control">
                                        <option value="">All Statuses</option>
                                        <option value="Pending">Pending</option>
                                        <option value="Approved">Approved</option>
                                        <option value="Rejected">Rejected</option>
                                        <option value="REQUEST COMPLETED">Completed</option>
                                    </select>
                                </div>
                                <div class="col-md-2 mb-2">
                                    <select id="departmentFilter" class="form-control">
                                        <option value="">All Departments</option>
                                        <option value="CRD">Customer Relations Department</option>
                                        <option value="FAD">Finance and Accounting Department</option>
                                        <option value="HRAD">Human Resources and Admin Department</option>
                                        <option value="PD">Parts Department</option>
                                        <option value="SD">Service Department</option>
                                        <option value="VSD">Vehicle Sales Department</option>
                                        <option value="TSURE">TSURE</option>
                                    </select>
                                </div>
                                <div class="col-md-3 mb-2">
                                    <input type="date" id="dateFilter" class="form-control">
                                </div>
                                <div class="col-md-2 mb-2">
                                    <button id="resetFilters" class="btn btn-outline-secondary btn-block">
                                        <i class="fas fa-undo"></i> Reset
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                    <th>ID</th>
                                        <th>Requestor</th>
                                        <th>Department</th>
                                        <th>Date Needed</th>
                                        <th>Manager</th>
                                        <th>Admin</th>
                                        <th>HR Manager</th>
                                        <th>Overall Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="tripRequestsTable">
                                    <!-- Data will be loaded via AJAX -->
                                </tbody>
                            </table>
                            <div class="row mt-3">
                                <div class="col-md-6">
                                    <p class="text-muted">Showing <span id="showingStart">0</span> to <span id="showingEnd">0</span> of <span id="totalRecords">0</span> entries</p>
                                </div>
                                <div class="col-md-6">
                                    <nav aria-label="Page navigation" class="float-right">
                                        <ul class="pagination">
                                            <li class="page-item disabled" id="prevPage">
                                                <a class="page-link" href="#" aria-label="Previous">
                                                    <span aria-hidden="true">&laquo;</span>
                                                </a>
                                            </li>
                                            <li class="page-item active" id="pageNumber">
                                                <a class="page-link" href="#">1</a>
                                            </li>
                                            <li class="page-item" id="nextPage">
                                                <a class="page-link" href="#" aria-label="Next">
                                                    <span aria-hidden="true">&raquo;</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <div id="loadingIndicator" style="display:none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);">
    
</div> <!-- End of main wrapper -->


<!-- Trip Details Modal -->
<div class="modal fade" id="tripDetailsModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="fas fa-clipboard-check mr-2"></i>Trip Request Details</h5>
                <button type="button" class="close text-white" data-dismiss="modal">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body px-4 py-4">
                <!-- Request Information Card -->
                <div class="card shadow-sm mb-4 border-0">
                    <div class="card-header bg-light">
                        <h6 class="mb-0"><i class="fas fa-info-circle mr-2"></i>Request Information</h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="info-group mb-3">
                                    <label class="text-muted small text-uppercase">Requestor</label>
                                    <p class="font-weight-bold mb-1" id="modal-requestor"></p>
                                </div>
                                <div class="info-group mb-3">
                                    <label class="text-muted small text-uppercase">Email</label>
                                    <p class="font-weight-bold mb-1" id="modal-requestor_email"></p>
                                </div>
                                <div class="info-group mb-3">
                                    <label class="text-muted small text-uppercase">Department</label>
                                    <p class="font-weight-bold mb-1" id="modal-department"></p>
                                </div>
                                <div class="info-group mb-3">
                                    <label class="text-muted small text-uppercase">Date Needed</label>
                                    <p class="font-weight-bold mb-1" id="modal-date"></p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="info-group mb-3">
                                    <label class="text-muted small text-uppercase">Time Needed</label>
                                    <p class="font-weight-bold mb-1" id="modal-time"></p>
                                </div>
                                <div class="info-group mb-3">
                                    <label class="text-muted small text-uppercase">Return Time</label>
                                    <p class="font-weight-bold mb-1" id="modal-time-return"></p>
                                </div>
                                <div class="info-group mb-3">
                                    <label class="text-muted small text-uppercase">Company Vehicle</label>
                                    <p class="font-weight-bold mb-1" id="modal-company-vehicle"></p>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="info-group mb-3">
                                    <label class="text-muted small text-uppercase">Route From</label>
                                    <p class="font-weight-bold mb-1" id="modal-route-from"></p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="info-group mb-3">
                                    <label class="text-muted small text-uppercase">Route To</label>
                                    <p class="font-weight-bold mb-1" id="modal-route-to"></p>
                                </div>
                            </div>
                        </div>
                        <div class="info-group">
                            <label class="text-muted small text-uppercase">Passengers</label>
                            <p class="font-weight-bold mb-0" id="modal-passengers"></p>
                        </div>
                    </div>
                </div>

                <!-- Purpose Card -->
                <div class="card shadow-sm mb-4 border-0">
                    <div class="card-header bg-light">
                        <h6 class="mb-0"><i class="fas fa-bullseye mr-2"></i>Purpose</h6>
                    </div>
                    <div class="card-body">
                        <p id="modal-purpose" class="mb-0"></p>
                    </div>
                </div>

                <!-- Approval Status Card -->
                <div class="card shadow-sm mb-4 border-0">
                    <div class="card-header bg-light">
                        <h6 class="mb-0"><i class="fas fa-check-circle mr-2"></i>Approval Status</h6>
                    </div>
                    <div class="card-body p-0">
                        <!-- Manager Section -->
                        <div class="p-3 border-bottom">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <h6 class="text-primary mb-0">
                                    <i class="fas fa-user-tie mr-2"></i>Manager
                                </h6>
                                <span id="manager-status-comment" class="badge"></span>
                            </div>
                            <div class="ml-4">
                                <p class="mb-1"><span class="text-muted">Name:</span> <span id="modal-manager-name"></span></p>
                                <p class="mb-1"><span class="text-muted">Role:</span> <span id="modal-manager-role"></span></p>
                                <p class="mb-1"><span class="text-muted">Comment:</span> <span id="manager-comment"></span></p>
                                <p class="mb-0 small text-muted">Approval Date: <span id="manager-comment-date"></span></p>
                            </div>
                        </div>

                        <!-- Admin Section -->
                        <div class="p-3 border-bottom">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <h6 class="text-primary mb-0">
                                    <i class="fas fa-user-cog mr-2"></i>Admin
                                </h6>
                                <span id="admin-status-comment" class="badge"></span>
                            </div>
                            <div class="ml-4">
                                <p class="mb-1"><span class="text-muted">Name:</span> <span id="modal-admin-name"></span></p>
                                <p class="mb-1"><span class="text-muted">Role:</span> <span id="modal-admin-role"></span></p>
                                
                                <!-- Vehicle and Driver Information Section -->
                                <div class="transport-info my-3">
                                    <div id="admin-vehicle-info" class="mb-2"></div>
                                    <div id="admin-driver-info" class="mb-2"></div>
                                </div>
                                
                                <p class="mb-1"><span class="text-muted">Comment:</span> <span id="admin-comment"></span></p>
                                <p class="mb-0 small text-muted">Approval Date: <span id="admin-comment-date"></span></p>
                            </div>
                        </div>

                        <!-- HR Section -->
                        <div class="p-3">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <h6 class="text-primary mb-0">
                                    <i class="fas fa-user-shield mr-2"></i>HR Manager
                                </h6>
                                <span id="hr-status-comment" class="badge"></span>
                            </div>
                            <div class="ml-4">
                                <p class="mb-1"><span class="text-muted">Name:</span> <span id="modal-hr-name"></span></p>
                                <p class="mb-1"><span class="text-muted">Role:</span> <span id="modal-hr-role"></span></p>
                                <p class="mb-1"><span class="text-muted">Comment:</span> <span id="hr-comment"></span></p>
                                <p class="mb-0 small text-muted">Approval Date: <span id="hr-comment-date"></span></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer bg-light">
                <button type="button" class="btn btn-secondary rounded-pill px-4" data-dismiss="modal">
                    <i class="fas fa-times mr-2"></i>Close
                </button>
            </div>
        </div>
    </div>
</div>


<!-- Loading Indicator -->
<div id="loadingIndicator" style="display:none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);">
    <div class="spinner-border text-primary" role="status">
        <span class="sr-only">Loading...</span>
    </div>
</div>

<!-- Scripts in correct order -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/js/adminlte.min.js"></script>
<script src="../js/dashboard-common.js"></script>
<script src="../js/modal-handler.js"></script>

<script>
// Define loadTripRequests first
function loadTripRequests() {
    $.ajax({
        url: '../fetch_admin_trips.php',
        method: 'GET',
        dataType: 'json',
        success: function(response) {
            if (response.error) {
                console.error('Server Error:', response.error);
                if (response.error === 'Unauthorized access') {
                    window.location.href = '../login.php';
                    return;
                }
                Swal.fire('Error', response.error, 'error');
                return;
            }
            
            let tableRows = '';
            if (response.length === 0) {
                tableRows = '<tr><td colspan="9" class="text-center">No trip requests found</td></tr>';
            } else {
                response.forEach(request => {
                    tableRows += generateTableRow(request);
                });
            }
            
            $('#tripRequestsTable').fadeOut(200, function() {
                $(this).html(tableRows).fadeIn(200);
            });
        },
        error: function(xhr, status, error) {
            console.error('AJAX Error:', error);
            if (xhr.status === 403) {
                window.location.href = '../login.php';
            } else {
                Swal.fire('Error', 'Failed to load trip requests', 'error');
            }
        }
    });
}

// Document ready handler after function definitions
$(document).ready(function() {
    // Initialize modal handler
    if (typeof ModalHandler !== 'undefined') {
        ModalHandler.init();
    } else {
        console.error('ModalHandler not loaded');
    }
    
    // Setup dashboard with error handling
    try {
        DashboardManager.setupDashboard({ 
            loadFunction: loadTripRequests 
        });
    } catch (e) {
        console.error('Dashboard setup error:', e);
    }
    
    // Add direct click handler for view buttons
    $(document).on('click', '.view-trip-details', function(e) {
        e.preventDefault();
        const tripId = $(this).data('id');
        viewTripDetails(tripId);
    });
});


// Function to update modal content
function updateModalContent(tripData) {
    console.log('Updating modal with data:', tripData);
    
  // Format time function to display in 24-hour format
  function formatTime(timeString) {
        if (!timeString) return 'N/A';
        
        try {
            // Parse the time string
            const [hours, minutes] = timeString.split(':').map(num => parseInt(num, 10));
            
            if (isNaN(hours) || isNaN(minutes)) {
                return 'Invalid Time';
            }
            
            // Format in 24-hour format: "13:30" or "09:05"
            const displayHours = hours.toString().padStart(2, '0');
            const displayMinutes = minutes.toString().padStart(2, '0');
            
            return `${displayHours}:${displayMinutes}`;
        } catch (error) {
            console.error('Time formatting error:', error);
            return 'Invalid Time Format';
        }
    }
    
    // Basic trip information
    $('#modal-requestor').text(tripData.requestor_name || 'N/A');
    $('#modal-requestor_email').text(tripData.requestor_email || 'N/A');
    $('#modal-department').text(tripData.department || 'N/A');
    $('#modal-date').text(tripData.date_needed || 'N/A');
    $('#modal-time').text(formatTime(tripData.time_needed) || 'N/A');
    $('#modal-time-return').text(formatTime(tripData.time_return) || 'N/A');
    $('#modal-company-vehicle').text(tripData.company_vehicle || 'N/A');
    $('#modal-route-from').text(tripData.route_from || 'N/A');
    $('#modal-route-to').text(tripData.route_to || 'N/A');
    $('#modal-passengers').text(tripData.passengers || 'N/A');
    $('#modal-purpose').text(tripData.purpose || 'N/A');

    // Manager approval information
    const manager = tripData.approvers.manager;
    $('#modal-manager-name').text(manager.name || 'Not Assigned');
    $('#modal-manager-role').text(manager.role || 'N/A');
    
    if (manager.status) {
        const managerStatusBadge = `<span class="badge ${DashboardManager.getStatusBadgeClass(manager.status)}">${manager.status}</span>`;
        $('#manager-status-comment').html(managerStatusBadge);
    } else {
        $('#manager-status-comment').text('Pending');
    }
    
    $('#manager-comment').text(manager.comment || 'No comment');
    $('#manager-comment-date').text(manager.date || 'N/A');

    // Admin approval information
    const admin = tripData.approvers.admin;
    $('#modal-admin-name').text(admin.name || 'Not Assigned');
    $('#modal-admin-role').text(admin.role || 'N/A');
    
    if (admin.status) {
        const adminStatusBadge = `<span class="badge ${DashboardManager.getStatusBadgeClass(admin.status)}">${admin.status}</span>`;
        $('#admin-status-comment').html(adminStatusBadge);
    } else {
        $('#admin-status-comment').text('Pending');
    }
    
    $('#admin-comment').text(admin.comment || 'No comment');
    $('#admin-comment-date').text(admin.date || 'N/A');

    // Vehicle and Driver information (if assigned by admin)
    if (tripData.company_vehicle === 'Yes') {
        let vehicleInfo = '';
        let driverInfo = '';
        
        // Add vehicle information if available
        if (admin.vehicle && admin.vehicle.name) {
            vehicleInfo = `
                <div class="alert alert-info mb-2">
                    <h6 class="mb-2"><i class="fas fa-car"></i> Vehicle Information</h6>
                    <p class="mb-1"><strong>Vehicle:</strong> ${admin.vehicle.name}</p>
                    <p class="mb-1"><strong>Plate Number:</strong> ${admin.vehicle.plate_number || 'Not provided'}</p>
                    <p class="mb-0"><strong>Status:</strong> 
                        <span class="badge ${DashboardManager.getStatusBadgeClass(admin.vehicle.status)}">${admin.vehicle.status || 'Pending'}</span>
                    </p>
                </div>
            `;
        }
        
        // Add driver information if available
        if (admin.driver && admin.driver.name) {
            driverInfo = `
                <div class="alert alert-secondary mb-2">
                    <h6 class="mb-2"><i class="fas fa-user"></i> Driver Information</h6>
                    <p class="mb-1"><strong>Name:</strong> ${admin.driver.name}</p>
                    <p class="mb-1"><strong>Contact:</strong> ${admin.driver.contact || 'Not provided'}</p>
                    <p class="mb-1"><strong>License:</strong> ${admin.driver.license || 'Not provided'}</p>
                    <p class="mb-0"><strong>Status:</strong> 
                        <span class="badge ${DashboardManager.getStatusBadgeClass(admin.driver.status)}">${admin.driver.status || 'Available'}</span>
                    </p>
                </div>
            `;
        }
        
        // Display vehicle and driver information separately
        $('#admin-vehicle-info').html(vehicleInfo);
        $('#admin-driver-info').html(driverInfo);
    } else {
        // If company vehicle is not requested, show a message
        $('#admin-vehicle-info').html('<div class="alert alert-light">No company vehicle requested</div>');
        $('#admin-driver-info').empty();
    }

    // HR Manager approval information
    const hr = tripData.approvers.hr_manager;
    $('#modal-hr-name').text(hr.name || 'Not Assigned');
    $('#modal-hr-role').text(hr.role || 'N/A');
    
    if (hr.status) {
        const hrStatusBadge = `<span class="badge ${DashboardManager.getStatusBadgeClass(hr.status)}">${hr.status}</span>`;
        $('#hr-status-comment').html(hrStatusBadge);
    } else {
        $('#hr-status-comment').text('Pending');
    }
    
    $('#hr-comment').text(hr.comment || 'No comment');
    $('#hr-comment-date').text(hr.date || 'N/A');
}

// Function to generate table rows
function generateTableRow(request) {
    // Check if all approvers have approved the request
    const allApproved = 
        request.approvers.manager.status === 'Approved' && 
        request.approvers.admin.status === 'Approved' && 
        request.approvers.hr_manager.status === 'Approved';
    
    // Set the overall status text and badge class
    let overallStatus = request.status.toUpperCase();
    let badgeClass = DashboardManager.getStatusBadgeClass(request.status);
    
    // If all approvers have approved, show "Request Completed"
    if (allApproved) {
        overallStatus = "REQUEST COMPLETED";
        badgeClass = "badge-success";
    }
    
    // Format the date if needed
    const dateNeeded = request.date_needed || 'N/A';
    
    // Create the view button with multiple classes and onclick handler
    const viewButton = `
        <button type="button" 
                class="btn btn-primary btn-sm view-trip-details view-trip-btn" 
                data-id="${request.id}" 
                data-action="view" 
                onclick="viewTripDetails(${request.id})">
            <i class="fas fa-eye"></i> View
        </button>
    `;
    
    // Add assign button if company vehicle is requested and not yet assigned
    let assignButton = '';
    if (request.company_vehicle === 'Yes' && 
        (!request.vehicle_id || !request.driver_id) && 
        request.status !== 'Rejected') {
        assignButton = `
            <button type="button" 
                class="btn btn-success btn-sm ml-1" 
                onclick="assignVehicleAndDriver(${request.id})">
                <i class="fas fa-truck"></i> Assign
            </button>`;
    }

    return `<tr>
        <td>${request.id}</td>
        <td>${request.requestor_name}</td>
        <td>${request.department}</td>
        <td>${dateNeeded}</td>
        <td>
            <span class="badge ${DashboardManager.getStatusBadgeClass(request.approvers.manager.status)}">
                ${request.approvers.manager.status}
            </span><br>
            <small>${request.approvers.manager.name || 'Not Assigned'}</small>
        </td>
        <td>
            <span class="badge ${DashboardManager.getStatusBadgeClass(request.approvers.admin.status)}">
                ${request.approvers.admin.status}
            </span><br>
            <small>${request.approvers.admin.name ? request.approvers.admin.name : 'Not Yet Assigned'}</small>
        </td>
        <td>
            <span class="badge ${DashboardManager.getStatusBadgeClass(request.approvers.hr_manager.status)}">
                ${request.approvers.hr_manager.status}
            </span><br>
            <small>${request.approvers.hr_manager.name || 'Not Assigned'}</small>
        </td>
        <td>
            <span class="badge ${badgeClass}">
                ${overallStatus}
            </span>
        </td>
        <td class="text-center">
            ${viewButton}
            ${assignButton}
        </td>
    </tr>`;
}


// Pagination and filtering variables
let currentPage = 1;
let itemsPerPage = 10;
let filteredData = [];
let allTripData = [];

// Enhanced loadTripRequests function with pagination and filtering
function loadTripRequests() {
    $.ajax({
        url: '../fetch_admin_trips.php',
        method: 'GET',
        dataType: 'json',
        success: function(response) {
            if (response.error) {
                console.error('Server Error:', response.error);
                if (response.error === 'Unauthorized access') {
                    window.location.href = '../login.php';
                    return;
                }
                Swal.fire('Error', response.error, 'error');
                return;
            }
            
            // Store all trip data
            allTripData = response;
            
            // Apply filters
            applyFilters();
        },
        error: function(xhr, status, error) {
            console.error('AJAX Error:', error);
            if (xhr.status === 403) {
                window.location.href = '../login.php';
            } else {
                Swal.fire('Error', 'Failed to load trip requests', 'error');
            }
        }
    });
}

// Function to apply filters and update the table
function applyFilters() {
    const searchTerm = $('#searchInput').val().toLowerCase();
    const statusFilter = $('#statusFilter').val();
    const departmentFilter = $('#departmentFilter').val();
    const dateFilter = $('#dateFilter').val();
    
    // Filter the data
    filteredData = allTripData.filter(request => {
        // Search term filter
        const matchesSearch = searchTerm === '' || 
            request.requestor_name.toLowerCase().includes(searchTerm) ||
            request.department.toLowerCase().includes(searchTerm) ||
            (request.purpose && request.purpose.toLowerCase().includes(searchTerm));
        
        // Status filter
        let statusMatch = true;
        if (statusFilter) {
            if (statusFilter === 'REQUEST COMPLETED') {
                statusMatch = request.approvers.manager.status === 'Approved' && 
                              request.approvers.admin.status === 'Approved' && 
                              request.approvers.hr_manager.status === 'Approved';
            } else if (statusFilter === 'Pending') {
                // Match if any approver has Pending status
                statusMatch = request.approvers.manager.status === 'Pending' || 
                              request.approvers.admin.status === 'Pending' || 
                              request.approvers.hr_manager.status === 'Pending';
            } else if (statusFilter === 'Approved') {
                // Match if any approver has Approved status
                statusMatch = request.approvers.manager.status === 'Approved' || 
                              request.approvers.admin.status === 'Approved' || 
                              request.approvers.hr_manager.status === 'Approved';
            } else if (statusFilter === 'Rejected') {
                // Match if any approver has Rejected status
                statusMatch = request.approvers.manager.status === 'Rejected' || 
                              request.approvers.admin.status === 'Rejected' || 
                              request.approvers.hr_manager.status === 'Rejected';
            } else {
                // Fallback to overall status for any other status values
                statusMatch = request.status === statusFilter;
            }
        }
        
        // Department filter - show all if empty value is selected
        const departmentMatch = !departmentFilter || request.department === departmentFilter;
        
        // Date filter
        const dateMatch = dateFilter === '' || request.date_needed.includes(dateFilter);
        
        return matchesSearch && statusMatch && departmentMatch && dateMatch;
    });
    
    // Update pagination info
    updatePaginationInfo();
    
    // Render the current page
    renderCurrentPage();
}

// Function to update pagination information
function updatePaginationInfo() {
    const totalRecords = filteredData.length;
    const totalPages = Math.ceil(totalRecords / itemsPerPage);
    
    // Adjust current page if needed
    if (currentPage > totalPages) {
        currentPage = totalPages > 0 ? totalPages : 1;
    }
    
    // Calculate showing range
    const start = (currentPage - 1) * itemsPerPage + 1;
    const end = Math.min(start + itemsPerPage - 1, totalRecords);
    
    // Update pagination info text
    $('#showingStart').text(totalRecords > 0 ? start : 0);
    $('#showingEnd').text(end);
    $('#totalRecords').text(totalRecords);
    
    // Update page number
    $('#pageNumber a').text(currentPage);
    
    // Enable/disable prev/next buttons
    $('#prevPage').toggleClass('disabled', currentPage === 1);
    $('#nextPage').toggleClass('disabled', currentPage === totalPages || totalPages === 0);
}

// Function to render the current page
function renderCurrentPage() {
    const start = (currentPage - 1) * itemsPerPage;
    const end = start + itemsPerPage;
    const pageData = filteredData.slice(start, end);
    
    let tableRows = '';
    if (pageData.length === 0) {
        tableRows = '<tr><td colspan="9" class="text-center">No trip requests found</td></tr>';
    } else {
        pageData.forEach(request => {
            tableRows += generateTableRow(request);
        });
    }
    
    $('#tripRequestsTable').fadeOut(200, function() {
        $(this).html(tableRows).fadeIn(200);
    });
}

// Event handlers for pagination and filtering
$(document).ready(function() {
    // Add to existing document ready code
    
    // Pagination event handlers
    $('#prevPage').on('click', function(e) {
        e.preventDefault();
        if (currentPage > 1) {
            currentPage--;
            renderCurrentPage();
            updatePaginationInfo();
        }
    });
    
    $('#nextPage').on('click', function(e) {
        e.preventDefault();
        const totalPages = Math.ceil(filteredData.length / itemsPerPage);
        if (currentPage < totalPages) {
            currentPage++;
            renderCurrentPage();
            updatePaginationInfo();
        }
    });
    
    // Search and filter event handlers
    $('#searchButton').on('click', function() {
        currentPage = 1;
        applyFilters();
    });
    
    $('#searchInput').on('keypress', function(e) {
        if (e.which === 13) {
            currentPage = 1;
            applyFilters();
        }
    });
    
    $('#statusFilter, #departmentFilter').on('change', function() {
        currentPage = 1;
        applyFilters();
    });
    
    $('#dateFilter').on('change', function() {
        currentPage = 1;
        applyFilters();
    });
    
    $('#resetFilters').on('click', function() {
        $('#searchInput').val('');
        $('#statusFilter').val('');
        $('#departmentFilter').val('');
        $('#dateFilter').val('');
        currentPage = 1;
        applyFilters();
    });
});
// Function to handle view trip details
function viewTripDetails(tripId) {
    console.log('View button clicked for trip ID:', tripId);
    
    // Show loading indicator if available
    if ($('#loadingIndicator').length) {
        $('#loadingIndicator').show();
    }
    
    // Show the modal first for better UX
    $('#tripDetailsModal').modal('show');
    
    // Then fetch the trip details
    $.ajax({
        url: '../fetch_trip_details.php',
        method: 'GET',
        data: { id: tripId },
        dataType: 'json',
        success: function(response) {
            if (response.error) {
                Swal.fire('Error', response.error, 'error');
                return;
            }
            
            // Update modal content
            updateModalContent(response);
        },
        error: function(xhr, status, error) {
            console.error('AJAX Error:', error);
            console.log('XHR status:', xhr.status);
            console.log('XHR response text:', xhr.responseText);
            Swal.fire('Error', 'Failed to load trip details', 'error');
        },
        complete: function() {
            // Hide loading indicator if available
            if ($('#loadingIndicator').length) {
                $('#loadingIndicator').hide();
            }
        }
    });
}

// Add this function after your existing JavaScript code
function assignVehicleAndDriver(tripId) {
    // Show loading indicator
    $('#loadingIndicator').show();
    
    // Fetch available vehicles and drivers
    Promise.all([
        $.ajax({
            url: '../fetch_available_vehicles.php',
            method: 'GET',
            dataType: 'json'
        }),
        $.ajax({
            url: '../fetch_available_drivers.php',
            method: 'GET',
            dataType: 'json'
        })
    ]).then(([vehicles, drivers]) => {
        $('#loadingIndicator').hide();

        // Validate if vehicles and drivers are available
        if (!vehicles.length) {
            Swal.fire('Error', 'No vehicles are currently available', 'error');
            return;
        }
        if (!drivers.length) {
            Swal.fire('Error', 'No drivers are currently available', 'error');
            return;
        }

        // Create select options
        const vehicleOptions = vehicles.map(v => 
            `<option value="${v.id}">${v.name} - ${v.plate_number} (${v.status})</option>`
        ).join('');
        
        const driverOptions = drivers.map(d => 
            `<option value="${d.id}">${d.name} - License: ${d.license_number} (${d.contact})</option>`
        ).join('');

        // Show assignment modal
        Swal.fire({
            title: 'Assign Vehicle and Driver',
            html: `
                <form id="assignmentForm" class="text-left">
                    <div class="form-group">
                        <label class="font-weight-bold mb-2">Select Vehicle:</label>
                        <select class="form-control mb-3" id="swal-vehicle" required>
                            <option value="">-- Select a vehicle --</option>
                            ${vehicleOptions}
                        </select>
                        
                        <label class="font-weight-bold mb-2">Select Driver:</label>
                        <select class="form-control mb-3" id="swal-driver" required>
                            <option value="">-- Select a driver --</option>
                            ${driverOptions}
                        </select>
                        
                        <label class="font-weight-bold mb-2">Assignment Notes:</label>
                        <textarea class="form-control" id="swal-notes" 
                            rows="3" required 
                            placeholder="Add any special instructions or notes..."></textarea>
                    </div>
                </form>
            `,
            showCancelButton: true,
            confirmButtonText: 'Assign',
            confirmButtonColor: '#28a745',
            cancelButtonText: 'Cancel',
            width: '600px',
            preConfirm: () => {
                const vehicle = Swal.getPopup().querySelector('#swal-vehicle').value;
                const driver = Swal.getPopup().querySelector('#swal-driver').value;
                const notes = Swal.getPopup().querySelector('#swal-notes').value.trim();
                
                if (!vehicle) return Swal.showValidationMessage('Please select a vehicle');
                if (!driver) return Swal.showValidationMessage('Please select a driver');
                if (!notes) return Swal.showValidationMessage('Please add assignment notes');
                
                return { vehicle, driver, notes };
            }
        }).then((result) => {
            if (result.isConfirmed) {
                $('#loadingIndicator').show();
                
                $.ajax({
                    url: '../assign_vehicle_driver.php',
                    method: 'POST',
                    data: {
                        trip_id: tripId,
                        vehicle_id: result.value.vehicle,
                        driver_id: result.value.driver,
                        notes: result.value.notes
                    },
                    dataType: 'json',
                    success: function(response) {
                        $('#loadingIndicator').hide();
                        
                        if (response.status === 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: 'Assignment Successful',
                                text: 'Vehicle and driver have been assigned.',
                                timer: 2000
                            }).then(() => {
                                loadTripRequests();
                            });
                        } else {
                            Swal.fire('Error', response.message || 'Failed to assign vehicle and driver', 'error');
                        }
                    },
                    error: function(xhr, status, error) {
                        $('#loadingIndicator').hide();
                        console.error('Assignment Error:', error);
                        Swal.fire('Error', 'Failed to assign vehicle and driver', 'error');
                    }
                });
            }
        });
    }).catch(error => {
        $('#loadingIndicator').hide();
        console.error('Error:', error);
        Swal.fire('Error', 'Failed to load vehicle and driver data', 'error');
    });
}
</script>
</body>
</html>
