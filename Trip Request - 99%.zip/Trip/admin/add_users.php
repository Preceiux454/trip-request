<?php
require '../db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $role = $_POST['role'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $query = "INSERT INTO users (name, email, role, password) VALUES ('$name', '$email', '$role', '$password')";
    if (mysqli_query($conn, $query)) {
        // Redirect back with success flag
        header("Location: manage_users.php?success=1");
        exit();
    } else {
        // Redirect back with error flag
        header("Location: manage_users.php?error=1");
        exit();
    }
}
?>
