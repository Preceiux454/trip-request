<!-- Main Sidebar -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <div class="brand-container">
        <a href="admin_master_dash.php" class="brand-link">
            <img src="../img/logo.png" alt="Toyota Logo" class="brand-image">
            <span class="brand-text">VEHICLE REQUEST SYSTEM </span>
        </a>
    </div>

    <!-- Sidebar -->
    <div class="sidebar">
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu">
                  <!-- Analytics -->
                  <li class="nav-item">
                    <a href="analytics_dashboard.php" class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'analytics_dashboard.php') ? 'active' : '' ?>">
                        <i class="nav-icon fas fa-chart-line"></i>
                        <p>Analytics Dashboard</p>
                    </a>
                </li>

                <!-- Dashboard -->
                <li class="nav-item">
                    <a href="admin_master_dash.php" class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'admin_master_dash.php') ? 'active' : '' ?>">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>Requests Dashboard</p>
                    </a>
                </li>

              
                <!-- Vehicle Management -->
                <li class="nav-item">
                    <a href="driver_management.php" class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'driver_management.php') ? 'active' : '' ?>">
                        <i class="nav-icon fas fa-id-card"></i>
                        <p>Manage Drivers</p>
                    </a>
                </li>

                <!-- Vehicle Management -->
                <li class="nav-item">
                    <a href="manage_vehicles.php" class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'vehicle_management.php') ? 'active' : '' ?>">
                        <i class="nav-icon fas fa-car"></i>
                        <p>Manage Vehicles</p>
                    </a>
                </li>

                <!-- Manage Users -->
                <li class="nav-item">
                    <a href="manage_users.php" class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'manage_users.php') ? 'active' : '' ?>">
                        <i class="nav-icon fas fa-users-cog"></i>
                        <p>Manage Users</p>
                    </a>
                </li>

                <!-- Logout -->
                <li class="nav-item mt-auto">
                    <a href="../logout.php" class="nav-link text-danger">
                        <i class="nav-icon fas fa-sign-out-alt"></i>
                        <p>Logout</p>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</aside>
