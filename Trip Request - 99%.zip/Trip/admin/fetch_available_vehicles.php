<?php
session_start();
require_once '../db.php';

header('Content-Type: application/json');

if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'Master Admin') {
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

try {
    // Gets only available vehicles for selection
    $query = "SELECT id, name, plate_number FROM vehicles WHERE status = 'Available' ORDER BY name";
    $result = mysqli_query($conn, $query);
    
    if (!$result) {
        throw new Exception(mysqli_error($conn));
    }

    $vehicles = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $vehicles[] = [
            'id' => $row['id'],
            'name' => htmlspecialchars($row['name']),
            'plate_number' => htmlspecialchars($row['plate_number'])
        ];
    }

    echo json_encode($vehicles);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}

mysqli_close($conn);