<?php
session_start();
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'Master Admin') {
    header("Location: ../login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<style>
/* Updated Sidebar Styling */
        .main-sidebar {
            background: #1a1a1a;
            box-shadow: 4px 0 10px rgba(0, 0, 0, 0.1);
            border-right: 1px solid rgba(255,255,255,0.1);
        }

        .brand-container {
            background: #ffffff;
            padding: 1.5rem;
            text-align: center;
            border-bottom: 1px solid rgba(0,0,0,0.1);
        }

        .brand-link {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none !important;
        }

        .brand-image {
            height: 50px;
            margin-bottom: 0.75rem;
            transition: transform 0.3s ease;
        }

        .brand-image:hover {
            transform: scale(1.05);
        }

        .brand-text {
            color: #1a1a1a;
            font-size: 1.2rem;
            font-weight: 600;
            text-align: center;
        }

        .sidebar .nav-pills .nav-link {
            color: rgba(255,255,255,0.8);
            border-radius: 8px;
            margin: 0.25rem 1rem;
            transition: all 0.3s ease;
            padding: 0.75rem 1rem;
        }

        .sidebar .nav-pills .nav-link:hover {
            color: #ffffff;
            background: rgba(255,255,255,0.1);
            transform: translateX(5px);
        }

        .sidebar .nav-pills .nav-link.active {
            background: #dc3545;
            color: #ffffff;
            box-shadow: 0 2px 4px rgba(220,53,69,0.4);
        }

        .nav-sidebar .nav-link i {
            margin-right: 0.75rem;
            width: 1.25rem;
            text-align: center;
            transition: all 0.3s ease;
        }

        .sidebar .nav-pills .nav-link:hover i {
            transform: translateX(3px);
        }

        .nav-sidebar > .nav-item {
            margin-bottom: 0.25rem;
        }

        .sidebar .mt-auto {
            margin-top: auto !important;
            border-top: 1px solid rgba(255,255,255,0.1);
            padding-top: 1rem;
        }

        .nav-sidebar .nav-link.text-danger {
            color: #dc3545 !important;
        }

        .nav-sidebar .nav-link.text-danger:hover {
            background: rgba(220,53,69,0.1);
        }
        .text-muted {
    font-size: 1rem;
}

.text-muted i {
    color:rgb(255, 0, 0);
}

.float-right h5 {
    margin: 0;
    padding: 10px;
    border-radius: 5px;
    background: rgba(255, 255, 255, 0.05);
}
</style>
<head>
    <meta charset="UTF-8">
    <title>Manage Drivers</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="css/admin-style.css">
</head>
<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <?php include 'inc/admin_sidebar.php'; ?>
        <div class="content-wrapper">
            <section class="content-header">
                <div class="container-fluid">
                <div class="row mb-2">
    <div class="col-sm-6">
        <h1><i class="fas fa-id-card text-dark mr-2"></i> Manage Drivers</h1>
    </div>
    <div class="col-sm-6">
        <div class="float-right">
            <h5 class="text-muted">
                <i class="fas fa-user mr-2"></i> 
                Bonjour, <?php echo htmlspecialchars($_SESSION['name']); ?>!
            </h5>
        </div>
    </div>
</div>
                </div>
            </section>
            <section class="content">
                <div class="container-fluid">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Driver List</h3>
                            <div class="card-tools">
                                <button id="addDriverBtn" class="btn btn-primary btn-sm">
                                    <i class="fas fa-plus"></i> Add New Driver
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <table id="driversTable" class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Contact</th>
                                        <th>License Number</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- ...AJAX loaded driver rows... -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <!-- ...scripts and AJAX functions for add, edit, delete operations... -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/js/adminlte.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // ...existing JS code...
        $(document).ready(function() {
            // Function to load drivers via AJAX
            function loadDrivers() {
                $.ajax({
                    url: 'fetch_available_drivers.php',
                    method: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        let rows = '';
                        $.each(response, function(i, driver) {
                            rows += `
                                <tr>
                                    <td>${driver.id}</td>
                                    <td>${driver.name}</td>
                                    <td>${driver.contact}</td>
                                    <td>${driver.license_number}</td>
                                    <td>${driver.status}</td>
                                    <td>
                                        <button class="btn btn-sm btn-primary edit-driver" data-id="${driver.id}"><i class="fas fa-edit"></i></button>
                                        <button class="btn btn-sm btn-danger delete-driver" data-id="${driver.id}"><i class="fas fa-trash-alt"></i></button>
                                    </td>
                                </tr>
                            `;
                        });
                        $('#driversTable tbody').html(rows);
                    },
                    error: function() {
                        alert('Failed to load drivers');
                    }
                });
            }
            loadDrivers();
            // ...handlers for add, edit, delete driver operations...
            $('#addDriverBtn').on('click', function() {
                Swal.fire({
                    title: 'Add New Driver',
                    html: `
                        <form id="addDriverForm" class="text-left">
                            <div class="form-group">
                                <label for="name">Driver Name:</label>
                                <input type="text" class="form-control" id="name" required>
                            </div>
                            <div class="form-group">
                                <label for="contact">Contact Number:</label>
                                <input type="text" class="form-control" id="contact" required>
                            </div>
                            <div class="form-group">
                                <label for="license_number">License Number:</label>
                                <input type="text" class="form-control" id="license_number" required>
                            </div>
                        </form>
                    `,
                    showCancelButton: true,
                    confirmButtonText: 'Add Driver',
                    confirmButtonColor: '#28a745',
                    cancelButtonText: 'Cancel',
                    preConfirm: () => {
                        const name = Swal.getPopup().querySelector('#name').value;
                        const contact = Swal.getPopup().querySelector('#contact').value;
                        const license_number = Swal.getPopup().querySelector('#license_number').value;

                        if (!name || !contact || !license_number) {
                            Swal.showValidationMessage('Please fill in all fields');
                            return false;
                        }

                        return { name, contact, license_number };
                    }
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: 'add_driver.php',
                            method: 'POST',
                            data: result.value,
                            dataType: 'json',
                            success: function(response) {
                                if (response.status === 'success') {
                                    Swal.fire('Success', response.message, 'success')
                                        .then(() => {
                                            loadDrivers(); // Reload the drivers table
                                        });
                                } else {
                                    Swal.fire('Error', response.message, 'error');
                                }
                            },
                            error: function(xhr, status, error) {
                                console.error('AJAX Error:', error);
                                Swal.fire('Error', 'Failed to add driver. Please try again.', 'error');
                            }
                        });
                    }
                });
            });
        });
    </script>
</body>
</html>
