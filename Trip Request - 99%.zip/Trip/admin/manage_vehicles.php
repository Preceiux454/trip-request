<?php
session_start();
require_once '../db.php';

if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'Master Admin') {
    header("Location: ../login.php");
    exit();
}

$admin_name = $_SESSION['name'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Vehicles</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<style>
/* Updated Sidebar Styling */
        .main-sidebar {
            background: #1a1a1a;
            box-shadow: 4px 0 10px rgba(0, 0, 0, 0.1);
            border-right: 1px solid rgba(255,255,255,0.1);
        }

        .brand-container {
            background: #ffffff;
            padding: 1.5rem;
            text-align: center;
            border-bottom: 1px solid rgba(0,0,0,0.1);
        }

        .brand-link {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none !important;
        }

        .brand-image {
            height: 50px;
            margin-bottom: 0.75rem;
            transition: transform 0.3s ease;
        }

        .brand-image:hover {
            transform: scale(1.05);
        }

        .brand-text {
            color: #1a1a1a;
            font-size: 1.2rem;
            font-weight: 600;
            text-align: center;
        }

        .sidebar .nav-pills .nav-link {
            color: rgba(255,255,255,0.8);
            border-radius: 8px;
            margin: 0.25rem 1rem;
            transition: all 0.3s ease;
            padding: 0.75rem 1rem;
        }

        .sidebar .nav-pills .nav-link:hover {
            color: #ffffff;
            background: rgba(255,255,255,0.1);
            transform: translateX(5px);
        }

        .sidebar .nav-pills .nav-link.active {
            background: #dc3545;
            color: #ffffff;
            box-shadow: 0 2px 4px rgba(220,53,69,0.4);
        }

        .nav-sidebar .nav-link i {
            margin-right: 0.75rem;
            width: 1.25rem;
            text-align: center;
            transition: all 0.3s ease;
        }

        .sidebar .nav-pills .nav-link:hover i {
            transform: translateX(3px);
        }

        .nav-sidebar > .nav-item {
            margin-bottom: 0.25rem;
        }

        .sidebar .mt-auto {
            margin-top: auto !important;
            border-top: 1px solid rgba(255,255,255,0.1);
            padding-top: 1rem;
        }

        .nav-sidebar .nav-link.text-danger {
            color: #dc3545 !important;
        }

        .nav-sidebar .nav-link.text-danger:hover {
            background: rgba(220,53,69,0.1);
        }
        .text-muted {
    font-size: 1rem;
}

.text-muted i {
    color:rgb(255, 0, 0)
}

.float-right h5 {
    margin: 0;
    padding: 10px;
    border-radius: 5px;
    background: rgba(255, 255, 255, 0.05);
}
</style>
<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <?php include 'inc/admin_sidebar.php'; ?>

        <div class="content-wrapper">
            <section class="content-header">
                <div class="container-fluid">
                <div class="row mb-2">
    <div class="col-sm-6">
        <h1><i class="fas fa-car text-dark mr-2"></i> Manage Vehicles</h1>
    </div>
    <div class="col-sm-6">
        <div class="float-right">
            <h5 class="text-muted">
                <i class="fas fa-user mr-2"></i> 
                Bonjour, <?php echo htmlspecialchars($_SESSION['name']); ?>!
            </h5>
        </div>
        </div>
  
                        <div class="col-sm-6">
                            <button class="btn btn-primary float-right" id="addVehicleBtn">
                                <i class="fas fa-plus"></i> Add New Vehicle
                            </button>
                        </div>
                    </div>
                </div>
            </section>

            <section class="content">
                <div class="container-fluid">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Company Vehicles</h3>
                        </div>
                        <div class="card-body">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Vehicle Name</th>
                                        <th>Plate Number</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="vehiclesTable">
                                    <!-- Data will be loaded via AJAX -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/js/adminlte.min.js"></script>
    <script>
        $(document).ready(function() {
            loadVehicles();

            // Add Vehicle Button Click
            $('#addVehicleBtn').click(function() {
                Swal.fire({
                    title: 'Add New Vehicle',
                    html: `
                        <input type="text" id="vehicleName" class="swal2-input" placeholder="Vehicle Name">
                        <input type="text" id="plateNumber" class="swal2-input" placeholder="Plate Number">
                        <select id="vehicleStatus" class="swal2-input">
                            <option value="Available">Available</option>
                            <option value="In Use">In Use</option>
                            <option value="Maintenance">Maintenance</option>
                        </select>
                    `,
                    focusConfirm: false,
                    showCancelButton: true,
                    confirmButtonText: 'Add Vehicle',
                    preConfirm: () => {
                        return {
                            name: document.getElementById('vehicleName').value,
                            plate: document.getElementById('plateNumber').value,
                            status: document.getElementById('vehicleStatus').value
                        }
                    }
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: 'add_vehicle.php',
                            method: 'POST',
                            data: result.value,
                            success: function(response) {
                                if (response.status === 'success') {
                                    Swal.fire('Success', 'Vehicle added successfully!', 'success');
                                    loadVehicles();
                                } else {
                                    Swal.fire('Error', response.message || 'Failed to add vehicle', 'error');
                                }
                            },
                            error: function() {
                                Swal.fire('Error', 'Failed to process request', 'error');
                            }
                        });
                    }
                });
            });

            function loadVehicles() {
                $.ajax({
                    url: 'fetch_vehicles.php',
                    method: 'GET',
                    success: function(response) {
                        let tableRows = '';
                        response.forEach(vehicle => {
                            tableRows += `
                                <tr>
                                    <td>${vehicle.id}</td>
                                    <td>${vehicle.name}</td>
                                    <td>${vehicle.plate_number}</td>
                                    <td>
                                        <span class="badge badge-${getStatusBadgeClass(vehicle.status)}">
                                            ${vehicle.status}
                                        </span>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-primary edit-vehicle" data-id="${vehicle.id}">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-danger delete-vehicle" data-id="${vehicle.id}">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            `;
                        });
                        $('#vehiclesTable').html(tableRows);
                    }
                });
            }

            function getStatusBadgeClass(status) {
                switch(status.toLowerCase()) {
                    case 'available': return 'success';
                    case 'in use': return 'warning';
                    case 'maintenance': return 'danger';
                    default: return 'secondary';
                }
            }
        });
    </script>
</body>
</html>