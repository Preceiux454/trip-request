<?php
session_start();
require_once '../db.php';

header('Content-Type: application/json');

if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'Master Admin') {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized access']);
    exit;
}

try {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $plate = mysqli_real_escape_string($conn, $_POST['plate']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);

    if (empty($name) || empty($plate)) {
        throw new Exception("Vehicle name and plate number are required");
    }

    $query = "INSERT INTO vehicles (name, plate_number, status) VALUES (?, ?, ?)";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "sss", $name, $plate, $status);

    if (mysqli_stmt_execute($stmt)) {
        echo json_encode(['status' => 'success']);
    } else {
        throw new Exception("Failed to add vehicle");
    }

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}

mysqli_close($conn);