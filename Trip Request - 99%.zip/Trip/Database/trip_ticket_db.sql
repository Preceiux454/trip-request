-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 16, 2025 at 04:47 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `trip_ticket_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `approvals`
--

CREATE TABLE `approvals` (
  `id` int(11) NOT NULL,
  `trip_id` int(11) NOT NULL,
  `approver_role` enum('manager','admin','hr') NOT NULL,
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `comment` text DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `approval_date` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `approvals`
--

INSERT INTO `approvals` (`id`, `trip_id`, `approver_role`, `status`, `comment`, `timestamp`, `approval_date`, `created_at`) VALUES
(198, 79, 'manager', 'Approved', 'fire', '2025-03-14 12:38:06', NULL, '2025-03-14 12:39:27'),
(199, 79, 'admin', 'Approved', 'g', '2025-03-14 12:40:04', NULL, '2025-03-14 12:40:04'),
(200, 79, '', 'Approved', 'g', '2025-03-14 12:41:06', NULL, '2025-03-14 12:41:06'),
(201, 80, 'manager', 'Approved', 'g', '2025-03-16 11:32:23', NULL, '2025-03-16 11:33:16'),
(202, 80, 'admin', 'Approved', 'g', '2025-03-16 11:34:07', NULL, '2025-03-16 11:34:07'),
(203, 80, 'hr', 'Approved', 'fire', '2025-03-16 11:35:18', NULL, '2025-03-16 11:35:18'),
(204, 81, 'manager', 'Approved', '', '2025-03-16 11:52:14', NULL, '2025-03-16 11:52:28'),
(205, 81, 'admin', 'Approved', 'g', '2025-03-16 11:53:07', NULL, '2025-03-16 11:53:07'),
(206, 81, 'hr', 'Approved', 'g', '2025-03-16 11:54:03', NULL, '2025-03-16 11:54:03'),
(207, 82, 'manager', 'Pending', NULL, '2025-03-16 12:18:17', NULL, '2025-03-16 12:18:17'),
(208, 83, 'manager', 'Pending', NULL, '2025-03-16 12:26:20', NULL, '2025-03-16 12:26:20'),
(209, 84, 'manager', 'Pending', NULL, '2025-03-16 12:37:59', NULL, '2025-03-16 12:37:59'),
(210, 85, 'manager', 'Rejected', 'g', '2025-03-16 12:38:03', NULL, '2025-03-16 13:43:29'),
(211, 86, 'manager', 'Approved', 'g', '2025-03-16 12:48:12', NULL, '2025-03-16 13:33:09'),
(212, 86, 'admin', 'Approved', 'g', '2025-03-16 13:45:55', NULL, '2025-03-16 13:45:55'),
(213, 86, 'hr', 'Approved', 'g', '2025-03-16 13:46:45', NULL, '2025-03-16 13:46:45'),
(214, 87, 'manager', 'Approved', 'gggggggg', '2025-03-16 15:14:53', NULL, '2025-03-16 15:22:47'),
(215, 88, 'manager', 'Approved', 'G', '2025-03-16 15:23:56', NULL, '2025-03-16 15:24:06'),
(216, 89, 'manager', 'Approved', 'G', '2025-03-16 15:26:26', NULL, '2025-03-16 15:26:41'),
(217, 90, 'manager', 'Approved', 'g', '2025-03-16 15:40:12', NULL, '2025-03-16 15:44:45'),
(218, 90, 'admin', 'Approved', 'g', '2025-03-16 15:45:52', NULL, '2025-03-16 15:45:52'),
(219, 90, 'hr', 'Approved', 'g', '2025-03-16 15:46:52', NULL, '2025-03-16 15:46:52');

-- --------------------------------------------------------

--
-- Table structure for table `drivers`
--

CREATE TABLE `drivers` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `license_number` varchar(50) NOT NULL,
  `status` enum('Available','Assigned','Unavailable') DEFAULT 'Available',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `drivers`
--

INSERT INTO `drivers` (`id`, `name`, `contact`, `license_number`, `status`, `created_at`, `updated_at`) VALUES
(7, 'John Doe', '09123456789', 'LIC-2025-001', 'Assigned', '2025-03-14 12:36:34', '2025-03-16 13:45:55'),
(8, 'Maria Garcia', '09234567890', 'LIC-2025-002', 'Available', '2025-03-14 12:36:34', '2025-03-14 12:36:54'),
(9, 'Robert Smith', '09345678901', 'LIC-2025-003', 'Available', '2025-03-14 12:36:34', '2025-03-14 12:36:34'),
(10, 'Sarah Johnson', '09456789012', 'LIC-2025-004', 'Available', '2025-03-14 12:36:34', '2025-03-14 12:36:54'),
(11, 'Michael Brown', '09567890123', 'LIC-2025-005', 'Available', '2025-03-14 12:36:34', '2025-03-14 12:36:34'),
(12, 'Emily Wilson', '09678901234', 'LIC-2025-006', 'Assigned', '2025-03-14 12:36:34', '2025-03-16 11:34:07'),
(13, 'David Lee', '09789012345', 'LIC-2025-007', 'Assigned', '2025-03-14 12:36:34', '2025-03-14 12:40:04'),
(14, 'Lisa Anderson', '09890123456', 'LIC-2025-008', 'Available', '2025-03-14 12:36:34', '2025-03-14 12:36:54'),
(15, 'James Taylor', '09901234567', 'LIC-2025-009', 'Assigned', '2025-03-14 12:36:34', '2025-03-16 11:53:07'),
(16, 'Patricia Martinez', '09012345678', 'LIC-2025-010', 'Available', '2025-03-14 12:36:34', '2025-03-14 12:36:34'),
(17, 'Gojo Satoru', '123', '321', 'Assigned', '2025-03-16 14:54:06', '2025-03-16 15:45:52');

-- --------------------------------------------------------

--
-- Table structure for table `trip_archives`
--

CREATE TABLE `trip_archives` (
  `archive_id` int(11) NOT NULL,
  `trip_id` int(11) NOT NULL,
  `approver_id` int(11) NOT NULL,
  `approver_role` enum('Manager','Admin','HR Manager') NOT NULL,
  `archived_date` datetime DEFAULT current_timestamp(),
  `archive_status` varchar(50) NOT NULL,
  `archive_comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trip_requests`
--

CREATE TABLE `trip_requests` (
  `id` int(11) NOT NULL,
  `requestor_name` varchar(255) NOT NULL,
  `requestor_email` varchar(255) NOT NULL,
  `department` enum('CRD','FAD','HRAD','PD','SD','VSD','TSURE') NOT NULL,
  `manager_id` int(11) NOT NULL,
  `date_needed` date NOT NULL,
  `time_needed` time NOT NULL,
  `time_return` time NOT NULL,
  `route_from` varchar(255) NOT NULL,
  `route_to` varchar(255) NOT NULL,
  `passengers` text NOT NULL,
  `purpose` text NOT NULL,
  `company_vehicle` enum('Yes','No') NOT NULL,
  `status` enum('Pending','Manager Approved','Admin Approved','Rejected') DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `vehicle_id` int(11) DEFAULT NULL,
  `archived` tinyint(1) DEFAULT 0,
  `archive_date` datetime DEFAULT NULL,
  `driver_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trip_requests`
--

INSERT INTO `trip_requests` (`id`, `requestor_name`, `requestor_email`, `department`, `manager_id`, `date_needed`, `time_needed`, `time_return`, `route_from`, `route_to`, `passengers`, `purpose`, `company_vehicle`, `status`, `created_at`, `vehicle_id`, `archived`, `archive_date`, `driver_id`) VALUES
(79, 'Lalong Tumatamis', 'arvsimisimi@gmail.com', 'CRD', 19, '2025-03-15', '15:00:00', '15:00:00', 'TEST123', 'TEST123', 'TEST123', 'TEST123', 'No', '', '2025-03-14 12:38:06', 47, 0, NULL, 13),
(80, 'Mr. Lalong Nag E-error', 'arvsimisimi@gmail.com', 'CRD', 19, '2025-03-17', '15:00:00', '15:00:00', 'Santa Rosa ', 'Calamba', 'me', 'me', 'No', '', '2025-03-16 11:32:23', 54, 0, NULL, 12),
(81, 'asdsda', 'asdasdas@asdasd.aas', 'CRD', 19, '2025-03-14', '06:30:00', '06:30:00', 'asda', 'sad', 'asda', 'asd', 'Yes', '', '2025-03-16 11:52:14', 46, 0, NULL, 15),
(82, 'MIssy', 'arvsimisimi@gmail.com', 'TSURE', 19, '2025-03-28', '15:00:00', '18:00:00', 'dubat', 'egypt', 'meeee', 'secret', 'Yes', 'Pending', '2025-03-16 12:18:17', NULL, 0, NULL, NULL),
(83, 'akin kalang', 'arvsimisimi@gmail.com', 'SD', 19, '2025-03-19', '06:30:00', '06:30:00', 'asd', 'as', 'dsd', 'sdsd', 'No', 'Pending', '2025-03-16 12:26:20', NULL, 0, NULL, NULL),
(84, 'asdas', 'das@sadas.df', 'FAD', 19, '2025-03-06', '15:00:00', '14:30:00', 'asdas', 'asdasd', 'asda', 'asd', 'No', 'Pending', '2025-03-16 12:37:59', NULL, 0, NULL, NULL),
(85, 'asdas', 'das@sadas.df', 'FAD', 19, '2025-03-06', '15:00:00', '14:30:00', 'asdas', 'asdasd', 'asda', 'asd', 'No', 'Rejected', '2025-03-16 12:38:03', NULL, 0, NULL, NULL),
(86, 'Lalong Tumatamis2123', 'arvsss@gmail.com', 'FAD', 19, '2025-03-14', '14:30:00', '15:00:00', 'sadasd', 'asdad', 'asdas', 'asd', 'Yes', '', '2025-03-16 12:48:11', 51, 0, NULL, 7),
(87, 'Mr. Akin Ka Lang', 'akinkalan@gmail.com', 'HRAD', 14, '2025-03-19', '15:00:00', '15:00:00', 'Santa', 'DAAA', 'secret', 'secret', 'No', '', '2025-03-16 15:14:53', NULL, 1, '2025-03-16 16:22:50', NULL),
(88, 'Pedro Disumusuko', 'arvsss@gmail.com', 'PD', 14, '2025-03-19', '15:00:00', '14:30:00', 'sadasd', 'dd', 'asdad', 'asd', 'Yes', '', '2025-03-16 15:23:56', NULL, 1, '2025-03-16 16:24:10', NULL),
(89, 'WWWWW', 'adsad@asdad.ad', 'PD', 14, '2025-03-27', '14:30:00', '14:00:00', 'sad', 'asdd', 'd', 'd', 'Yes', '', '2025-03-16 15:26:26', NULL, 1, '2025-03-16 16:26:44', NULL),
(90, 'asdad', 'ddd@asdasd.asd', 'FAD', 19, '2025-03-18', '07:00:00', '07:00:00', 'asdad', 'dad', 'as', 'asd', 'Yes', '', '2025-03-16 15:40:12', 55, 1, '2025-03-16 16:44:48', 17);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('Master Admin','User','Manager','Admin','HR Manager') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`) VALUES
(8, 'Gojo Satoru', 'gojo@tsr.local', '$2y$10$2PWqi3cHUaOftslLIQ7/NeVoOAsG9Um01QzEBYpxlG46kFb004UDy', 'Manager'),
(11, 'Dito Ka Sakin', 'ditoka@tsr.local', '$2y$10$9ML3lSja2ytUWPHbnx3nEeR.Rnl2lOI8tzZPa0FrGyKFiXPgjn8Zi', 'User'),
(13, 'Victor Schevalier', 'vic@tsr.local', '$2y$10$aNzVkQ4BsPD8s3oqSeNLoOSNCk6xrmUeXa3pO3IkvVOFxfVFZ6GZe', 'Manager'),
(14, 'Dainty', 'dainty@tsr.local', '$2y$10$e2ax0QpnBdzhv3nAYXDf6OpX2tj1dEauDdIejK4Hxg0.mbkACAc2m', 'Manager'),
(15, 'Marie', 'marie@tsr.local', '$2y$10$v3WleJGXud4D0ER7L8ZK2eDAvHpcIsF.u4ewvCLxWSMAZ0ASN1jXq', 'Manager'),
(16, 'AdminMaster', 'masteradmin@tsr.local', '$2y$10$UObkL9qEHz.5qwH34NhsGuuXjX6LnQMG5IOqQZQ6d2bWeD5uhuM5G', 'Master Admin'),
(17, 'Shelby', 'johnarvie454@gmail.com', '$2y$10$TQ99aKKZ0Mq0NEagcmRojelm0Bq9LliwG4nSG5D8DVcV5q4IPtFoK', 'Admin'),
(18, 'Lalong Tumatamis', 'gptproject8@gmail.com', '$2y$10$ZioygyyC5wlZRlAmNjIrSOoyxCyBdUZz60N4NOT85psO09R07dj9y', 'HR Manager'),
(19, 'Bossingg', 'rdacc714@gmail.com', '$2y$10$ZKuFo2EShFt390996jp.luIJ1AF9hweJebReN/7b3BT6v9NPJ0f66', 'Manager'),
(20, 'Lalong Tumatabang', 'johnarasd@gmail.com', '$2y$10$o2JV23LVrKADrjP2crkCN.H6lcnjBbTL4VF7R/mlnUpIiS4OQ0kS6', 'User');

-- --------------------------------------------------------

--
-- Table structure for table `vehicles`
--

CREATE TABLE `vehicles` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `plate_number` varchar(20) NOT NULL,
  `status` enum('Available','In Use','Maintenance') DEFAULT 'Available',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vehicles`
--

INSERT INTO `vehicles` (`id`, `name`, `plate_number`, `status`, `created_at`) VALUES
(45, 'Toyota Camry', 'ABC-1234', 'Available', '2025-03-14 12:36:35'),
(46, 'Honda Civic', 'DEF-5678', 'In Use', '2025-03-14 12:36:35'),
(47, 'Ford Explorer', 'GHI-9012', 'In Use', '2025-03-14 12:36:35'),
(48, 'Nissan Urvan', 'JKL-3456', 'Available', '2025-03-14 12:36:35'),
(49, 'Toyota Hiace', 'MNO-7890', 'Available', '2025-03-14 12:36:35'),
(50, 'Mitsubishi L300', 'PQR-1234', 'Available', '2025-03-14 12:36:35'),
(51, 'Hyundai H100', 'STU-5678', 'In Use', '2025-03-14 12:36:35'),
(52, 'Isuzu MU-X', 'VWX-9012', 'Available', '2025-03-14 12:36:35'),
(53, 'Toyota Innova', 'YZA-3456', 'Available', '2025-03-14 12:36:35'),
(54, 'Honda BR-V', 'BCD-7890', 'In Use', '2025-03-14 12:36:35'),
(55, 'Hilux GRS', '123', 'In Use', '2025-03-16 14:45:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `approvals`
--
ALTER TABLE `approvals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_trip_approvals` (`trip_id`,`approver_role`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `drivers`
--
ALTER TABLE `drivers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trip_archives`
--
ALTER TABLE `trip_archives`
  ADD PRIMARY KEY (`archive_id`),
  ADD KEY `trip_id` (`trip_id`),
  ADD KEY `approver_id` (`approver_id`);

--
-- Indexes for table `trip_requests`
--
ALTER TABLE `trip_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_manager_id` (`manager_id`),
  ADD KEY `idx_vehicle_id` (`vehicle_id`),
  ADD KEY `driver_id` (`driver_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `approvals`
--
ALTER TABLE `approvals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=220;

--
-- AUTO_INCREMENT for table `drivers`
--
ALTER TABLE `drivers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `trip_archives`
--
ALTER TABLE `trip_archives`
  MODIFY `archive_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `trip_requests`
--
ALTER TABLE `trip_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `vehicles`
--
ALTER TABLE `vehicles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `approvals`
--
ALTER TABLE `approvals`
  ADD CONSTRAINT `approvals_ibfk_1` FOREIGN KEY (`trip_id`) REFERENCES `trip_requests` (`id`);

--
-- Constraints for table `trip_archives`
--
ALTER TABLE `trip_archives`
  ADD CONSTRAINT `trip_archives_ibfk_1` FOREIGN KEY (`trip_id`) REFERENCES `trip_requests` (`id`),
  ADD CONSTRAINT `trip_archives_ibfk_2` FOREIGN KEY (`approver_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `trip_requests`
--
ALTER TABLE `trip_requests`
  ADD CONSTRAINT `trip_requests_ibfk_1` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `trip_requests_ibfk_2` FOREIGN KEY (`driver_id`) REFERENCES `drivers` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
