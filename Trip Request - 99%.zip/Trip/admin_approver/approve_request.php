<?php
session_start();
require_once '../db.php';

header('Content-Type: application/json');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';

function sendHRNotification($hrEmail, $requestor_name, $adminName, $comment, $driverInfo) {
    $mail = new PHPMailer(true);
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;
        $mail->Username   = 'furfectmatch00@gmail.com';
        $mail->Password   = 'hshp joln vbgl yddk';

        // Recipients
        $mail->setFrom('furfectmatch00@gmail.com', 'Vehicle Request');
        $mail->addAddress($hrEmail);

        // Build email content with driver information
        $emailBody = "
        <b><p style='font-family: Arial, sans-serif; font-size: 16px; color: #333;'>Good Day HR Manager!,</p></b>
        <p style='font-family: Arial, sans-serif; font-size: 16px; color: #333;'>A trip request has been approved by <b>{$adminName}</b>, and would require your attention.</p>
        <p style='font-family: Arial, sans-serif; font-size: 16px; color: #333;'><strong>Approval Details:</strong><br>
        -----------------------------------------------<br>
        <b>Requestor Name:</b> {$requestor_name}<br>
        <b>Admin:</b> {$adminName}<br>
        <b>Comment:</b> {$comment}<br>
        -----------------------------------------------</p>
        
        <p style='font-family: Arial, sans-serif; font-size: 16px; color: #333;'><strong>Assigned Driver Details:</strong><br>
        -----------------------------------------------<br>
        <b>Driver Name:</b> {$driverInfo['name']}<br>
        <b>Contact Number:</b> {$driverInfo['contact']}<br>
        <b>License Number:</b> {$driverInfo['license_number']}<br>
        -----------------------------------------------</p>
        
        <p style='font-family: Arial, sans-serif; font-size: 16px; color: #333;'><b>You may access this link:</b> <a href='http://localhost/Trip/login.php'>localhost/Trip/login.php</a></p>
        <b><p style='font-family: Arial, sans-serif; font-size: 16px; color: #333;'>IMPORTANT: This is an automated notification. For technical assistance, please contact the IT Help Desk.</b></p>";

        // Email content
        $mail->isHTML(true);
        $mail->Subject = 'Vehicle Request - HR Approval';
        $mail->Body    = $emailBody;
        
        $mail->send();

    } catch (Exception $e) {
        throw new Exception("Mailer Error: {$mail->ErrorInfo}");
    }
}

if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'Admin') {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized access']);
    exit;
}

try {
    if (empty($_POST['trip_id']) || empty($_POST['vehicle_id']) || empty($_POST['driver_id'])) {
        throw new Exception("Missing required parameters");
    }

    $trip_id = intval($_POST['trip_id']);
    $vehicle_id = intval($_POST['vehicle_id']);
    $driver_id = intval($_POST['driver_id']);
    $comment = mysqli_real_escape_string($conn, $_POST['comment'] ?? '');

    mysqli_begin_transaction($conn);

    // Debug logging
    error_log("Processing approval - Trip ID: $trip_id, Vehicle: $vehicle_id, Driver: $driver_id");

    // Validate all IDs exist
    $validation_query = "SELECT 
        (SELECT COUNT(*) FROM trip_requests WHERE id = ?) as trip_exists,
        (SELECT COUNT(*) FROM vehicles WHERE id = ?) as vehicle_exists,
        (SELECT COUNT(*) FROM drivers WHERE id = ?) as driver_exists";
    
    $stmt = mysqli_prepare($conn, $validation_query);
    mysqli_stmt_bind_param($stmt, "iii", $trip_id, $vehicle_id, $driver_id);
    mysqli_stmt_execute($stmt);
    $validation_result = mysqli_stmt_get_result($stmt);
    $validation = mysqli_fetch_assoc($validation_result);

    if (!$validation['trip_exists'] || !$validation['vehicle_exists'] || !$validation['driver_exists']) {
        throw new Exception("Invalid trip, vehicle, or driver ID");
    }

    // Important check: Verifies manager approved first
    $check_query = "SELECT tr.status, tr.id, 
                          COALESCE(ma.status, 'Pending') as manager_status,
                          COALESCE(aa.status, 'Pending') as admin_status
                   FROM trip_requests tr
                   LEFT JOIN approvals ma ON tr.id = ma.trip_id AND ma.approver_role = 'manager'
                   LEFT JOIN approvals aa ON tr.id = aa.trip_id AND aa.approver_role = 'admin'
                   WHERE tr.id = ?";
    
    $stmt = mysqli_prepare($conn, $check_query);
    mysqli_stmt_bind_param($stmt, "i", $trip_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);

    if (!$row) {
        throw new Exception("Trip request not found");
    }

    // Allow processing if manager has approved and admin hasn't acted yet
    if ($row['manager_status'] !== 'Approved' || $row['admin_status'] !== 'Pending') {
        throw new Exception("Trip request cannot be processed in its current status");
    }

    // Validation of vehicle availability
    $vehicle_check = "SELECT status FROM vehicles WHERE id = ?";
    $stmt = mysqli_prepare($conn, $vehicle_check);
    mysqli_stmt_bind_param($stmt, "i", $vehicle_id);
    mysqli_stmt_execute($stmt);
    $vehicle_result = mysqli_stmt_get_result($stmt);
    $vehicle = mysqli_fetch_assoc($vehicle_result);

    if (!$vehicle || $vehicle['status'] !== 'Available') {
        throw new Exception("Selected vehicle is not available");
    }

    // Validate driver availability
    $driver_check = "SELECT status FROM drivers WHERE id = ?";
    $stmt = mysqli_prepare($conn, $driver_check);
    mysqli_stmt_bind_param($stmt, "i", $driver_id);
    mysqli_stmt_execute($stmt);
    $driver_result = mysqli_stmt_get_result($stmt);
    $driver = mysqli_fetch_assoc($driver_result);
    if (!$driver || $driver['status'] !== 'Available') {
        throw new Exception("Selected driver is not available");
    }

    // Key database updates:
    // 1. Insert admin approval
    $query = "INSERT INTO approvals (trip_id, approver_role, status, comment) 
              VALUES (?, 'admin', 'Approved', ?)";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "is", $trip_id, $comment);
    
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Failed to insert approval record: " . mysqli_stmt_error($stmt));
    }

    // 2. Update trip request with status, vehicle_id and driver_id
    $update_query = "UPDATE trip_requests 
                    SET status = 'Admin Approved', 
                        vehicle_id = ?, 
                        driver_id = ? 
                    WHERE id = ?";
    $stmt = mysqli_prepare($conn, $update_query);
    mysqli_stmt_bind_param($stmt, "iii", $vehicle_id, $driver_id, $trip_id);
    
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Failed to update trip request: " . mysqli_stmt_error($stmt));
    }

    // 3. Update vehicle status to 'In Use'
    $vehicle_update = "UPDATE vehicles SET status = 'In Use' WHERE id = ?";
    $stmt = mysqli_prepare($conn, $vehicle_update);
    mysqli_stmt_bind_param($stmt, "i", $vehicle_id);
    
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Failed to update vehicle status: " . mysqli_stmt_error($stmt));
    }

    // 4. Update driver status to 'Assigned'
    $driver_update = "UPDATE drivers SET status = 'Assigned' WHERE id = ?";
    $stmt = mysqli_prepare($conn, $driver_update);
    mysqli_stmt_bind_param($stmt, "i", $driver_id);
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Failed to update driver status: " . mysqli_stmt_error($stmt));
    }

    // Fetch driver details for email
    $driver_query = "SELECT name, contact, license_number FROM drivers WHERE id = ?";
    $stmt = mysqli_prepare($conn, $driver_query);
    mysqli_stmt_bind_param($stmt, "i", $driver_id);
    mysqli_stmt_execute($stmt);
    $driver_result = mysqli_stmt_get_result($stmt);
    $driverInfo = mysqli_fetch_assoc($driver_result);

    if (!$driverInfo) {
        throw new Exception("Driver information not found");
    }

    mysqli_commit($conn);

    // Fetch HR manager email dynamically
    $hr_query = "SELECT email FROM users WHERE role = 'HR Manager' LIMIT 1";
    $hr_result = mysqli_query($conn, $hr_query);
    if ($hr_result && mysqli_num_rows($hr_result) > 0) {
        $hrData = mysqli_fetch_assoc($hr_result);
        $hrEmail = $hrData['email'];
    } else {
        throw new Exception("HR Manager email not found");
    }

    // Fetch requestor name dynamically
    $requestor_query = "SELECT requestor_name FROM trip_requests WHERE id = ? LIMIT 1";
    $stmt = mysqli_prepare($conn, $requestor_query);
    mysqli_stmt_bind_param($stmt, "i", $trip_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    if ($result && mysqli_num_rows($result) > 0) {
        $requestorData = mysqli_fetch_assoc($result);
        $requestor_name = $requestorData['requestor_name'];
    } else {
        throw new Exception("Requestor name not found");
    }

    // Send email notification with driver info
    $adminName = $_SESSION['name']; // Assuming admin's name is stored in session
    sendHRNotification($hrEmail, $requestor_name, $adminName, $comment, $driverInfo);

    echo json_encode(['status' => 'success', 'message' => 'Request approved successfully']);

} catch (Exception $e) {
    mysqli_rollback($conn);
    error_log("Approval Error: " . $e->getMessage());
    error_log("Stack trace: " . $e->getTraceAsString());
    
    echo json_encode([
        'status' => 'error',
        'message' => 'Failed to process request: ' . $e->getMessage()
    ]);
} finally {
    if (isset($stmt)) {
        mysqli_stmt_close($stmt);
    }
    mysqli_close($conn);
}