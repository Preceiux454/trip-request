<?php
session_start();
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'Admin') {
    header("Location: ../login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Drivers</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/css/adminlte.min.css">
    <!-- ...existing head code (CSS, meta, etc.)... -->
</head>
<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <?php include 'inc/admin_approver_sidebar.php'; ?>
        <div class="content-wrapper">
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1>Manage Drivers</h1>
                        </div>
                        <div class="col-sm-6">
                            <div class="float-right">
                                <!-- Optionally display logged-in admin info -->
                                <h5 class="text-muted"><i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['name']); ?></h5>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="content">
                <div class="container-fluid">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Driver List</h3>
                            <div class="card-tools">
                                <button id="addDriverBtn" class="btn btn-primary btn-sm">
                                    <i class="fas fa-plus"></i> Add New Driver
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <table id="driversTable" class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Contact</th>
                                        <th>License Number</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- ...AJAX loaded driver rows... -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <!-- ...scripts and AJAX functions for add, edit, delete operations... -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/js/adminlte.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // ...existing JS code...
        $(document).ready(function() {
            // Function to load drivers via AJAX
            function loadDrivers() {
                $.ajax({
                    url: 'fetch_available_drivers.php',
                    method: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        let rows = '';
                        $.each(response, function(i, driver) {
                            rows += `
                                <tr>
                                    <td>${driver.id}</td>
                                    <td>${driver.name}</td>
                                    <td>${driver.contact}</td>
                                    <td>${driver.license_number}</td>
                                    <td>${driver.status}</td>
                                    <td>
                                        <button class="btn btn-sm btn-primary edit-driver" data-id="${driver.id}"><i class="fas fa-edit"></i></button>
                                        <button class="btn btn-sm btn-danger delete-driver" data-id="${driver.id}"><i class="fas fa-trash-alt"></i></button>
                                    </td>
                                </tr>
                            `;
                        });
                        $('#driversTable tbody').html(rows);
                    },
                    error: function() {
                        alert('Failed to load drivers');
                    }
                });
            }
            loadDrivers();
            // ...handlers for add, edit, delete driver operations...
            $('#addDriverBtn').on('click', function() {
                Swal.fire({
                    title: 'Add New Driver',
                    html: `
                        <form id="addDriverForm" class="text-left">
                            <div class="form-group">
                                <label for="name">Driver Name:</label>
                                <input type="text" class="form-control" id="name" required>
                            </div>
                            <div class="form-group">
                                <label for="contact">Contact Number:</label>
                                <input type="text" class="form-control" id="contact" required>
                            </div>
                            <div class="form-group">
                                <label for="license_number">License Number:</label>
                                <input type="text" class="form-control" id="license_number" required>
                            </div>
                        </form>
                    `,
                    showCancelButton: true,
                    confirmButtonText: 'Add Driver',
                    confirmButtonColor: '#28a745',
                    cancelButtonText: 'Cancel',
                    preConfirm: () => {
                        const name = Swal.getPopup().querySelector('#name').value;
                        const contact = Swal.getPopup().querySelector('#contact').value;
                        const license_number = Swal.getPopup().querySelector('#license_number').value;

                        if (!name || !contact || !license_number) {
                            Swal.showValidationMessage('Please fill in all fields');
                            return false;
                        }

                        return { name, contact, license_number };
                    }
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: 'add_driver.php',
                            method: 'POST',
                            data: result.value,
                            dataType: 'json',
                            success: function(response) {
                                if (response.status === 'success') {
                                    Swal.fire('Success', response.message, 'success')
                                        .then(() => {
                                            loadDrivers(); // Reload the drivers table
                                        });
                                } else {
                                    Swal.fire('Error', response.message, 'error');
                                }
                            },
                            error: function(xhr, status, error) {
                                console.error('AJAX Error:', error);
                                Swal.fire('Error', 'Failed to add driver. Please try again.', 'error');
                            }
                        });
                    }
                });
            });
        });
    </script>
</body>
</html>
