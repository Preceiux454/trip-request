<?php
session_start();
require_once '../db.php';

if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'Admin') {
    header("Location: ../login.php");
    exit();
}

$admin_name = $_SESSION['name'];
?>

<!DOCTYPE html>
<html lang="en">
    
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Vehicles</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <?php include 'inc/admin_approver_sidebar.php'; ?>

        <div class="content-wrapper">
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1><i class="fas fa-car"></i> Manage Vehicles</h1>
                        </div>
                        <div class="col-sm-6">
                            <button class="btn btn-primary float-right" id="addVehicleBtn">
                                <i class="fas fa-plus"></i> Add New Vehicle
                            </button>
                        </div>
                    </div>
                </div>
            </section>

            <section class="content">
                <div class="container-fluid">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Company Vehicles</h3>
                        </div>
                        <div class="card-body">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Vehicle Name</th>
                                        <th>Plate Number</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="vehiclesTable">
                                    <!-- Data will be loaded via AJAX -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/js/adminlte.min.js"></script>
    <script>
        $(document).ready(function() {
            loadVehicles();

            // Add Vehicle Button Click
            $('#addVehicleBtn').click(function() {
                Swal.fire({
                    title: 'Add New Vehicle',
                    html: `
                        <input type="text" id="vehicleName" class="swal2-input" placeholder="Vehicle Name">
                        <input type="text" id="plateNumber" class="swal2-input" placeholder="Plate Number">
                        <select id="vehicleStatus" class="swal2-input">
                            <option value="Available">Available</option>
                            <option value="In Use">In Use</option>
                            <option value="Maintenance">Maintenance</option>
                        </select>
                    `,
                    focusConfirm: false,
                    showCancelButton: true,
                    confirmButtonText: 'Add Vehicle',
                    preConfirm: () => {
                        return {
                            name: document.getElementById('vehicleName').value,
                            plate: document.getElementById('plateNumber').value,
                            status: document.getElementById('vehicleStatus').value
                        }
                    }
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: 'add_vehicle.php',
                            method: 'POST',
                            data: result.value,
                            success: function(response) {
                                if (response.status === 'success') {
                                    Swal.fire('Success', 'Vehicle added successfully!', 'success');
                                    loadVehicles();
                                } else {
                                    Swal.fire('Error', response.message || 'Failed to add vehicle', 'error');
                                }
                            },
                            error: function() {
                                Swal.fire('Error', 'Failed to process request', 'error');
                            }
                        });
                    }
                });
            });

            function loadVehicles() {
                $.ajax({
                    url: 'fetch_vehicles.php',
                    method: 'GET',
                    success: function(response) {
                        let tableRows = '';
                        response.forEach(vehicle => {
                            tableRows += `
                                <tr>
                                    <td>${vehicle.id}</td>
                                    <td>${vehicle.name}</td>
                                    <td>${vehicle.plate_number}</td>
                                    <td>
                                        <span class="badge badge-${getStatusBadgeClass(vehicle.status)}">
                                            ${vehicle.status}
                                        </span>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-primary edit-vehicle" data-id="${vehicle.id}">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-danger delete-vehicle" data-id="${vehicle.id}">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            `;
                        });
                        $('#vehiclesTable').html(tableRows);
                    }
                });
            }

            function getStatusBadgeClass(status) {
                switch(status.toLowerCase()) {
                    case 'available': return 'success';
                    case 'in use': return 'warning';
                    case 'maintenance': return 'danger';
                    default: return 'secondary';
                }
            }
        });
    </script>
</body>
</html>