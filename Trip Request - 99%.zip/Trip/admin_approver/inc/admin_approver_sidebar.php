<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <a href="#" class="brand-link">
        <i class="fas fa-user-shield"></i>
        <span class="brand-text font-weight-light">Admin Approver</span>
    </a>

    <div class="sidebar">
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu">
                <li class="nav-item">
                    <a href="./admin_approver.php" class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'admin_approver.php') ? 'active' : '' ?>">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                
                <li class="nav-item">
                    <a href="./manage_vehicles.php" class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'manage_vehicles.php') ? 'active' : '' ?>">
                        <i class="nav-icon fas fa-car"></i>
                        <p>Manage Vehicles</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="./driver_management.php" class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'driver_management.php') ? 'active' : '' ?>">
                        <i class="nav-icon fas fa-user-tie"></i>
                        <p>Manage Drivers</p>
                    </a>
                </li>

                <li class="nav-item mt-auto">
                    <a href="../logout.php" class="nav-link text-danger">
                        <i class="nav-icon fas fa-sign-out-alt"></i>
                        <p>Logout</p>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</aside>