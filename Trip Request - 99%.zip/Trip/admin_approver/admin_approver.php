<?php
session_start();
require_once '../db.php';

// Check if user is logged in and is an Admin Approver
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'Admin') {
    header("Location: ../login.php");
    exit();
}

$admin_name = $_SESSION['name'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Approver Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/js/adminlte.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="../js/modal-handler.js"></script>
    <style>
        .comment-block {
            background-color: #f8f9fa;
            border-radius: 5px;
            padding: 10px;
        }
        .comment-block .card {
            border: 1px solid rgba(0,0,0,.125);
        }
        .badge {
            font-size: 0.875rem;
            padding: 0.375rem 0.5rem;
        }
        .view-modal-container .swal2-popup {
        padding: 2rem;
    }
    
    .view-modal-container .swal2-html-container {
        margin: 1rem 0;
        text-align: left;
    }
    
    .text-left {
        text-align: left;
    }
    
    .badge {
        font-size: 0.75rem;
        padding: 0.25rem 0.5rem;
    }
    
    .card {
        margin-bottom: 0.5rem;
    }
    
    .card-body.p-2 {
        padding: 0.5rem !important;
    }
    
    .mb-1 {
        margin-bottom: 0.25rem !important;
    }
    </style>
</head>
<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <?php include 'inc/admin_approver_sidebar.php'; ?>

        <div class="content-wrapper">
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1><i class="fas fa-clipboard-list"></i> Admin For Approval Requests</h1>
                        </div>
                        <div class="col-sm-6">
                            <div class="float-right">
                                <h5 class="text-muted">
                                    <i class="fas fa-user"></i> Admin: <?php echo htmlspecialchars($admin_name); ?>
                                </h5>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section class="content">
                <div class="container-fluid">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Trip Requests Pending Admin Approval</h3>
                        </div>
                        <div class="card-body">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Requestor</th>
                                        <th>Department</th>
                                        <th>Date Needed</th>
                                        <th>Manager</th>
                                        <th>Manager Status</th>
                                        <th>Admin Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="tripRequestsTable">
                                    <!-- Data will be loaded via AJAX -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <div id="loadingIndicator" style="display:none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);">
    <div class="spinner-border text-primary" role="status">
        <span class="sr-only">Loading...</span>
    </div>
</div>

<!-- Include the shared modal -->
<?php include '../inc/trip_details_modal.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/js/adminlte.min.js"></script>
<script>
        $(document).ready(function() {
    // Initialize trip requests
    loadTripRequests();
    
    // Setup dashboard auto-refresh using DashboardManager
    DashboardManager.setupDashboard({ 
        loadFunction: loadTripRequests 
    });

    // Setup view buttons if needed
    if (typeof ModalHandler !== 'undefined') {
        ModalHandler.init();
    } else {
        console.error('ModalHandler not loaded');
    }

    // Replace the existing loadTripRequests function
    function loadTripRequests() {
        $.ajax({
            url: 'fetch_admin_requests.php',
            method: 'GET',
            dataType: 'json',
            beforeSend: function() {
                $('#loadingIndicator').show();
                console.log('Loading trip requests...');
            },
            success: function(response) {
                console.log('Response received:', response);
                
                if (response.error) {
                    Swal.fire('Error', response.error, 'error');
                    return;
                }

                let tableRows = '';
                response.forEach(request => {
                    tableRows += `
                        <tr>
                            <td>${request.id}</td>
                            <td>${request.requestor_name}</td>
                            <td>${request.department}</td>
                            <td>${request.date_needed}</td>
                            <td>${request.manager_name}</td>
                            <td><span class="badge badge-${getStatusBadgeClass(request.manager_status)}">${request.manager_status}</span></td>
                            <td><span class="badge badge-${getStatusBadgeClass(request.admin_status)}">${request.admin_status}</span></td>
                            <td>
                                <div class="btn-group">
                                    <button class="btn btn-sm btn-primary view-trip-btn" data-id="${request.id}">
                                        <i class="fas fa-eye"></i> View
                                    </button>
                                    ${request.manager_status === 'Approved' && request.admin_status === 'Pending' ? `
                                        <button class="btn btn-success btn-sm approve-btn" data-id="${request.id}">
                                            <i class="fas fa-check"></i> Approve
                                        </button>
                                        <button class="btn btn-danger btn-sm reject-btn" data-id="${request.id}">
                                            <i class="fas fa-times"></i> Reject
                                        </button>
                                    ` : ''}
                                </div>
                            </td>
                        </tr>
                    `;
                });

                if (tableRows) {
                    $('#tripRequestsTable').html(tableRows);
                } else {
                    $('#tripRequestsTable').html('<tr><td colspan="8" class="text-center">No pending requests found</td></tr>');
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', {
                    status: status,
                    error: error,
                    response: xhr.responseText
                });
                Swal.fire('Error', 'Failed to load trip requests', 'error');
            },
            complete: function() {
                $('#loadingIndicator').hide();
            }
        });
    }

    function getStatusBadgeClass(status) {
        switch(status.toLowerCase()) {
            case 'approved': return 'success';
            case 'rejected': return 'danger';
            case 'pending': return 'warning';
            default: return 'secondary';
        }
    }

    // Update the approve button handler
    $(document).on('click', '.approve-btn', function() {
        const tripId = $(this).data('id');
        
        // Fetch both vehicles and drivers concurrently
        $.when(
            $.ajax({ url: 'fetch_available_vehicles.php', method: 'GET', dataType: 'json' }),
            $.ajax({ url: 'fetch_available_drivers.php', method: 'GET', dataType: 'json' })
        ).done(function(vehiclesData, driversData) {
            const vehicles = vehiclesData[0], drivers = driversData[0];

            if (!vehicles.length) {
                Swal.fire('Error', 'No vehicles available', 'error');
                return;
            }
            if (!drivers.length) {
                Swal.fire('Error', 'No drivers available', 'error');
                return;
            }

            const vehicleOptions = vehicles.map(v => 
                `<option value="${v.id}">${v.name} (${v.plate_number})</option>`
            ).join('');
            const driverOptions = drivers.map(d => 
                `<option value="${d.id}">${d.name} (License: ${d.license_number})</option>`
            ).join('');

            Swal.fire({
                title: 'Approve Trip Request',
                html: `
                    <div class="form-group">
                        <label for="swal-vehicle">Select Vehicle:</label>
                        <select class="form-control mb-3" id="swal-vehicle" required>
                            <option value="">Select a vehicle</option>
                            ${vehicleOptions}
                        </select>
                        <label for="swal-driver">Select Driver:</label>
                        <select class="form-control mb-3" id="swal-driver" required>
                            <option value="">Select a driver</option>
                            ${driverOptions}
                        </select>
                        <label for="swal-comment">Comments:</label>
                        <textarea class="form-control" id="swal-comment" rows="3" required></textarea>
                    </div>
                `,
                showCancelButton: true,
                confirmButtonText: 'Approve',
                confirmButtonColor: '#28a745',
                preConfirm: () => {
                    const vehicle = Swal.getPopup().querySelector('#swal-vehicle').value;
                    const driver = Swal.getPopup().querySelector('#swal-driver').value;
                    const comment = Swal.getPopup().querySelector('#swal-comment').value;
                    
                    if (!vehicle) {
                        Swal.showValidationMessage('Please select a vehicle');
                        return false;
                    }
                    if (!driver) {
                        Swal.showValidationMessage('Please select a driver');
                        return false;
                    }
                    if (!comment || !comment.trim()) {
                        Swal.showValidationMessage('Please provide approval comments');
                        return false;
                    }
                    
                    return { vehicle, driver, comment };
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: 'approve_request.php',
                        method: 'POST',
                        data: {
                            trip_id: tripId,
                            vehicle_id: result.value.vehicle,
                            driver_id: result.value.driver,
                            comment: result.value.comment
                        },
                        dataType: 'json',
                        success: function(response) {
                            console.log('Server response:', response); // Debug logging
                            if (response.status === 'success') {
                                Swal.fire('Success', response.message, 'success')
                                    .then(() => { loadTripRequests(); });
                            } else {
                                Swal.fire('Error', response.message || 'Unknown error occurred', 'error');
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error('AJAX Error:', {xhr, status, error});
                            Swal.fire('Error', 'Failed to process request. Please check console for details.', 'error');
                        }
                    });
                }
            });
        }).fail(function() {
            Swal.fire('Error', 'Failed to fetch available vehicles or drivers', 'error');
        });
    });

    // Handle reject button click
    $(document).on('click', '.reject-btn', function() {
        const tripId = $(this).data('id');
        
        Swal.fire({
            title: 'Reject Trip Request',
            input: 'textarea',
            inputLabel: 'Reason for Rejection',
            inputPlaceholder: 'Please provide a reason...',
            inputValidator: (value) => {
                if (!value) {
                    return 'You need to provide a reason for rejection!';
                }
            },
            showCancelButton: true,
            confirmButtonText: 'Reject',
            confirmButtonColor: '#dc3545'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'reject_request.php',
                    method: 'POST',
                    data: {
                        trip_id: tripId,
                        comment: result.value
                    },
                    success: function(response) {
                        if (response.status === 'success') {
                            Swal.fire('Success', 'Trip request rejected', 'success')
                            .then(() => {
                                loadTripRequests(); // Reload the table
                            });
                        } else {
                            Swal.fire('Error', response.message || 'Failed to reject request', 'error');
                        }
                    },
                    error: function(xhr, status, error) {
                        Swal.fire('Error', 'Failed to process request', 'error');
                    }
                });
            }
        });
    });

    // Replace the existing view button click handler
    $(document).on('click', '.view-trip-btn', function() {  // Note: changed from .view-btn to .view-trip-btn
        const tripId = $(this).data('id');
        console.log('Viewing trip:', tripId); // Debug log
        
        $.ajax({
            url: '../fetch_trip_details.php',
            method: 'GET',
            data: { id: tripId },
            success: function(response) {
                console.log('Response:', response); // Debug log
                
                if (response.error) {
                    Swal.fire('Error', response.error, 'error');
                    return;
                }

                // Format dates helper function
                const formatDate = (dateString) => {
                    if (!dateString) return 'N/A';
                    return new Date(dateString).toLocaleString('en-US', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                    });
                };

                // Basic info updates
                $('#modal-requestor').text(response.requestor_name);
                $('#modal-department').text(response.department);
                $('#modal-date').text(response.date_needed);
                $('#modal-time').text(response.time_needed);
                $('#modal-time-return').text(response.time_return || 'N/A');
                $('#modal-route-from').text(response.route_from);
                $('#modal-route-to').text(response.route_to);
                $('#modal-passengers').text(response.passengers);
                $('#modal-purpose').text(response.purpose);

                // Manager approval section
                const managerStatus = response.approvers.manager.status || 'Pending';
                $('#manager-status-comment').html(`
                    <span class="badge badge-${getStatusBadgeClass(managerStatus)}">
                        ${managerStatus}
                    </span>
                `);
                $('#manager-comment').text(response.approvers.manager.comment || 'No comment');
                $('#manager-comment-date').text(formatDate(response.approvers.manager.date));

                // Admin approval section
                const adminStatus = response.approvers.admin.status || 'Pending';
                $('#admin-status-comment').html(`
                    <span class="badge badge-${getStatusBadgeClass(adminStatus)}">
                        ${adminStatus}
                    </span>
                `);
                $('#admin-comment').text(response.approvers.admin.comment || 'No comment');
                $('#admin-comment-date').text(formatDate(response.approvers.admin.date));

                // Vehicle and driver info
                let vehicleInfo = '';
                if (response.approvers.admin.vehicle) {
                    vehicleInfo += `
                        <div class="mt-2 mb-2">
                            <strong>Assigned Vehicle:</strong><br>
                            ${response.approvers.admin.vehicle.name} (${response.approvers.admin.vehicle.plate_number})
                        </div>`;
                }
                if (response.approvers.admin.driver) {
                    vehicleInfo += `
                        <div class="mt-2">
                            <strong>Assigned Driver:</strong><br>
                            Name: ${response.approvers.admin.driver.name}<br>
                            Contact: ${response.approvers.admin.driver.contact}<br>
                            License: ${response.approvers.admin.driver.license}
                        </div>`;
                }
                $('#admin-vehicle-info').html(vehicleInfo || 'No vehicle/driver assigned');

                // HR approval section
                const hrStatus = response.approvers.hr.status || 'Pending';
                $('#hr-status-comment').html(`
                    <span class="badge badge-${getStatusBadgeClass(hrStatus)}">
                        ${hrStatus}
                    </span>
                `);
                $('#hr-comment').text(response.approvers.hr.comment || 'No comment');
                $('#hr-comment-date').text(formatDate(response.approvers.hr.date));

                // Show the modal
                $('#tripDetailsModal').modal('show');
            },
            error: function(xhr, status, error) {
                console.error('View Details Error:', error);
                Swal.fire('Error', 'Failed to fetch trip details', 'error');
            }
        });
    });
});
    </script>
<!-- Trip Details Modal -->
<div class="modal fade" id="tripDetailsModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">Trip Request Details</h5>
                <button type="button" class="close text-white" data-dismiss="modal">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="trip-details">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <p><strong>Requestor:</strong> <span id="modal-requestor"></span></p>
                            <p><strong>Department:</strong> <span id="modal-department"></span></p>
                            <p><strong>Date Needed:</strong> <span id="modal-date"></span></p>
                            <p><strong>Time Needed:</strong> <span id="modal-time"></span></p>
                            <p><strong>Return Time:</strong> <span id="modal-time-return"></span></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Route From:</strong> <span id="modal-route-from"></span></p>
                            <p><strong>Route To:</strong> <span id="modal-route-to"></span></p>
                            <p><strong>Passengers:</strong> <span id="modal-passengers"></span></p>
                        </div>
                    </div>
                    <h6 class="border-bottom pb-2">Purpose</h6>
                    <p id="modal-purpose" class="mb-4"></p>
                    
                    <div class="comments-section">
                        <h6 class="border-bottom pb-2">Approval Status</h6>
                        <div class="comment-block mb-3">
                            <div class="card">
                                <div class="card-body">
                                    <h6>Manager: <span id="modal-manager-name"></span></h6>
                                    <p class="mb-1"><strong>Status:</strong> <span id="manager-status-comment"></span></p>
                                    <p class="mb-1"><strong>Comment:</strong> <span id="manager-comment"></span></p>
                                    <small class="text-muted">Date: <span id="manager-comment-date"></span></small>
                                </div>
                            </div>
                        </div>
                        <div class="comment-block mb-3">
                            <div class="card">
                                <div class="card-body">
                                    <h6>Admin: <span id="modal-admin-name"></span></h6>
                                    <p class="mb-1"><strong>Status:</strong> <span id="admin-status-comment"></span></p>
                                    <div id="admin-vehicle-info"></div>
                                    <p class="mb-1"><strong>Comment:</strong> <span id="admin-comment"></span></p>
                                    <small class="text-muted">Date: <span id="admin-comment-date"></span></small>
                                </div>
                            </div>
                        </div>
                        <div class="comment-block mb-3">
                            <div class="card">
                                <div class="card-body">
                                    <h6>HR Manager: <span id="modal-hr-name"></span></h6>
                                    <p class="mb-1"><strong>Status:</strong> <span id="hr-status-comment"></span></p>
                                    <p class="mb-1"><strong>Comment:</strong> <span id="hr-comment"></span></p>
                                    <small class="text-muted">Date: <span id="hr-comment-date"></span></small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Loading Indicator -->
<div id="loadingIndicator" style="display:none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);">
    <div class="spinner-border text-primary" role="status">
        <span class="sr-only">Loading...</span>
    </div>
</div>

<!-- Scripts in correct order -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/js/adminlte.min.js"></script>
<script src="../js/dashboard-common.js"></script>
<script src="../js/modal-handler.js"></script>
</body>
</html>