<?php
session_start();
require_once '../db.php';

header('Content-Type: application/json');

// Validate admin access
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'Admin') {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized access']);
    exit;
}

try {
    // Get and validate input
    $data = $_POST;
    
    // Input validation
    if (empty($data['name']) || empty($data['contact']) || empty($data['license_number'])) {
        throw new Exception('All fields are required');
    }

    // Sanitize inputs
    $name = mysqli_real_escape_string($conn, trim($data['name']));
    $contact = mysqli_real_escape_string($conn, trim($data['contact']));
    $license_number = mysqli_real_escape_string($conn, trim($data['license_number']));

    // Check if license number already exists
    $check_query = "SELECT id FROM drivers WHERE license_number = ?";
    $stmt = mysqli_prepare($conn, $check_query);
    mysqli_stmt_bind_param($stmt, "s", $license_number);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);
    
    if (mysqli_stmt_num_rows($stmt) > 0) {
        throw new Exception('A driver with this license number already exists');
    }
    mysqli_stmt_close($stmt);

    // Insert new driver
    $query = "INSERT INTO drivers (name, contact, license_number, status) VALUES (?, ?, ?, 'Available')";
    $stmt = mysqli_prepare($conn, $query);
    
    if (!$stmt) {
        throw new Exception('Failed to prepare statement: ' . mysqli_error($conn));
    }

    mysqli_stmt_bind_param($stmt, "sss", $name, $contact, $license_number);
    
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception('Failed to add driver: ' . mysqli_stmt_error($stmt));
    }

    echo json_encode([
        'status' => 'success',
        'message' => 'Driver added successfully',
        'driver_id' => mysqli_insert_id($conn)
    ]);

} catch (Exception $e) {
    error_log("Add Driver Error: " . $e->getMessage());
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
} finally {
    if (isset($stmt)) {
        mysqli_stmt_close($stmt);
    }
    mysqli_close($conn);
}
