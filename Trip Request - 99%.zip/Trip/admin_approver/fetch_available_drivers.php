<?php
session_start();
require_once '../db.php';

header('Content-Type: application/json');

if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'Admin') {
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

try {
    // Gets only available drivers for selection
    $query = "SELECT id, name, contact, license_number FROM drivers WHERE status = 'Available' ORDER BY name";
    $result = mysqli_query($conn, $query);
    
    if (!$result) {
        throw new Exception(mysqli_error($conn));
    }

    $drivers = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $drivers[] = [
            'id' => $row['id'],
            'name' => htmlspecialchars($row['name']),
            'contact' => htmlspecialchars($row['contact']),
            'license_number' => htmlspecialchars($row['license_number']),
        ];
    }

    echo json_encode($drivers);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}

mysqli_close($conn);
