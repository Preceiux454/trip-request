<?php
session_start();
require_once '../db.php';

header('Content-Type: application/json');

// Debug information
error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    // Check authentication
    if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'Admin') {
        throw new Exception('Unauthorized access');
    }

    // Debug: Log the query execution
    error_log("Fetching trip requests for Admin...");

    // Update the SELECT query
    $query = "SELECT 
        tr.id,
        tr.requestor_name,
        tr.department,
        tr.date_needed,
        tr.time_needed,
        tr.time_return,
        tr.route_from,
        tr.route_to,
        tr.passengers,
        tr.purpose,
        tr.company_vehicle,
        tr.status,
        tr.created_at,
        COALESCE(tr.manager_id, 0) as manager_id,
        COALESCE(u.name, 'Not Assigned') as manager_name,
        COALESCE(ma.status, 'Pending') as manager_status,
        COALESCE(aa.status, 'Pending') as admin_status
    FROM trip_requests tr
    LEFT JOIN users u ON tr.manager_id = u.id
    LEFT JOIN (
        SELECT trip_id, status 
        FROM approvals 
        WHERE approver_role = 'manager'
    ) ma ON tr.id = ma.trip_id
    LEFT JOIN (
        SELECT trip_id, status 
        FROM approvals 
        WHERE approver_role = 'admin'
    ) aa ON tr.id = aa.trip_id
    WHERE tr.status NOT IN ('Final Approved', 'Rejected')
    ORDER BY tr.created_at DESC";

    $result = mysqli_query($conn, $query);
    
    if (!$result) {
        throw new Exception("Query failed: " . mysqli_error($conn));
    }

    // Debug: Log the number of rows
    $num_rows = mysqli_num_rows($result);
    error_log("Found $num_rows trip requests");

    // Update the response array structure
    $requests = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $requests[] = [
            'id' => $row['id'],
            'requestor_name' => htmlspecialchars($row['requestor_name']),
            'department' => htmlspecialchars($row['department']),
            'date_needed' => date('M d, Y', strtotime($row['date_needed'])),
            'time_needed' => date('h:i A', strtotime($row['time_needed'])),
            'time_return' => date('h:i A', strtotime($row['time_return'])),
            'route_from' => htmlspecialchars($row['route_from']),
            'route_to' => htmlspecialchars($row['route_to']),
            'passengers' => htmlspecialchars($row['passengers']),
            'purpose' => htmlspecialchars($row['purpose']),
            'company_vehicle' => $row['company_vehicle'],
            'manager_name' => htmlspecialchars($row['manager_name']),
            'manager_status' => $row['manager_status'],
            'admin_status' => $row['admin_status'],
            'status' => $row['status']
        ];
    }

    // Debug: Log the final response
    error_log("Sending response: " . json_encode($requests));
    echo json_encode($requests);

} catch (Exception $e) {
    error_log("Fetch Requests Error: " . $e->getMessage());
    echo json_encode([
        'error' => $e->getMessage(),
        'debug_info' => [
            'session_id' => session_id(),
            'user_role' => $_SESSION['role'] ?? 'not set',
            'user_id' => $_SESSION['id'] ?? 'not set'
        ]
    ]);
} finally {
    mysqli_close($conn);
}