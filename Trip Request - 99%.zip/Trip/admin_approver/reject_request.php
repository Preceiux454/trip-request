<?php
session_start();
require_once '../db.php';

header('Content-Type: application/json');

if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'Admin') {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized access']);
    exit;
}

try {
    $trip_id = intval($_POST['trip_id']);
    $comment = mysqli_real_escape_string($conn, $_POST['comment']);

    // Check if request exists and is in valid state
    $check_query = "SELECT tr.status, tr.id, 
                          COALESCE(ma.status, 'Pending') as manager_status,
                          COALESCE(aa.status, 'Pending') as admin_status
                   FROM trip_requests tr
                   LEFT JOIN approvals ma ON tr.id = ma.trip_id AND ma.approver_role = 'manager'
                   LEFT JOIN approvals aa ON tr.id = aa.trip_id AND aa.approver_role = 'admin'
                   WHERE tr.id = ?";
    
    $stmt = mysqli_prepare($conn, $check_query);
    mysqli_stmt_bind_param($stmt, "i", $trip_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);

    if (!$row) {
        throw new Exception("Trip request not found");
    }

    // Allow processing if manager has approved and admin hasn't acted yet
    if ($row['manager_status'] !== 'Approved' || $row['admin_status'] !== 'Pending') {
        throw new Exception("Trip request cannot be processed in its current status");
    }

    mysqli_begin_transaction($conn);

    // Insert admin rejection - using approver_id instead of admin_id
    $query = "INSERT INTO approvals (trip_id, approver_id, approver_role, status, comment) 
              VALUES (?, ?, 'admin', 'Rejected', ?)";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "iis", $trip_id, $_SESSION['id'], $comment);
    
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Failed to insert approval record: " . mysqli_stmt_error($stmt));
    }

    // Update trip request status
    $update_query = "UPDATE trip_requests SET status = 'Rejected' WHERE id = ?";
    $stmt = mysqli_prepare($conn, $update_query);
    mysqli_stmt_bind_param($stmt, "i", $trip_id);
    
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Failed to update trip request: " . mysqli_stmt_error($stmt));
    }

    mysqli_commit($conn);
    echo json_encode(['status' => 'success', 'message' => 'Request rejected successfully']);

} catch (Exception $e) {
    mysqli_rollback($conn);
    error_log("Rejection Error: " . $e->getMessage());
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}

mysqli_close($conn);